// extension/src/shared/i18n.ts
var translations = {
  en: {
    popup: {
      title: "sharedom",
      badge: "v1.0.0",
      ctaTitle: "Inspect DOM Element",
      ctaSubtitle: "Hover & click any element on the page",
      defaultSettings: "Default Settings",
      resolution: "Resolution",
      format: "Format",
      resStandard: "1x Standard",
      resRetina: "2x Retina HD",
      resUltra: "3x Ultra HD",
      fmtPng: "PNG (Alpha)",
      fmtJpeg: "JPEG",
      fmtWebp: "WebP",
      fmtPdf: "PDF Document",
      shortcutsTitle: "Keyboard Shortcuts",
      shortcutInspect: "Inspect Element",
      shortcutParentChild: "Parent / Child",
      shortcutCapture: "Capture Element",
      shortcutCancel: "Cancel / Close",
      buyCoffee: "Buy me a coffee",
      footer: "Zero dependencies DOM snapshotter",
      restrictedPageTitle: "Protected Page",
      restrictedPageDesc: "Browser internal pages and Chrome Web Store are protected by security policy. Open a regular website to inspect.",
      permissionErrorTitle: "Inspection Failed",
      permissionErrorDesc: "Could not access the page. Please reload the tab or check permissions and try again.",
      btnRetry: "Retry Inspection",
      btnReloadTab: "Reload Tab"
    },
    overlay: {
      title: "DOM Inspector",
      prompt: "Click or press Enter/Space",
      parent: "\u2191 Parent",
      capture: "\u21B5 Capture",
      exit: "Esc Exit"
    },
    modal: {
      title: "Capture DOM Element",
      rendering: "Rendering DOM Snapshot...",
      resolution: "Resolution",
      format: "Format",
      background: "Background",
      bgAuto: "Auto (Detected)",
      bgTransparent: "Transparent",
      bgWhite: "White (#FFF)",
      bgDark: "Dark (#111)",
      bgCustom: "Custom...",
      reselect: "Re-select",
      reselectTooltip: "Re-select element (Esc to exit)",
      base64: "Base64",
      download: "Download",
      copyImage: "Copy Image",
      pdf: "PDF",
      pdfTooltip: "Download element as PDF",
      generatingPdf: "Generating PDF...",
      pdfSuccess: "PDF downloaded!",
      pdfError: "Failed to generate PDF",
      copySuccess: "Image copied to clipboard!",
      copyError: "Could not copy image to clipboard",
      dataUrlSuccess: "Base64 Data URL copied!",
      dataUrlError: "Failed to copy Data URL",
      downloaded: "Downloaded",
      captureFailed: "Failed to capture element snapshot."
    }
  },
  es: {
    popup: {
      title: "sharedom",
      badge: "v1.0.0",
      ctaTitle: "Inspeccionar Elemento DOM",
      ctaSubtitle: "Pasa el cursor y haz clic en cualquier elemento",
      defaultSettings: "Ajustes por Defecto",
      resolution: "Resoluci\xF3n",
      format: "Formato",
      resStandard: "1x Est\xE1ndar",
      resRetina: "2x Retina HD",
      resUltra: "3x Ultra HD",
      fmtPng: "PNG (Transparencia)",
      fmtJpeg: "JPEG",
      fmtWebp: "WebP",
      fmtPdf: "Documento PDF",
      shortcutsTitle: "Atajos de Teclado",
      shortcutInspect: "Inspeccionar",
      shortcutParentChild: "Padre / Hijo",
      shortcutCapture: "Capturar elemento",
      shortcutCancel: "Cancelar / Cerrar",
      buyCoffee: "Inv\xEDtame un caf\xE9",
      footer: "Capturador de DOM con cero dependencias",
      restrictedPageTitle: "P\xE1gina Protegida",
      restrictedPageDesc: "Las p\xE1ginas internas del navegador y Chrome Web Store est\xE1n protegidas por seguridad. Abre una web normal para inspeccionar.",
      permissionErrorTitle: "Error de Inspecci\xF3n",
      permissionErrorDesc: "No se pudo acceder a la p\xE1gina. Por favor recarga la pesta\xF1a o verifica los permisos e intenta de nuevo.",
      btnRetry: "Reintentar Inspecci\xF3n",
      btnReloadTab: "Recargar Pesta\xF1a"
    },
    overlay: {
      title: "Inspector DOM",
      prompt: "Clic o pulsa Enter/Espacio",
      parent: "\u2191 Padre",
      capture: "\u21B5 Capturar",
      exit: "Esc Salir"
    },
    modal: {
      title: "Capturar Elemento DOM",
      rendering: "Renderizando Captura del DOM...",
      resolution: "Resoluci\xF3n",
      format: "Formato",
      background: "Fondo",
      bgAuto: "Auto (Detectado)",
      bgTransparent: "Transparente",
      bgWhite: "Blanco (#FFF)",
      bgDark: "Oscuro (#111)",
      bgCustom: "Personalizado...",
      reselect: "Re-seleccionar",
      reselectTooltip: "Re-seleccionar elemento (Esc para salir)",
      base64: "Base64",
      download: "Descargar",
      copyImage: "Copiar Imagen",
      pdf: "PDF",
      pdfTooltip: "Descargar elemento como PDF",
      generatingPdf: "Generando PDF...",
      pdfSuccess: "\xA1PDF descargado!",
      pdfError: "Error al generar el PDF",
      copySuccess: "\xA1Imagen copiada al portapapeles!",
      copyError: "No se pudo copiar la imagen al portapapeles",
      dataUrlSuccess: "\xA1Data URL Base64 copiada!",
      dataUrlError: "Error al copiar Data URL",
      downloaded: "Descargado",
      captureFailed: "Error al capturar el elemento."
    }
  }
};

// extension/src/popup/popup.ts
var inspectBtn = document.getElementById("inspect-btn");
var scaleSelect = document.getElementById("scale-select");
var formatSelect = document.getElementById("format-select");
var langToggleBtn = document.getElementById("lang-toggle-btn");
var osModifier = document.getElementById("os-modifier");
var ctaTitle = document.getElementById("cta-title");
var ctaSubtitle = document.getElementById("cta-subtitle");
var txtDefaultSettings = document.getElementById("txt-default-settings");
var txtResolutionLabel = document.getElementById("txt-resolution-label");
var txtFormatLabel = document.getElementById("txt-format-label");
var txtShortcutsTitle = document.getElementById("txt-shortcuts-title");
var txtShortcutInspect = document.getElementById("txt-shortcut-inspect");
var txtShortcutParentChild = document.getElementById("txt-shortcut-parent-child");
var txtShortcutCapture = document.getElementById("txt-shortcut-capture");
var txtShortcutCancel = document.getElementById("txt-shortcut-cancel");
var txtCoffee = document.getElementById("txt-coffee");
var txtFooter = document.getElementById("txt-footer");
var statusBanner = document.getElementById("status-banner");
var bannerIconShield = document.getElementById("banner-icon-shield");
var bannerIconAlert = document.getElementById("banner-icon-alert");
var bannerTitle = document.getElementById("banner-title");
var bannerDesc = document.getElementById("banner-desc");
var bannerActions = document.getElementById("banner-actions");
var bannerRetryBtn = document.getElementById("banner-retry-btn");
var bannerReloadBtn = document.getElementById("banner-reload-btn");
var isMac = navigator.platform.toUpperCase().includes("MAC") || navigator.userAgent.includes("Macintosh");
if (osModifier) {
  osModifier.textContent = isMac ? "\u2325 Option" : "Alt";
}
var currentLanguage = "en";
var currentTab = null;
var isRestrictedPage = false;
var hasPermissionError = false;
function isUrlRestricted(url) {
  if (!url) return true;
  const restrictedPrefixes = [
    "chrome://",
    "edge://",
    "about:",
    "chrome-extension://",
    "devtools://",
    "view-source:"
  ];
  if (restrictedPrefixes.some((prefix) => url.startsWith(prefix))) {
    return true;
  }
  if (url.startsWith("https://chromewebstore.google.com") || url.startsWith("https://chrome.google.com/webstore") || url.startsWith("https://microsoftedge.microsoft.com/addons")) {
    return true;
  }
  return false;
}
function updateBannerUI() {
  const t = translations[currentLanguage].popup;
  if (isRestrictedPage) {
    if (statusBanner) {
      statusBanner.style.display = "flex";
      statusBanner.className = "status-banner banner-warning";
    }
    if (bannerIconShield) bannerIconShield.style.display = "block";
    if (bannerIconAlert) bannerIconAlert.style.display = "none";
    if (bannerTitle) bannerTitle.textContent = t.restrictedPageTitle;
    if (bannerDesc) bannerDesc.textContent = t.restrictedPageDesc;
    if (bannerActions) bannerActions.style.display = "none";
    if (inspectBtn) inspectBtn.disabled = true;
  } else if (hasPermissionError) {
    if (statusBanner) {
      statusBanner.style.display = "flex";
      statusBanner.className = "status-banner banner-error";
    }
    if (bannerIconShield) bannerIconShield.style.display = "none";
    if (bannerIconAlert) bannerIconAlert.style.display = "block";
    if (bannerTitle) bannerTitle.textContent = t.permissionErrorTitle;
    if (bannerDesc) bannerDesc.textContent = t.permissionErrorDesc;
    if (bannerActions) bannerActions.style.display = "flex";
    if (bannerRetryBtn) bannerRetryBtn.textContent = t.btnRetry;
    if (bannerReloadBtn) bannerReloadBtn.textContent = t.btnReloadTab;
    if (inspectBtn) inspectBtn.disabled = false;
  } else {
    if (statusBanner) statusBanner.style.display = "none";
    if (inspectBtn) inspectBtn.disabled = false;
  }
}
function applyLanguage(lang) {
  currentLanguage = lang;
  const t = translations[lang].popup;
  if (langToggleBtn) {
    langToggleBtn.textContent = lang === "en" ? "ES" : "EN";
  }
  if (ctaTitle) ctaTitle.textContent = t.ctaTitle;
  if (ctaSubtitle) ctaSubtitle.textContent = t.ctaSubtitle;
  if (txtDefaultSettings) txtDefaultSettings.textContent = t.defaultSettings;
  if (txtResolutionLabel) txtResolutionLabel.textContent = t.resolution;
  if (txtFormatLabel) txtFormatLabel.textContent = t.format;
  if (txtShortcutsTitle) txtShortcutsTitle.textContent = t.shortcutsTitle;
  if (txtShortcutInspect) txtShortcutInspect.textContent = t.shortcutInspect;
  if (txtShortcutParentChild) txtShortcutParentChild.textContent = t.shortcutParentChild;
  if (txtShortcutCapture) txtShortcutCapture.textContent = t.shortcutCapture;
  if (txtShortcutCancel) txtShortcutCancel.textContent = t.shortcutCancel;
  if (txtCoffee) txtCoffee.textContent = t.buyCoffee;
  if (txtFooter) txtFooter.textContent = t.footer;
  if (scaleSelect) {
    const opts = scaleSelect.options;
    if (opts.length >= 3) {
      opts[0].textContent = t.resStandard;
      opts[1].textContent = t.resRetina;
      opts[2].textContent = t.resUltra;
    }
  }
  if (formatSelect) {
    const opts = formatSelect.options;
    if (opts.length >= 4) {
      opts[0].textContent = t.fmtPng;
      opts[1].textContent = t.fmtJpeg;
      opts[2].textContent = t.fmtWebp;
      opts[3].textContent = t.fmtPdf;
    }
  }
  updateBannerUI();
}
async function loadSettings() {
  try {
    const data = await chrome.storage.local.get(["language", "defaultScale", "defaultFormat"]);
    if (data.language === "en" || data.language === "es") {
      applyLanguage(data.language);
    } else {
      applyLanguage("en");
    }
    if (data.defaultScale && scaleSelect) {
      scaleSelect.value = String(data.defaultScale);
    }
    if (data.defaultFormat && formatSelect) {
      formatSelect.value = String(data.defaultFormat);
    }
  } catch {
    applyLanguage("en");
  }
}
async function saveSettings() {
  try {
    await chrome.storage.local.set({
      language: currentLanguage,
      defaultScale: Number(scaleSelect.value),
      defaultFormat: formatSelect.value
    });
  } catch {
  }
}
async function checkActiveTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    currentTab = tab || null;
    isRestrictedPage = isUrlRestricted(tab?.url);
    updateBannerUI();
  } catch {
    isRestrictedPage = true;
    updateBannerUI();
  }
}
async function startInspection() {
  hasPermissionError = false;
  updateBannerUI();
  if (!currentTab?.id || isRestrictedPage) {
    return;
  }
  const inspectorOptions = {
    scale: Number(scaleSelect.value),
    format: formatSelect.value,
    language: currentLanguage
  };
  try {
    await chrome.tabs.sendMessage(currentTab.id, {
      type: "START_INSPECTOR",
      options: inspectorOptions
    });
    window.close();
  } catch {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: currentTab.id },
        files: ["content.js"]
      });
      setTimeout(async () => {
        try {
          await chrome.tabs.sendMessage(currentTab.id, {
            type: "START_INSPECTOR",
            options: inspectorOptions
          });
          window.close();
        } catch {
          hasPermissionError = true;
          updateBannerUI();
        }
      }, 100);
    } catch {
      hasPermissionError = true;
      updateBannerUI();
    }
  }
}
langToggleBtn?.addEventListener("click", async () => {
  const nextLang = currentLanguage === "en" ? "es" : "en";
  applyLanguage(nextLang);
  await saveSettings();
});
scaleSelect?.addEventListener("change", saveSettings);
formatSelect?.addEventListener("change", saveSettings);
inspectBtn?.addEventListener("click", startInspection);
bannerRetryBtn?.addEventListener("click", startInspection);
bannerReloadBtn?.addEventListener("click", async () => {
  if (currentTab?.id) {
    try {
      await chrome.tabs.reload(currentTab.id);
      window.close();
    } catch {
    }
  }
});
loadSettings();
checkActiveTab();
