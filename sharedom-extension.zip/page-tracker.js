"use strict";
(() => {
  // extension/src/content/page-tracker.ts
  (() => {
    const w = window;
    if (typeof window === "undefined" || w.__sharedom_tracker_installed__) return;
    w.__sharedom_tracker_installed__ = true;
    const logsBuffer = [];
    const reqsBuffer = [];
    const MAX_BUFFER = 300;
    function emitEvent(name, payload) {
      try {
        const detail = JSON.stringify(payload);
        window.dispatchEvent(new CustomEvent(name, { detail }));
        document.dispatchEvent(new CustomEvent(name, { detail }));
      } catch {
        try {
          window.dispatchEvent(new CustomEvent(name, { detail: payload }));
        } catch {
        }
      }
    }
    function formatValue(v) {
      if (v === null) return "null";
      if (v === void 0) return "undefined";
      if (typeof v === "string") return v;
      if (typeof v === "number" || typeof v === "boolean") return String(v);
      if (v instanceof Error) {
        return v.stack || `${v.name}: ${v.message}`;
      }
      if (typeof v === "object") {
        try {
          if ("message" in v && "name" in v) {
            return v.stack || `${v.name}: ${v.message}`;
          }
          return JSON.stringify(v);
        } catch {
          return Object.prototype.toString.call(v);
        }
      }
      return String(v);
    }
    function formatConsoleArgs(args) {
      if (args.length === 0) return "";
      const first = args[0];
      if (typeof first === "string" && first.includes("%c")) {
        let text = first.replace(/%c/g, "").trim();
        const extraArgs = [];
        for (let i = 1; i < args.length; i++) {
          const a = args[i];
          if (typeof a === "string" && (a.includes(":") || a.includes("color") || a.includes("font") || a.includes("background"))) {
            continue;
          }
          extraArgs.push(a);
        }
        if (extraArgs.length > 0) {
          text += " " + extraArgs.map(formatValue).join(" ");
        }
        return text;
      }
      return args.map(formatValue).join(" ");
    }
    function recordLog(level, rawArgs) {
      try {
        const message = formatConsoleArgs(rawArgs);
        if (!message && rawArgs.length === 0) return;
        const item = {
          level,
          message: message || `(${level})`,
          timestamp: Date.now(),
          count: 1
        };
        const last = logsBuffer[logsBuffer.length - 1];
        if (last && last.level === level && last.message === item.message) {
          last.count = (last.count || 1) + 1;
          last.timestamp = item.timestamp;
        } else {
          if (logsBuffer.length >= MAX_BUFFER) logsBuffer.shift();
          logsBuffer.push(item);
        }
        emitEvent("__sharedom_page_log__", item);
      } catch {
      }
    }
    const methods = ["log", "info", "warn", "error", "debug", "trace", "dir", "table"];
    for (const method of methods) {
      let original = console[method];
      const hook = function(...args) {
        const level = method === "trace" ? "debug" : method === "dir" || method === "table" ? "log" : method;
        recordLog(level, args);
        if (typeof original === "function") {
          try {
            return original.apply(console, args);
          } catch {
            return original(...args);
          }
        }
      };
      try {
        Object.defineProperty(console, method, {
          configurable: true,
          enumerable: true,
          get() {
            return hook;
          },
          set(newFn) {
            original = newFn;
          }
        });
      } catch {
        console[method] = hook;
      }
    }
    window.addEventListener("error", (event) => {
      try {
        const err = event.error;
        const message = err ? err.stack || `${err.name || "Error"}: ${err.message || event.message}` : event.message || "Script error";
        if (message) {
          recordLog("error", [message]);
        }
      } catch {
      }
    }, true);
    window.addEventListener("unhandledrejection", (event) => {
      try {
        const reason = event.reason;
        const message = reason instanceof Error ? reason.stack || `${reason.name}: ${reason.message}` : typeof reason === "object" && reason !== null ? JSON.stringify(reason) : String(reason);
        if (message) {
          recordLog("error", [`Unhandled Rejection: ${message}`]);
        }
      } catch {
      }
    }, true);
    function extractName(url) {
      try {
        const u = new URL(url, window.location.href);
        return u.pathname + (u.search || "") || u.host || url;
      } catch {
        return url;
      }
    }
    function recordReq(req) {
      if (reqsBuffer.length >= MAX_BUFFER) reqsBuffer.shift();
      reqsBuffer.push(req);
      emitEvent("__sharedom_page_req__", req);
    }
    if (typeof window.fetch === "function") {
      const origFetch = window.fetch;
      window.fetch = function(input, init) {
        const start = performance.now();
        const url = typeof input === "string" ? input : input && input.url ? input.url : String(input);
        const method = init && init.method || input && input.method || "GET";
        return origFetch.apply(window, [input, init]).then((res) => {
          try {
            recordReq({
              method: method.toUpperCase(),
              url,
              name: extractName(url),
              status: res.status,
              statusText: res.statusText || (res.ok ? "OK" : ""),
              type: "fetch",
              duration: Math.round(performance.now() - start),
              timestamp: Date.now()
            });
          } catch {
          }
          return res;
        }).catch((err) => {
          try {
            recordReq({
              method: method.toUpperCase(),
              url,
              name: extractName(url),
              status: 0,
              statusText: "Failed",
              type: "fetch",
              duration: Math.round(performance.now() - start),
              timestamp: Date.now()
            });
          } catch {
          }
          throw err;
        });
      };
    }
    if (typeof XMLHttpRequest !== "undefined") {
      const origOpen = XMLHttpRequest.prototype.open;
      const origSend = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open = function(method, url, ...rest) {
        this.__sh_method = method;
        this.__sh_url = typeof url === "string" ? url : url && url.href ? url.href : String(url);
        return origOpen.apply(this, [method, url, ...rest]);
      };
      XMLHttpRequest.prototype.send = function(body) {
        const self = this;
        const start = performance.now();
        this.addEventListener("loadend", () => {
          try {
            recordReq({
              method: (self.__sh_method || "GET").toUpperCase(),
              url: self.__sh_url || "",
              name: extractName(self.__sh_url || ""),
              status: self.status,
              statusText: self.statusText,
              type: "xhr",
              duration: Math.round(performance.now() - start),
              timestamp: Date.now()
            });
          } catch {
          }
        });
        return origSend.apply(this, [body]);
      };
    }
    const handleSync = () => {
      logsBuffer.forEach((log) => emitEvent("__sharedom_page_log__", log));
      reqsBuffer.forEach((req) => emitEvent("__sharedom_page_req__", req));
    };
    window.addEventListener("__sharedom_request_sync__", handleSync);
    document.addEventListener("__sharedom_request_sync__", handleSync);
  })();
})();
