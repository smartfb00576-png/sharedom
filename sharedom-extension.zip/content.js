"use strict";
(() => {
  // extension/src/content/styles.ts
  var overlayStyles = `
:host {
  all: initial;
  z-index: 2147483647;
  position: fixed;
  inset: 0;
  pointer-events: none;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
}

*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

.sharedom-hidden {
  display: none !important;
}

.sharedom-status-pill {
  position: fixed;
  top: 18px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(18, 18, 24, 0.94);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  color: #f4f4f5;
  border: 1px solid rgba(255, 255, 255, 0.14);
  padding: 8px 16px;
  border-radius: 9999px;
  display: flex;
  align-items: center;
  gap: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.05);
  pointer-events: auto;
  user-select: none;
  font-size: 13px;
  font-weight: 500;
  z-index: 2147483647;
  animation: sharedomSlideDown 0.2s cubic-bezier(0.16, 1, 0.3, 1);
}

.sharedom-status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #22c55e;
  box-shadow: 0 0 8px #22c55e;
  animation: sharedomPulse 1.8s infinite;
}

.sharedom-status-title {
  color: #ffffff;
  font-weight: 600;
  letter-spacing: -0.01em;
}

.sharedom-shortcut-group {
  display: flex;
  align-items: center;
  gap: 6px;
  border-left: 1px solid rgba(255, 255, 255, 0.12);
  padding-left: 12px;
}

.sharedom-kbd {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.15);
  color: #d4d4d8;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 4px;
  line-height: 1;
}

.sharedom-close-pill-btn {
  background: transparent;
  border: none;
  color: #a1a1aa;
  cursor: pointer;
  padding: 4px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease;
}

.sharedom-close-pill-btn:hover {
  background: rgba(255, 255, 255, 0.15);
  color: #ffffff;
}

.sharedom-highlight-box {
  position: fixed;
  pointer-events: none;
  border: 2px solid #6366f1;
  background: rgba(99, 102, 241, 0.15);
  border-radius: 4px;
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.35), 0 0 24px rgba(99, 102, 241, 0.25);
  transition: top 0.05s ease-out, left 0.05s ease-out, width 0.05s ease-out, height 0.05s ease-out;
  z-index: 2147483645;
}

.sharedom-highlight-tag {
  position: absolute;
  top: -28px;
  left: 0;
  background: #0f172a;
  color: #f8fafc;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 11px;
  font-weight: 500;
  padding: 3px 8px;
  border-radius: 5px;
  border: 1px solid rgba(255, 255, 255, 0.16);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.35);
  white-space: nowrap;
  pointer-events: none;
  display: flex;
  align-items: center;
  gap: 6px;
}

.sharedom-highlight-tag.flipped-down {
  top: auto;
  bottom: -28px;
}

.sharedom-tag-name {
  color: #818cf8;
  font-weight: 700;
}

.sharedom-tag-class {
  color: #94a3b8;
}

.sharedom-tag-size {
  color: #38bdf8;
  border-left: 1px solid rgba(255, 255, 255, 0.15);
  padding-left: 6px;
}

.sharedom-modal-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.55);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
  display: flex;
  align-items: center;
  justify-content: center;
  pointer-events: auto;
  z-index: 2147483646;
  animation: sharedomFadeIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
  padding: 16px;
}

.sharedom-modal-card {
  background: #111116;
  color: #fafafa;
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 20px;
  width: 540px;
  max-width: calc(100vw - 32px);
  max-height: 90vh;
  box-shadow: 0 25px 60px -15px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.05);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  animation: sharedomScaleUp 0.22s cubic-bezier(0.16, 1, 0.3, 1);
}

.sharedom-modal-header {
  padding: 18px 22px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}

.sharedom-modal-title-wrap {
  display: flex;
  align-items: center;
  gap: 10px;
}

.sharedom-modal-logo {
  width: 28px;
  height: 28px;
  border-radius: 8px;
  background: linear-gradient(135deg, #6366f1, #06b6d4);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-weight: 800;
  font-size: 14px;
}

.sharedom-modal-title {
  font-size: 16px;
  font-weight: 600;
  color: #ffffff;
  letter-spacing: -0.01em;
}

.sharedom-modal-subtitle {
  font-size: 12px;
  color: #a1a1aa;
}

.sharedom-icon-btn {
  background: transparent;
  border: none;
  color: #71717a;
  cursor: pointer;
  padding: 6px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease;
}

.sharedom-icon-btn:hover {
  background: rgba(255, 255, 255, 0.08);
  color: #ffffff;
}

.sharedom-modal-body {
  padding: 20px 22px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.sharedom-preview-container {
  width: 100%;
  min-height: 180px;
  max-height: 300px;
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  background-color: #1c1c24;
  background-image: 
    linear-gradient(45deg, #262633 25%, transparent 25%), 
    linear-gradient(-45deg, #262633 25%, transparent 25%), 
    linear-gradient(45deg, transparent 75%, #262633 75%), 
    linear-gradient(-45deg, transparent 75%, #262633 75%);
  background-size: 16px 16px;
  background-position: 0 0, 0 8px, 8px -8px, -8px 0px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  position: relative;
}

.sharedom-preview-img {
  max-width: 100%;
  max-height: 290px;
  object-fit: contain;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
  border-radius: 4px;
}

.sharedom-preview-loader {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  color: #a1a1aa;
  font-size: 13px;
}

.sharedom-spinner {
  width: 28px;
  height: 28px;
  border: 3px solid rgba(255, 255, 255, 0.1);
  border-top-color: #6366f1;
  border-radius: 50%;
  animation: sharedomSpin 0.8s linear infinite;
}

.sharedom-preview-meta {
  position: absolute;
  bottom: 8px;
  right: 8px;
  background: rgba(0, 0, 0, 0.75);
  backdrop-filter: blur(6px);
  color: #e4e4e7;
  font-size: 11px;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  padding: 3px 8px;
  border-radius: 6px;
  border: 1px solid rgba(255, 255, 255, 0.12);
}

.sharedom-controls-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}

.sharedom-control-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.sharedom-control-label {
  font-size: 12px;
  font-weight: 500;
  color: #a1a1aa;
}

.sharedom-select-wrap {
  position: relative;
}

.sharedom-select {
  width: 100%;
  background: #1e1e26;
  border: 1px solid rgba(255, 255, 255, 0.12);
  color: #ffffff;
  padding: 8px 12px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  outline: none;
  cursor: pointer;
  appearance: none;
  transition: all 0.15s ease;
}

.sharedom-select:hover {
  border-color: rgba(255, 255, 255, 0.22);
}

.sharedom-select:focus {
  border-color: #6366f1;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.25);
}

.sharedom-btn-group {
  display: flex;
  border-radius: 8px;
  background: #1e1e26;
  border: 1px solid rgba(255, 255, 255, 0.12);
  overflow: hidden;
}

.sharedom-btn-option {
  flex: 1;
  background: transparent;
  border: none;
  color: #a1a1aa;
  padding: 8px 4px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.15s ease;
  text-align: center;
}

.sharedom-btn-option:not(:last-child) {
  border-right: 1px solid rgba(255, 255, 255, 0.08);
}

.sharedom-btn-option:hover {
  color: #ffffff;
  background: rgba(255, 255, 255, 0.04);
}

.sharedom-btn-option.active {
  background: #6366f1;
  color: #ffffff;
}

.sharedom-color-picker-wrap {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #1e1e26;
  border: 1px solid rgba(255, 255, 255, 0.12);
  padding: 4px 8px;
  border-radius: 8px;
}

.sharedom-color-input {
  width: 24px;
  height: 24px;
  border: none;
  border-radius: 4px;
  background: transparent;
  cursor: pointer;
  padding: 0;
}

.sharedom-color-label {
  font-size: 12px;
  color: #ffffff;
  font-family: ui-monospace, monospace;
}

.sharedom-modal-footer {
  padding: 16px 20px;
  border-top: 1px solid rgba(255, 255, 255, 0.08);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  background: #0d0d12;
}

.sharedom-footer-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.sharedom-footer-right {
  display: flex;
  align-items: center;
  gap: 10px;
}

.sharedom-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  height: 38px;
  min-height: 38px;
  max-height: 38px;
  padding: 0 14px;
  border-radius: 10px;
  font-size: 13px;
  font-weight: 600;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  transition: all 0.15s ease;
  border: none;
  outline: none;
  user-select: none;
  box-sizing: border-box;
}

.sharedom-btn-icon {
  width: 38px;
  height: 38px;
  min-width: 38px;
  max-width: 38px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.sharedom-btn svg {
  flex-shrink: 0;
}

.sharedom-btn-secondary {
  background: #24242e;
  color: #f4f4f5;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.sharedom-btn-secondary:hover {
  background: #2e2e3a;
  border-color: rgba(255, 255, 255, 0.18);
}

.sharedom-btn-copylogs {
  background: rgba(167, 139, 250, 0.12);
  color: #c4b5fd;
  border: 1px solid rgba(167, 139, 250, 0.28);
}

.sharedom-btn-copylogs:hover {
  background: rgba(167, 139, 250, 0.22);
  color: #ffffff;
  border-color: rgba(167, 139, 250, 0.5);
  transform: translateY(-1px);
}

.sharedom-btn-copylogs:active {
  transform: translateY(0);
}

.sharedom-btn-pdf {
  background: rgba(239, 68, 68, 0.12);
  color: #f87171;
  border: 1px solid rgba(239, 68, 68, 0.28);
}

.sharedom-btn-pdf:hover {
  background: rgba(239, 68, 68, 0.22);
  color: #fca5a5;
  border-color: rgba(239, 68, 68, 0.5);
  transform: translateY(-1px);
}

.sharedom-btn-pdf:active {
  transform: translateY(0);
}

.sharedom-btn-primary {
  background: linear-gradient(135deg, #6366f1, #4f46e5);
  color: #ffffff;
  box-shadow: 0 4px 14px rgba(99, 102, 241, 0.35);
}

.sharedom-btn-primary:hover {
  background: linear-gradient(135deg, #4f46e5, #4338ca);
  box-shadow: 0 6px 20px rgba(99, 102, 241, 0.45);
  transform: translateY(-1px);
}

.sharedom-btn-primary:active {
  transform: translateY(0);
}

.sharedom-btn-ghost {
  background: transparent;
  color: #a1a1aa;
  padding: 8px 12px;
}

.sharedom-btn-ghost:hover {
  background: rgba(255, 255, 255, 0.08);
  color: #ffffff;
}

.sharedom-toast-container {
  position: fixed;
  bottom: 24px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  flex-direction: column;
  gap: 8px;
  z-index: 2147483647;
  pointer-events: none;
}

.sharedom-toast {
  background: #09090b;
  color: #ffffff;
  border: 1px solid rgba(255, 255, 255, 0.16);
  padding: 10px 18px;
  border-radius: 12px;
  font-size: 13px;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 10px;
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(255, 255, 255, 0.08);
  animation: sharedomToastIn 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  pointer-events: auto;
}

@keyframes sharedomSlideDown {
  from {
    opacity: 0;
    transform: translate(-50%, -12px);
  }
  to {
    opacity: 1;
    transform: translate(-50%, 0);
  }
}

@keyframes sharedomFadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes sharedomScaleUp {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

@keyframes sharedomPulse {
  0%, 100% {
    opacity: 1;
    transform: scale(1);
  }
  50% {
    opacity: 0.5;
    transform: scale(0.85);
  }
}

@keyframes sharedomSpin {
  to {
    transform: rotate(360deg);
  }
}

@keyframes sharedomToastIn {
  from {
    opacity: 0;
    transform: translateY(12px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.sharedom-pagination-bar {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  margin-top: 10px;
  width: 100%;
}

.sharedom-page-btn {
  background: #1e1e2c;
  border: 1px solid rgba(255, 255, 255, 0.14);
  color: #f1f5f9;
  border-radius: 8px;
  padding: 5px 12px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  font-size: 12px;
  font-weight: 500;
  transition: all 0.15s ease;
}

.sharedom-page-btn:hover:not(:disabled) {
  background: #2a2a3e;
  border-color: rgba(167, 139, 250, 0.4);
  transform: translateY(-1px);
}

.sharedom-page-btn:disabled {
  opacity: 0.35;
  cursor: not-allowed;
  transform: none !important;
}

.sharedom-page-indicator {
  font-size: 12.5px;
  font-weight: 600;
  color: #cbd5e1;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  min-width: 60px;
  text-align: center;
}

@media (max-width: 600px) {
  .sharedom-modal-footer {
    flex-direction: column;
    align-items: stretch;
    gap: 10px;
    padding: 12px 16px;
  }
  .sharedom-footer-left,
  .sharedom-footer-right {
    width: 100%;
    display: flex;
    justify-content: stretch;
    gap: 8px;
  }
  .sharedom-footer-left .sharedom-btn,
  .sharedom-footer-right .sharedom-btn {
    flex: 1 1 0;
    min-width: 0;
    padding: 0 8px;
    font-size: 12px;
  }
}
`;

  // extension/src/shared/i18n.ts
  var translations = {
    en: {
      popup: {
        title: "sharedom",
        badge: "v1.2.0",
        ctaTitle: "Inspect DOM Element",
        ctaSubtitle: "Hover & click any element on the page",
        specializedTitle: "Specialized Captures",
        btnConsoleLogs: "Capture Console Logs",
        btnConsoleLogsSubtitle: "Export console output as image or PDF",
        btnNetworkRequests: "Capture Network Requests",
        btnNetworkRequestsSubtitle: "Export API requests, status & URLs",
        defaultSettings: "Default Settings",
        resolution: "Resolution",
        format: "Format",
        resStandard: "1x Standard",
        resRetina: "2x Retina HD",
        resUltra: "3x Ultra HD",
        fmtPng: "PNG (Alpha)",
        fmtJpeg: "JPEG",
        fmtWebp: "WebP",
        fmtPdf: "PDF Document",
        shortcutsTitle: "Keyboard Shortcuts",
        shortcutInspect: "Inspect Element",
        shortcutParentChild: "Parent / Child",
        shortcutCapture: "Capture Element",
        shortcutCancel: "Cancel / Close",
        buyCoffee: "Buy me a coffee",
        footer: "Zero dependencies DOM snapshotter",
        restrictedPageTitle: "Protected Page",
        restrictedPageDesc: "Browser internal pages and Chrome Web Store are protected by security policy. Open a regular website to inspect.",
        permissionErrorTitle: "Inspection Failed",
        permissionErrorDesc: "Could not access the page. Please reload the tab or check permissions and try again.",
        btnRetry: "Retry Inspection",
        btnReloadTab: "Reload Tab"
      },
      overlay: {
        title: "DOM Inspector",
        prompt: "Click or press Enter/Space",
        parent: "\u2191 Parent",
        capture: "\u21B5 Capture",
        exit: "Esc Exit"
      },
      modal: {
        title: "Capture DOM Element",
        consoleTitle: "Capture Console Logs",
        networkTitle: "Capture Network Requests",
        logsSubtitle: "Console output snapshot",
        networkSubtitle: "Network requests snapshot",
        rendering: "Rendering DOM Snapshot...",
        resolution: "Resolution",
        format: "Format",
        background: "Background",
        bgAuto: "Auto (Detected)",
        bgTransparent: "Transparent",
        bgWhite: "White (#FFF)",
        bgDark: "Dark (#111)",
        bgCustom: "Custom...",
        reselect: "Re-select",
        reselectTooltip: "Re-select element (Esc to exit)",
        base64: "Base64",
        download: "Download",
        copyImage: "Copy Image",
        pdf: "PDF",
        pdfTooltip: "Download element as PDF",
        generatingPdf: "Generating PDF...",
        pdfSuccess: "PDF downloaded!",
        pdfError: "Failed to generate PDF",
        copySuccess: "Image copied to clipboard!",
        copyError: "Could not copy image to clipboard",
        dataUrlSuccess: "Base64 Data URL copied!",
        dataUrlError: "Failed to copy Data URL",
        downloaded: "Downloaded",
        captureFailed: "Failed to capture element snapshot.",
        loadingDom: "Capturing element snapshot...",
        loadingLogs: "Capturing console logs...",
        loadingNetwork: "Capturing network requests...",
        page: "Page",
        prevPage: "Previous page",
        nextPage: "Next page",
        allCopied: "All images copied to clipboard!",
        allDownloaded: "All images downloaded!",
        zipDownloaded: "ZIP file downloaded with all images!",
        copyLogs: "Copy Logs",
        copyLogsTooltip: "Copy all console logs as text to clipboard",
        logsCopied: "All console logs copied to clipboard!",
        logsCopyError: "Failed to copy logs to clipboard"
      }
    },
    es: {
      popup: {
        title: "sharedom",
        badge: "v1.2.0",
        ctaTitle: "Inspeccionar Elemento DOM",
        ctaSubtitle: "Pasa el cursor y haz clic en cualquier elemento",
        specializedTitle: "Capturas Especializadas",
        btnConsoleLogs: "Capturar Consola",
        btnConsoleLogsSubtitle: "Exportar consola como imagen o PDF",
        btnNetworkRequests: "Capturar Peticiones",
        btnNetworkRequestsSubtitle: "Exportar peticiones API, estado y URLs",
        defaultSettings: "Ajustes por Defecto",
        resolution: "Resoluci\xF3n",
        format: "Formato",
        resStandard: "1x Est\xE1ndar",
        resRetina: "2x Retina HD",
        resUltra: "3x Ultra HD",
        fmtPng: "PNG (Transparencia)",
        fmtJpeg: "JPEG",
        fmtWebp: "WebP",
        fmtPdf: "Documento PDF",
        shortcutsTitle: "Atajos de Teclado",
        shortcutInspect: "Inspeccionar",
        shortcutParentChild: "Padre / Hijo",
        shortcutCapture: "Capturar elemento",
        shortcutCancel: "Cancelar / Cerrar",
        buyCoffee: "Inv\xEDtame un caf\xE9",
        footer: "Capturador de DOM con cero dependencias",
        restrictedPageTitle: "P\xE1gina Protegida",
        restrictedPageDesc: "Las p\xE1ginas internas del navegador y Chrome Web Store est\xE1n protegidas por seguridad. Abre una web normal para inspeccionar.",
        permissionErrorTitle: "Error de Inspecci\xF3n",
        permissionErrorDesc: "No se pudo acceder a la p\xE1gina. Por favor recarga la pesta\xF1a o verifica los permisos e intenta de nuevo.",
        btnRetry: "Reintentar Inspecci\xF3n",
        btnReloadTab: "Recargar Pesta\xF1a"
      },
      overlay: {
        title: "Inspector DOM",
        prompt: "Clic o pulsa Enter/Espacio",
        parent: "\u2191 Padre",
        capture: "\u21B5 Capturar",
        exit: "Esc Salir"
      },
      modal: {
        title: "Capturar Elemento DOM",
        consoleTitle: "Capturar Registros de Consola",
        networkTitle: "Capturar Peticiones de Red",
        logsSubtitle: "Captura de registros de consola",
        networkSubtitle: "Captura de peticiones de red",
        rendering: "Renderizando Captura del DOM...",
        resolution: "Resoluci\xF3n",
        format: "Formato",
        background: "Fondo",
        bgAuto: "Auto (Detectado)",
        bgTransparent: "Transparente",
        bgWhite: "Blanco (#FFF)",
        bgDark: "Oscuro (#111)",
        bgCustom: "Personalizado...",
        reselect: "Re-seleccionar",
        reselectTooltip: "Re-seleccionar elemento (Esc para salir)",
        base64: "Base64",
        download: "Descargar",
        copyImage: "Copiar Imagen",
        pdf: "PDF",
        pdfTooltip: "Descargar elemento como PDF",
        generatingPdf: "Generando PDF...",
        pdfSuccess: "\xA1PDF descargado!",
        pdfError: "Error al generar el PDF",
        copySuccess: "\xA1Imagen copiada al portapapeles!",
        copyError: "No se pudo copiar la imagen al portapapeles",
        dataUrlSuccess: "\xA1Data URL Base64 copiado!",
        dataUrlError: "Error al copiar Data URL",
        downloaded: "Descargado",
        captureFailed: "Error al capturar elemento.",
        loadingDom: "Capturando elemento...",
        loadingLogs: "Capturando registros de consola...",
        loadingNetwork: "Capturando peticiones de red...",
        page: "P\xE1gina",
        prevPage: "P\xE1gina anterior",
        nextPage: "P\xE1gina siguiente",
        allCopied: "\xA1Todas las im\xE1genes fueron copiadas al portapapeles!",
        allDownloaded: "\xA1Todas las im\xE1genes fueron descargadas!",
        zipDownloaded: "\xA1Archivo ZIP descargado con todas las im\xE1genes!",
        copyLogs: "Copiar Logs",
        copyLogsTooltip: "Copiar todos los registros de consola como texto al portapapeles",
        logsCopied: "\xA1Todos los logs fueron copiados al portapapeles!",
        logsCopyError: "Error al copiar los logs al portapapeles"
      }
    }
  };

  // extension/src/content/overlay.ts
  var OverlayManager = class {
    host = null;
    shadow = null;
    statusPill = null;
    highlightBox = null;
    highlightTag = null;
    tagNameEl = null;
    tagClassEl = null;
    tagSizeEl = null;
    toastContainer = null;
    language = "en";
    constructor(language = "en") {
      this.language = language;
      this.init();
    }
    setLanguage(language) {
      this.language = language;
    }
    init() {
      const existing = document.getElementById("sharedom-inspector-host");
      if (existing) {
        existing.remove();
      }
      this.host = document.createElement("div");
      this.host.id = "sharedom-inspector-host";
      this.shadow = this.host.attachShadow({ mode: "open" });
      const styleEl = document.createElement("style");
      styleEl.textContent = overlayStyles;
      this.shadow.appendChild(styleEl);
      this.createHighlightBox();
      this.createToastContainer();
      document.documentElement.appendChild(this.host);
    }
    createHighlightBox() {
      if (!this.shadow) return;
      this.highlightBox = document.createElement("div");
      this.highlightBox.className = "sharedom-highlight-box sharedom-hidden";
      this.highlightTag = document.createElement("div");
      this.highlightTag.className = "sharedom-highlight-tag";
      this.tagNameEl = document.createElement("span");
      this.tagNameEl.className = "sharedom-tag-name";
      this.tagClassEl = document.createElement("span");
      this.tagClassEl.className = "sharedom-tag-class";
      this.tagSizeEl = document.createElement("span");
      this.tagSizeEl.className = "sharedom-tag-size";
      this.highlightTag.appendChild(this.tagNameEl);
      this.highlightTag.appendChild(this.tagClassEl);
      this.highlightTag.appendChild(this.tagSizeEl);
      this.highlightBox.appendChild(this.highlightTag);
      this.shadow.appendChild(this.highlightBox);
    }
    createToastContainer() {
      if (!this.shadow) return;
      this.toastContainer = document.createElement("div");
      this.toastContainer.className = "sharedom-toast-container";
      this.shadow.appendChild(this.toastContainer);
    }
    showStatusPill(onClose, language = this.language) {
      if (!this.shadow) return;
      this.language = language;
      const t = translations[this.language].overlay;
      if (this.statusPill) {
        this.statusPill.remove();
      }
      this.statusPill = document.createElement("div");
      this.statusPill.className = "sharedom-status-pill";
      const dot = document.createElement("div");
      dot.className = "sharedom-status-dot";
      const title = document.createElement("span");
      title.className = "sharedom-status-title";
      title.textContent = t.title;
      const promptText = document.createElement("span");
      promptText.style.color = "#a1a1aa";
      promptText.textContent = t.prompt;
      const shortcutGroup = document.createElement("div");
      shortcutGroup.className = "sharedom-shortcut-group";
      const kbdParent = document.createElement("span");
      kbdParent.className = "sharedom-kbd";
      kbdParent.textContent = t.parent;
      const kbdCapture = document.createElement("span");
      kbdCapture.className = "sharedom-kbd";
      kbdCapture.textContent = t.capture;
      const kbdEsc = document.createElement("span");
      kbdEsc.className = "sharedom-kbd";
      kbdEsc.textContent = t.exit;
      shortcutGroup.appendChild(kbdParent);
      shortcutGroup.appendChild(kbdCapture);
      shortcutGroup.appendChild(kbdEsc);
      const closeBtn = document.createElement("button");
      closeBtn.className = "sharedom-close-pill-btn";
      closeBtn.setAttribute("title", `${t.exit}`);
      closeBtn.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    `;
      closeBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        onClose();
      });
      this.statusPill.appendChild(dot);
      this.statusPill.appendChild(title);
      this.statusPill.appendChild(promptText);
      this.statusPill.appendChild(shortcutGroup);
      this.statusPill.appendChild(closeBtn);
      this.shadow.appendChild(this.statusPill);
    }
    hideStatusPill() {
      if (this.statusPill) {
        this.statusPill.remove();
        this.statusPill = null;
      }
    }
    showHighlight(element) {
      if (!this.highlightBox || !this.highlightTag || !this.tagNameEl || !this.tagClassEl || !this.tagSizeEl) {
        return;
      }
      const rect = element.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) {
        this.hideHighlight();
        return;
      }
      this.highlightBox.style.top = `${rect.top}px`;
      this.highlightBox.style.left = `${rect.left}px`;
      this.highlightBox.style.width = `${rect.width}px`;
      this.highlightBox.style.height = `${rect.height}px`;
      this.highlightBox.classList.remove("sharedom-hidden");
      const tagName = element.tagName.toLowerCase();
      this.tagNameEl.textContent = tagName;
      let classDesc = "";
      if (element.id) {
        classDesc += `#${element.id}`;
      }
      if (element.classList && element.classList.length > 0) {
        const classes = Array.from(element.classList).slice(0, 2).map((c) => `.${c}`).join("");
        classDesc += classes;
      }
      this.tagClassEl.textContent = classDesc;
      const width = Math.round(rect.width);
      const height = Math.round(rect.height);
      this.tagSizeEl.textContent = `${width} \xD7 ${height}`;
      if (rect.top < 32) {
        this.highlightTag.classList.add("flipped-down");
      } else {
        this.highlightTag.classList.remove("flipped-down");
      }
    }
    hideHighlight() {
      if (this.highlightBox) {
        this.highlightBox.classList.add("sharedom-hidden");
      }
    }
    showToast(message, icon = "\u2713") {
      if (!this.toastContainer) return;
      const toast = document.createElement("div");
      toast.className = "sharedom-toast";
      const iconSpan = document.createElement("span");
      iconSpan.style.color = "#38bdf8";
      iconSpan.style.fontWeight = "700";
      iconSpan.textContent = icon;
      const msgSpan = document.createElement("span");
      msgSpan.textContent = message;
      toast.appendChild(iconSpan);
      toast.appendChild(msgSpan);
      this.toastContainer.appendChild(toast);
      setTimeout(() => {
        toast.style.transition = "opacity 0.25s ease, transform 0.25s ease";
        toast.style.opacity = "0";
        toast.style.transform = "translateY(12px)";
        setTimeout(() => toast.remove(), 260);
      }, 2400);
    }
    getShadowRoot() {
      return this.shadow;
    }
    getHostElement() {
      return this.host;
    }
    destroy() {
      if (this.host && this.host.parentNode) {
        this.host.remove();
      }
      this.host = null;
      this.shadow = null;
      this.statusPill = null;
      this.highlightBox = null;
      this.toastContainer = null;
    }
  };

  // src/dom.ts
  function resolveElement(target) {
    if (typeof document === "undefined") {
      throw new Error(
        '[sharedom]: DOM operations require a browser environment (document is undefined). For server-side rendering (SSR/Node.js), use the "sharedom/ssr" module.'
      );
    }
    if (typeof target === "string") {
      const element = document.querySelector(target);
      if (!element) {
        throw new Error(`[sharedom]: No element found matching selector "${target}".`);
      }
      return element;
    }
    if (typeof HTMLElement !== "undefined" && target instanceof HTMLElement) {
      return target;
    }
    throw new Error("[sharedom]: Target must be a valid CSS selector string or an HTMLElement.");
  }
  function validateElementDimensions(element) {
    const rect = element.getBoundingClientRect();
    const width = Math.round(rect.width);
    const height = Math.round(rect.height);
    if (width <= 0 || height <= 0) {
      throw new Error("[sharedom]: Cannot capture element with width or height of 0. Ensure the element is visible in the DOM.");
    }
    return { width, height };
  }
  function validateOptions(options) {
    if (options.scale !== void 0 && (typeof options.scale !== "number" || options.scale <= 0)) {
      throw new Error("[sharedom]: Scale option must be a positive number.");
    }
    if (options.quality !== void 0 && (typeof options.quality !== "number" || options.quality < 0 || options.quality > 1)) {
      throw new Error("[sharedom]: Quality option must be a number between 0 and 1.");
    }
    if (options.format !== void 0 && options.format !== "png" && options.format !== "jpeg" && options.format !== "webp") {
      throw new Error('[sharedom]: Format option must be "png", "jpeg", or "webp".');
    }
  }
  function syncDynamicStates(source, target) {
    if (typeof HTMLInputElement !== "undefined" && source instanceof HTMLInputElement && target instanceof HTMLInputElement) {
      target.setAttribute("value", source.value);
      target.value = source.value;
      if (source.checked) {
        target.setAttribute("checked", "");
        target.checked = true;
      }
    } else if (typeof HTMLTextAreaElement !== "undefined" && source instanceof HTMLTextAreaElement && target instanceof HTMLTextAreaElement) {
      target.textContent = source.value;
      target.value = source.value;
    } else if (typeof HTMLSelectElement !== "undefined" && source instanceof HTMLSelectElement && target instanceof HTMLSelectElement) {
      target.value = source.value;
      const targetOptions = target.querySelectorAll("option");
      const selectedIndex = source.selectedIndex;
      if (selectedIndex >= 0 && targetOptions[selectedIndex]) {
        targetOptions[selectedIndex].setAttribute("selected", "true");
      }
    } else if (typeof HTMLCanvasElement !== "undefined" && source instanceof HTMLCanvasElement && target instanceof HTMLCanvasElement) {
      try {
        const dataUrl = source.toDataURL();
        const image = new Image();
        image.src = dataUrl;
        target.replaceWith(image);
      } catch {
      }
    }
    const sourceChildren = Array.from(source.children);
    const targetChildren = Array.from(target.children);
    for (let i = 0; i < sourceChildren.length; i++) {
      if (targetChildren[i]) {
        syncDynamicStates(sourceChildren[i], targetChildren[i]);
      }
    }
  }

  // src/styles.ts
  function cloneComputedStyles(source, target) {
    const sourceStyles = window.getComputedStyle(source);
    const targetElement = target;
    for (let i = 0; i < sourceStyles.length; i++) {
      const key = sourceStyles[i];
      const value = sourceStyles.getPropertyValue(key);
      const priority = sourceStyles.getPropertyPriority(key);
      targetElement.style.setProperty(key, value, priority);
    }
    const sourceChildren = Array.from(source.children);
    const targetChildren = Array.from(target.children);
    for (let i = 0; i < sourceChildren.length; i++) {
      if (targetChildren[i]) {
        cloneComputedStyles(sourceChildren[i], targetChildren[i]);
      }
    }
  }
  function getDocumentFontStyles() {
    let fontStyles = "";
    const linkElements = Array.from(document.querySelectorAll('link[rel="stylesheet"]'));
    for (const link of linkElements) {
      if (link.href) {
        fontStyles += `@import url('${link.href}');
`;
      }
    }
    try {
      const sheets = Array.from(document.styleSheets);
      for (const sheet of sheets) {
        try {
          const rules = Array.from(sheet.cssRules || []);
          for (const rule of rules) {
            if (rule instanceof CSSFontFaceRule) {
              fontStyles += rule.cssText + "\n";
            }
          }
        } catch {
          continue;
        }
      }
    } catch {
    }
    return fontStyles;
  }

  // src/images.ts
  async function fetchUrlAsDataUrl(url) {
    if (!url || url.startsWith("data:")) {
      return url;
    }
    try {
      const response = await fetch(url, { mode: "cors" });
      if (response.ok) {
        const blob = await response.blob();
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            resolve(typeof reader.result === "string" ? reader.result : url);
          };
          reader.onerror = () => {
            resolve(url);
          };
          reader.readAsDataURL(blob);
        });
      }
    } catch {
    }
    try {
      const anonymousDataUrl = await new Promise((resolve, reject) => {
        const temp = new Image();
        temp.crossOrigin = "anonymous";
        temp.onload = () => {
          try {
            const canvas = document.createElement("canvas");
            canvas.width = temp.naturalWidth;
            canvas.height = temp.naturalHeight;
            const ctx = canvas.getContext("2d");
            if (!ctx) return reject();
            ctx.drawImage(temp, 0, 0);
            resolve(canvas.toDataURL("image/png"));
          } catch (e) {
            reject(e);
          }
        };
        temp.onerror = reject;
        temp.src = url;
      });
      if (anonymousDataUrl && anonymousDataUrl.startsWith("data:")) {
        return anonymousDataUrl;
      }
    } catch {
    }
    return url;
  }
  async function fetchImageAsDataUrl(img) {
    const url = img.currentSrc || img.src || img.getAttribute("src") || "";
    if (!url || url.startsWith("data:")) {
      return url;
    }
    const fetched = await fetchUrlAsDataUrl(url);
    if (fetched && fetched.startsWith("data:")) {
      return fetched;
    }
    if (img.complete && img.naturalWidth > 0 && img.naturalHeight > 0) {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          return canvas.toDataURL("image/png");
        }
      } catch {
      }
    }
    return url;
  }
  async function inlineImages(rootElement) {
    const images = Array.from(rootElement.querySelectorAll("img"));
    const originalSources = /* @__PURE__ */ new Map();
    const inliningPromises = images.map(async (img) => {
      const originalSrc = img.getAttribute("src") || "";
      const originalSrcset = img.getAttribute("srcset") || void 0;
      originalSources.set(img, { src: originalSrc, srcset: originalSrcset });
      const dataUrl = await fetchImageAsDataUrl(img);
      if (dataUrl && dataUrl.startsWith("data:")) {
        img.removeAttribute("srcset");
        img.removeAttribute("sizes");
        img.setAttribute("src", dataUrl);
      }
    });
    const svgImages = Array.from(rootElement.querySelectorAll("image"));
    const svgPromises = svgImages.map(async (svgImg) => {
      const href = svgImg.getAttribute("href") || svgImg.getAttribute("xlink:href") || "";
      if (href && !href.startsWith("data:")) {
        const dataUrl = await fetchUrlAsDataUrl(href);
        if (dataUrl && dataUrl.startsWith("data:")) {
          svgImg.setAttribute("href", dataUrl);
          if (svgImg.hasAttribute("xlink:href")) {
            svgImg.setAttribute("xlink:href", dataUrl);
          }
        }
      }
    });
    const allElements = [rootElement, ...Array.from(rootElement.querySelectorAll("*"))];
    const bgPromises = allElements.map(async (el) => {
      const bg = el.style.backgroundImage || window.getComputedStyle(el).backgroundImage;
      if (!bg || bg === "none") return;
      const match = bg.match(/url\(["']?(https?:\/\/[^"')]+)["']?\)/i);
      if (match && match[1]) {
        const bgUrl = match[1];
        const dataUrl = await fetchUrlAsDataUrl(bgUrl);
        if (dataUrl && dataUrl.startsWith("data:")) {
          el.style.backgroundImage = `url("${dataUrl}")`;
        }
      }
    });
    await Promise.all([...inliningPromises, ...svgPromises, ...bgPromises]);
    return () => {
      originalSources.clear();
    };
  }

  // src/svg.ts
  function createSvgDataUrl(element, width, height) {
    const serializedHtml = new XMLSerializer().serializeToString(element);
    const fontStyles = getDocumentFontStyles();
    const styleBlock = fontStyles ? `<style><![CDATA[
${fontStyles}
]]></style>` : "";
    const svgString = `
    <svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
      <foreignObject width="100%" height="100%">
        <div xmlns="http://www.w3.org/1999/xhtml" style="width:100%;height:100%;">
          ${styleBlock}
          ${serializedHtml}
        </div>
      </foreignObject>
    </svg>
  `;
    return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgString)}`;
  }

  // src/optimizer.ts
  function optimizeCanvasPixels(context, width, height) {
    const imageData = context.getImageData(0, 0, width, height);
    const data = imageData.data;
    const pixelView = new Uint32Array(data.buffer);
    const length = pixelView.length;
    let hasModifications = false;
    for (let i = 0; i < length; i++) {
      if ((pixelView[i] & 4278190080) === 0 && pixelView[i] !== 0) {
        pixelView[i] = 0;
        hasModifications = true;
      }
    }
    if (hasModifications) {
      context.putImageData(imageData, 0, 0);
    }
  }
  function optimizeDataUrl(dataUrl) {
    const commaIndex = dataUrl.indexOf(",");
    if (commaIndex === -1) {
      return dataUrl;
    }
    const header = dataUrl.slice(0, commaIndex);
    const base64Payload = dataUrl.slice(commaIndex + 1).trim();
    return `${header},${base64Payload}`;
  }
  function exportOptimizedCanvas(canvas, context, format = "png", quality = 0.92) {
    optimizeCanvasPixels(context, canvas.width, canvas.height);
    const mimeType = format === "jpeg" ? "image/jpeg" : format === "webp" ? "image/webp" : "image/png";
    const rawDataUrl = canvas.toDataURL(mimeType, quality);
    return optimizeDataUrl(rawDataUrl);
  }

  // src/canvas.ts
  function renderSvgToCanvas(svgDataUrl, width, height, options) {
    const { scale = 1, backgroundColor, quality = 0.92, format = "png", optimize = true } = options;
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(width * scale);
        canvas.height = Math.round(height * scale);
        const context = canvas.getContext("2d", { willReadFrequently: true });
        if (!context) {
          return reject(new Error("[sharedom]: Could not obtain 2D canvas context."));
        }
        context.imageSmoothingEnabled = true;
        context.imageSmoothingQuality = "high";
        context.scale(scale, scale);
        if (backgroundColor) {
          context.fillStyle = backgroundColor;
          context.fillRect(0, 0, width, height);
        }
        context.drawImage(image, 0, 0);
        try {
          if (optimize) {
            const dataUrl = exportOptimizedCanvas(canvas, context, format, quality);
            resolve(dataUrl);
          } else {
            const mimeType = format === "jpeg" ? "image/jpeg" : format === "webp" ? "image/webp" : "image/png";
            const dataUrl = canvas.toDataURL(mimeType, quality);
            resolve(dataUrl);
          }
        } catch (error) {
          reject(new Error(`[sharedom]: Failed to export canvas image. ${error}`));
        }
      };
      image.onerror = (error) => {
        reject(new Error(`[sharedom]: Failed to load rendered SVG image. ${error}`));
      };
      image.src = svgDataUrl;
    });
  }

  // src/tracker.ts
  var MAX_ENTRIES = 200;
  var isConsoleListening = false;
  var capturedLogs = [];
  var originalLog = null;
  var originalInfo = null;
  var originalWarn = null;
  var originalError = null;
  var originalDebug = null;
  function safeStringify(arg) {
    if (arg === null) return "null";
    if (arg === void 0) return "undefined";
    if (typeof arg === "string") return arg;
    if (typeof arg === "number" || typeof arg === "boolean" || typeof arg === "symbol") {
      return String(arg);
    }
    if (arg instanceof Error) {
      return `${arg.name}: ${arg.message}`;
    }
    if (typeof arg === "object") {
      try {
        const seen = /* @__PURE__ */ new WeakSet();
        return JSON.stringify(arg, (_key, val) => {
          if (typeof val === "object" && val !== null) {
            if (seen.has(val)) return "[Circular]";
            seen.add(val);
          }
          return val;
        });
      } catch {
        return Object.prototype.toString.call(arg);
      }
    }
    return String(arg);
  }
  function formatTrackerArgs(args) {
    if (args.length === 0) return "";
    const first = args[0];
    if (typeof first === "string" && first.includes("%c")) {
      let text = first.replace(/%c/g, "").trim();
      const nonCssArgs = [];
      for (let i = 1; i < args.length; i++) {
        const a = args[i];
        if (typeof a === "string" && (a.includes(":") || a.includes("color") || a.includes("font") || a.includes("background"))) {
          continue;
        }
        nonCssArgs.push(a);
      }
      if (nonCssArgs.length > 0) {
        text += " " + nonCssArgs.map(safeStringify).join(" ");
      }
      return text;
    }
    return args.map(safeStringify).join(" ");
  }
  function pushLog(level, args) {
    const message = formatTrackerArgs(args);
    const last = capturedLogs[capturedLogs.length - 1];
    if (last && last.level === level && last.message === message) {
      last.count = (last.count || 1) + 1;
      last.timestamp = Date.now();
      return;
    }
    if (capturedLogs.length >= MAX_ENTRIES) {
      capturedLogs.shift();
    }
    capturedLogs.push({
      level,
      message,
      timestamp: Date.now(),
      count: 1
    });
  }
  var originalErrorHandler = null;
  var originalRejectionHandler = null;
  function startConsoleCapture() {
    if (typeof window === "undefined" || typeof console === "undefined") {
      return () => {
      };
    }
    if (isConsoleListening) {
      return stopConsoleCapture;
    }
    isConsoleListening = true;
    originalLog = console.log;
    originalInfo = console.info;
    originalWarn = console.warn;
    originalError = console.error;
    originalDebug = console.debug;
    console.log = (...args) => {
      pushLog("log", args);
      originalLog?.apply(console, args);
    };
    console.info = (...args) => {
      pushLog("info", args);
      originalInfo?.apply(console, args);
    };
    console.warn = (...args) => {
      pushLog("warn", args);
      originalWarn?.apply(console, args);
    };
    console.error = (...args) => {
      pushLog("error", args);
      originalError?.apply(console, args);
    };
    console.debug = (...args) => {
      pushLog("debug", args);
      originalDebug?.apply(console, args);
    };
    originalErrorHandler = (event) => {
      try {
        const err = event.error;
        const message = err ? err.stack || `${err.name || "Error"}: ${err.message || event.message}` : event.message || "Script error";
        if (message) {
          pushLog("error", [message]);
        }
      } catch {
      }
    };
    originalRejectionHandler = (event) => {
      try {
        const reason = event.reason;
        const message = reason instanceof Error ? reason.stack || `${reason.name}: ${reason.message}` : typeof reason === "object" && reason !== null ? safeStringify(reason) : String(reason);
        if (message) {
          pushLog("error", [`Unhandled Rejection: ${message}`]);
        }
      } catch {
      }
    };
    window.addEventListener("error", originalErrorHandler, true);
    window.addEventListener("unhandledrejection", originalRejectionHandler, true);
    return stopConsoleCapture;
  }
  function stopConsoleCapture() {
    if (!isConsoleListening) return;
    if (originalLog) console.log = originalLog;
    if (originalInfo) console.info = originalInfo;
    if (originalWarn) console.warn = originalWarn;
    if (originalError) console.error = originalError;
    if (originalDebug) console.debug = originalDebug;
    originalLog = null;
    originalInfo = null;
    originalWarn = null;
    originalError = null;
    originalDebug = null;
    if (originalErrorHandler) {
      window.removeEventListener("error", originalErrorHandler, true);
      originalErrorHandler = null;
    }
    if (originalRejectionHandler) {
      window.removeEventListener("unhandledrejection", originalRejectionHandler, true);
      originalRejectionHandler = null;
    }
    isConsoleListening = false;
  }
  function getConsoleLogs() {
    return [...capturedLogs];
  }
  var isNetworkListening = false;
  var capturedRequests = [];
  var originalFetch = null;
  var originalXhrOpen = null;
  var originalXhrSend = null;
  function extractEndpointName(urlStr) {
    try {
      const parsed = new URL(urlStr, typeof window !== "undefined" ? window.location.href : "http://localhost");
      const path = parsed.pathname;
      if (!path || path === "/") {
        return parsed.host || urlStr;
      }
      return path + (parsed.search ? parsed.search : "");
    } catch {
      return urlStr;
    }
  }
  function pushRequest(entry) {
    if (capturedRequests.length >= MAX_ENTRIES) {
      capturedRequests.shift();
    }
    capturedRequests.push(entry);
  }
  function startNetworkCapture() {
    if (typeof window === "undefined") {
      return () => {
      };
    }
    if (isNetworkListening) {
      return stopNetworkCapture;
    }
    isNetworkListening = true;
    if (typeof window.fetch === "function") {
      originalFetch = window.fetch;
      window.fetch = async (...args) => {
        const start = performance.now();
        const input = args[0];
        const init = args[1];
        let url = "";
        let method = (init?.method || "GET").toUpperCase();
        if (typeof input === "string") {
          url = input;
        } else if (input instanceof URL) {
          url = input.href;
        } else if (input && typeof input === "object" && "url" in input) {
          url = input.url;
          if (!init?.method && input.method) {
            method = input.method.toUpperCase();
          }
        }
        const timestamp = Date.now();
        const name = extractEndpointName(url);
        try {
          const response = await originalFetch.apply(window, args);
          const duration = Math.round(performance.now() - start);
          pushRequest({
            method,
            url,
            name,
            status: response.status,
            statusText: response.statusText || (response.ok ? "OK" : ""),
            type: "fetch",
            duration,
            timestamp
          });
          return response;
        } catch (err) {
          const duration = Math.round(performance.now() - start);
          pushRequest({
            method,
            url,
            name,
            status: 0,
            statusText: "Failed",
            type: "fetch",
            duration,
            timestamp
          });
          throw err;
        }
      };
    }
    if (typeof XMLHttpRequest !== "undefined") {
      originalXhrOpen = XMLHttpRequest.prototype.open;
      originalXhrSend = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open = function(method, url, ...rest) {
        this.__sharedom_meta = {
          method: String(method).toUpperCase(),
          url: typeof url === "string" ? url : url.href
        };
        return originalXhrOpen.apply(this, [method, url, ...rest]);
      };
      XMLHttpRequest.prototype.send = function(...args) {
        const meta = this.__sharedom_meta;
        if (meta) {
          const start = performance.now();
          const timestamp = Date.now();
          this.addEventListener("loadend", () => {
            const duration = Math.round(performance.now() - start);
            const name = extractEndpointName(meta.url);
            pushRequest({
              method: meta.method || "GET",
              url: meta.url,
              name,
              status: this.status,
              statusText: this.statusText,
              type: "xhr",
              duration,
              timestamp
            });
          });
        }
        return originalXhrSend.apply(this, args);
      };
    }
    return stopNetworkCapture;
  }
  function stopNetworkCapture() {
    if (!isNetworkListening) return;
    if (originalFetch && typeof window !== "undefined") {
      window.fetch = originalFetch;
      originalFetch = null;
    }
    if (originalXhrOpen && typeof XMLHttpRequest !== "undefined") {
      XMLHttpRequest.prototype.open = originalXhrOpen;
      originalXhrOpen = null;
    }
    if (originalXhrSend && typeof XMLHttpRequest !== "undefined") {
      XMLHttpRequest.prototype.send = originalXhrSend;
      originalXhrSend = null;
    }
    isNetworkListening = false;
  }
  function getNetworkRequests() {
    if (capturedRequests.length > 0) {
      return [...capturedRequests];
    }
    if (typeof window !== "undefined" && typeof window.performance?.getEntriesByType === "function") {
      try {
        const resources = window.performance.getEntriesByType("resource");
        if (resources.length > 0) {
          return resources.slice(-MAX_ENTRIES).map((res) => {
            const statusVal = res.responseStatus;
            return {
              method: "GET",
              url: res.name,
              name: extractEndpointName(res.name),
              status: statusVal !== void 0 && statusVal !== 0 ? statusVal : 200,
              statusText: statusVal ? `HTTP ${statusVal}` : "OK",
              type: res.initiatorType || "resource",
              duration: Math.round(res.duration),
              timestamp: Math.round(performance.timeOrigin + res.startTime)
            };
          });
        }
      } catch {
      }
    }
    return [];
  }

  // src/i18n.ts
  var currentLibraryLanguage = "en";
  var tableTranslations = {
    en: {
      consoleTitle: "Console Logs",
      networkTitle: "Network Requests",
      colIndex: "#",
      colLevel: "Level",
      colMessage: "Message",
      colTime: "Time",
      colMethod: "Method",
      colNameUrl: "Name / URL",
      colStatus: "Status",
      colType: "Type",
      colDuration: "Duration",
      emptyConsole: "No console logs recorded",
      emptyNetwork: "No network requests recorded",
      totalLogs: "logs",
      errors: "errors",
      warnings: "warnings",
      totalRequests: "requests",
      success: "success",
      failed: "failed",
      watermark: "sharedom",
      page: "Page",
      of: "of"
    },
    es: {
      consoleTitle: "Registros de Consola",
      networkTitle: "Peticiones de Red",
      colIndex: "#",
      colLevel: "Nivel",
      colMessage: "Mensaje",
      colTime: "Hora",
      colMethod: "M\xE9todo",
      colNameUrl: "Nombre / URL",
      colStatus: "Estado",
      colType: "Tipo",
      colDuration: "Duraci\xF3n",
      emptyConsole: "No hay registros de consola grabados",
      emptyNetwork: "No hay peticiones de red grabadas",
      totalLogs: "registros",
      errors: "errores",
      warnings: "advertencias",
      totalRequests: "peticiones",
      success: "\xE9xito",
      failed: "fallidas",
      watermark: "sharedom",
      page: "P\xE1gina",
      of: "de"
    }
  };
  function getTranslations(lang) {
    const selected = lang || currentLibraryLanguage;
    return tableTranslations[selected] || tableTranslations.en;
  }

  // src/renderer.ts
  function formatTime(timestamp) {
    const d = new Date(timestamp);
    const h = String(d.getHours()).padStart(2, "0");
    const m = String(d.getMinutes()).padStart(2, "0");
    const s = String(d.getSeconds()).padStart(2, "0");
    const ms = String(d.getMilliseconds()).padStart(3, "0");
    return `${h}:${m}:${s}.${ms}`;
  }
  function formatDateHeader(timestamp) {
    const d = new Date(timestamp);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    const h = String(d.getHours()).padStart(2, "0");
    const m = String(d.getMinutes()).padStart(2, "0");
    const s = String(d.getSeconds()).padStart(2, "0");
    return `${year}-${month}-${day} ${h}:${m}:${s}`;
  }
  function escapeHtml(str2) {
    return str2.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }
  var BASE_STYLES = `
.sharedom-card {
    box-sizing: border-box;
    width: 880px;
    background: linear-gradient(180deg, #0f172a 0%, #090d16 100%);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 16px;
    padding: 24px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    color: #e2e8f0;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    position: relative;
    overflow: hidden;
}
.sharedom-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
    padding-bottom: 16px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}
.sharedom-header-left {
    display: flex;
    align-items: center;
    gap: 12px;
}
.sharedom-icon-box {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, rgba(167, 139, 250, 0.2), rgba(124, 58, 237, 0.3));
    border: 1px solid rgba(167, 139, 250, 0.3);
}
.sharedom-title {
    font-size: 18px;
    font-weight: 700;
    color: #f8fafc;
    letter-spacing: -0.02em;
    margin: 0;
    line-height: 1.2;
}
.sharedom-subtitle {
    font-size: 12px;
    color: #94a3b8;
    margin: 3px 0 0 0;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}
.sharedom-header-right {
    display: flex;
    align-items: center;
    gap: 8px;
}
.sharedom-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 10px;
    border-radius: 9999px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.02em;
    line-height: 1;
}
.sharedom-badge-neutral {
    background: rgba(148, 163, 184, 0.12);
    color: #cbd5e1;
    border: 1px solid rgba(148, 163, 184, 0.2);
}
.sharedom-badge-success {
    background: rgba(16, 185, 129, 0.12);
    color: #34d399;
    border: 1px solid rgba(16, 185, 129, 0.25);
}
.sharedom-badge-warning {
    background: rgba(245, 158, 11, 0.12);
    color: #fbbf24;
    border: 1px solid rgba(245, 158, 11, 0.25);
}
.sharedom-badge-danger {
    background: rgba(244, 63, 94, 0.12);
    color: #fb7185;
    border: 1px solid rgba(244, 63, 94, 0.25);
}
.sharedom-badge-info {
    background: rgba(56, 189, 248, 0.12);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.25);
}
.sharedom-badge-brand {
    background: linear-gradient(135deg, rgba(167, 139, 250, 0.25), rgba(124, 58, 237, 0.35));
    color: #c4b5fd;
    border: 1px solid rgba(167, 139, 250, 0.4);
    font-weight: 700;
}
.sharedom-table-wrap {
    width: 100%;
    overflow-x: hidden;
}
.sharedom-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 4px;
    font-size: 12px;
}
.sharedom-table th {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: #94a3b8;
    padding: 8px 12px;
    text-align: left;
    background: rgba(255, 255, 255, 0.03);
}
.sharedom-table th:first-child {
    border-top-left-radius: 8px;
    border-bottom-left-radius: 8px;
}
.sharedom-table th:last-child {
    border-top-right-radius: 8px;
    border-bottom-right-radius: 8px;
}
.sharedom-table td {
    padding: 9px 12px;
    background: rgba(255, 255, 255, 0.02);
    border-top: 1px solid rgba(255, 255, 255, 0.03);
    border-bottom: 1px solid rgba(255, 255, 255, 0.03);
    vertical-align: middle;
}
.sharedom-table tr:hover td {
    background: rgba(255, 255, 255, 0.04);
}
.sharedom-table td:first-child {
    border-top-left-radius: 8px;
    border-bottom-left-radius: 8px;
    border-left: 1px solid rgba(255, 255, 255, 0.03);
    color: #64748b;
    font-family: ui-monospace, monospace;
    font-size: 11px;
    text-align: center;
    width: 32px;
}
.sharedom-table td:last-child {
    border-top-right-radius: 8px;
    border-bottom-right-radius: 8px;
    border-right: 1px solid rgba(255, 255, 255, 0.03);
}
.sharedom-pill {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.03em;
    text-align: center;
    line-height: 1.2;
}
.sharedom-mono {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}
.sharedom-msg {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 12px;
    color: #f1f5f9;
    word-break: break-word;
    white-space: pre-wrap;
    line-height: 1.45;
}
.sharedom-count-bubble {
    display: inline-block;
    margin-left: 6px;
    padding: 1px 6px;
    border-radius: 9999px;
    background: rgba(255, 255, 255, 0.1);
    color: #cbd5e1;
    font-size: 10px;
    font-weight: 700;
}
.sharedom-empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 48px 24px;
    background: rgba(255, 255, 255, 0.015);
    border: 1px dashed rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    color: #94a3b8;
    text-align: center;
}
.sharedom-empty-icon {
    margin-bottom: 12px;
    opacity: 0.7;
}
`;
  function chunkItems(items, size) {
    if (!items || items.length === 0) return [[]];
    if (size <= 0 || items.length <= size) return [items];
    const chunks = [];
    for (let i = 0; i < items.length; i += size) {
      chunks.push(items.slice(i, i + size));
    }
    return chunks;
  }
  function createConsoleLogsElement(logs = [], options) {
    const t = getTranslations(options?.language);
    const max = options?.maxEntries || 100;
    const sliced = logs.slice(-max);
    let errorCount = 0;
    let warnCount = 0;
    let infoCount = 0;
    sliced.forEach((l) => {
      if (l.level === "error") errorCount += l.count || 1;
      else if (l.level === "warn") warnCount += l.count || 1;
      else infoCount += l.count || 1;
    });
    const totalLogs = errorCount + warnCount + infoCount;
    const now = Date.now();
    const container = document.createElement("div");
    container.className = "sharedom-card";
    const styleEl = document.createElement("style");
    styleEl.textContent = BASE_STYLES;
    container.appendChild(styleEl);
    const header = document.createElement("div");
    header.className = "sharedom-header";
    header.innerHTML = `
        <div class="sharedom-header-left">
            <div class="sharedom-icon-box">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="4 17 10 11 4 5"></polyline>
                    <line x1="12" y1="19" x2="20" y2="19"></line>
                </svg>
            </div>
            <div>
                <h3 class="sharedom-title">${escapeHtml(options?.title || t.consoleTitle)}</h3>
                <div class="sharedom-subtitle">${formatDateHeader(now)}</div>
            </div>
        </div>
        <div class="sharedom-header-right">
            ${options?.totalPages && options.totalPages > 1 ? `<span class="sharedom-badge" style="background: rgba(167, 139, 250, 0.15); color: #c4b5fd; border: 1px solid rgba(167, 139, 250, 0.3); font-weight: 600;">${t.page} ${options.pageIndex || 1} / ${options.totalPages}</span>` : ""}
            <span class="sharedom-badge sharedom-badge-neutral">${options?.totalItems || totalLogs} ${t.totalLogs}</span>
            ${errorCount > 0 ? `<span class="sharedom-badge sharedom-badge-danger">${errorCount} ${t.errors}</span>` : ""}
            ${warnCount > 0 ? `<span class="sharedom-badge sharedom-badge-warning">${warnCount} ${t.warnings}</span>` : ""}
            <span class="sharedom-badge sharedom-badge-brand">${t.watermark}</span>
        </div>
    `;
    container.appendChild(header);
    if (sliced.length === 0) {
      const empty = document.createElement("div");
      empty.className = "sharedom-empty-state";
      empty.innerHTML = `
            <div class="sharedom-empty-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="8" x2="12" y2="12"></line>
                    <line x1="12" y1="16" x2="12.01" y2="16"></line>
                </svg>
            </div>
            <div style="font-size: 14px; font-weight: 500;">${t.emptyConsole}</div>
        `;
      container.appendChild(empty);
      return container;
    }
    const tableWrap = document.createElement("div");
    tableWrap.className = "sharedom-table-wrap";
    let rowsHtml = "";
    sliced.forEach((log, index) => {
      let pillClass = "sharedom-badge-neutral";
      const levelUpper = log.level.toUpperCase();
      if (log.level === "error") pillClass = "sharedom-badge-danger";
      else if (log.level === "warn") pillClass = "sharedom-badge-warning";
      else if (log.level === "info") pillClass = "sharedom-badge-info";
      const countBubble = log.count && log.count > 1 ? `<span class="sharedom-count-bubble">\xD7${log.count}</span>` : "";
      const rowNum = (options?.startIndex || 0) + index + 1;
      rowsHtml += `
            <tr>
                <td>${rowNum}</td>
                <td style="width: 76px;">
                    <span class="sharedom-pill ${pillClass}">${levelUpper}</span>
                </td>
                <td>
                    <div class="sharedom-msg">${escapeHtml(log.message)}${countBubble}</div>
                </td>
                <td class="sharedom-mono" style="width: 90px; text-align: right; color: #64748b; font-size: 11px;">
                    ${formatTime(log.timestamp)}
                </td>
            </tr>
        `;
    });
    tableWrap.innerHTML = `
        <table class="sharedom-table">
            <thead>
                <tr>
                    <th style="width: 32px; text-align: center;">${t.colIndex}</th>
                    <th style="width: 76px;">${t.colLevel}</th>
                    <th>${t.colMessage}</th>
                    <th style="width: 90px; text-align: right;">${t.colTime}</th>
                </tr>
            </thead>
            <tbody>
                ${rowsHtml}
            </tbody>
        </table>
    `;
    container.appendChild(tableWrap);
    return container;
  }
  function createNetworkRequestsElement(requests = [], options) {
    const t = getTranslations(options?.language);
    const max = options?.maxEntries || 100;
    const sliced = requests.slice(-max);
    let successCount = 0;
    let failedCount = 0;
    sliced.forEach((r) => {
      const numStatus = Number(r.status);
      if (numStatus >= 200 && numStatus < 400) {
        successCount++;
      } else {
        failedCount++;
      }
    });
    const totalRequests = sliced.length;
    const now = Date.now();
    const container = document.createElement("div");
    container.className = "sharedom-card";
    const styleEl = document.createElement("style");
    styleEl.textContent = BASE_STYLES;
    container.appendChild(styleEl);
    const header = document.createElement("div");
    header.className = "sharedom-header";
    header.innerHTML = `
        <div class="sharedom-header-left">
            <div class="sharedom-icon-box">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="2" y1="12" x2="22" y2="12"></line>
                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                </svg>
            </div>
            <div>
                <h3 class="sharedom-title">${escapeHtml(options?.title || t.networkTitle)}</h3>
                <div class="sharedom-subtitle">${formatDateHeader(now)}</div>
            </div>
        </div>
        <div class="sharedom-header-right">
            ${options?.totalPages && options.totalPages > 1 ? `<span class="sharedom-badge" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); font-weight: 600;">${t.page} ${options.pageIndex || 1} / ${options.totalPages}</span>` : ""}
            <span class="sharedom-badge sharedom-badge-neutral">${options?.totalItems || totalRequests} ${t.totalRequests}</span>
            <span class="sharedom-badge sharedom-badge-success">${successCount} ${t.success}</span>
            ${failedCount > 0 ? `<span class="sharedom-badge sharedom-badge-danger">${failedCount} ${t.failed}</span>` : ""}
            <span class="sharedom-badge sharedom-badge-brand">${t.watermark}</span>
        </div>
    `;
    container.appendChild(header);
    if (sliced.length === 0) {
      const empty = document.createElement("div");
      empty.className = "sharedom-empty-state";
      empty.innerHTML = `
            <div class="sharedom-empty-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="1" y1="1" x2="23" y2="23"></line>
                    <path d="M16.72 11.06A10.94 10.94 0 0 1 19 12.55"></path>
                    <path d="M5 12.55a10.94 10.94 0 0 1 5.17-2.39"></path>
                    <path d="M10.71 5.05A16 16 0 0 1 22.58 9"></path>
                    <path d="M1.42 9a15.91 15.91 0 0 1 4.7-2.88"></path>
                    <path d="M8.53 16.11a6 6 0 0 1 6.95 0"></path>
                    <line x1="12" y1="20" x2="12.01" y2="20"></line>
                </svg>
            </div>
            <div style="font-size: 14px; font-weight: 500;">${t.emptyNetwork}</div>
        `;
      container.appendChild(empty);
      return container;
    }
    const tableWrap = document.createElement("div");
    tableWrap.className = "sharedom-table-wrap";
    let rowsHtml = "";
    sliced.forEach((req, index) => {
      let methodClass = "sharedom-badge-neutral";
      const m = (req.method || "GET").toUpperCase();
      if (m === "GET") methodClass = "sharedom-badge-info";
      else if (m === "POST") methodClass = "sharedom-badge-success";
      else if (m === "PUT") methodClass = "sharedom-badge-warning";
      else if (m === "DELETE") methodClass = "sharedom-badge-danger";
      else if (m === "PATCH") methodClass = "sharedom-badge-brand";
      let statusClass = "sharedom-badge-neutral";
      const numStatus = Number(req.status);
      if (numStatus >= 200 && numStatus < 300) statusClass = "sharedom-badge-success";
      else if (numStatus >= 300 && numStatus < 400) statusClass = "sharedom-badge-info";
      else if (numStatus >= 400 && numStatus < 500) statusClass = "sharedom-badge-warning";
      else if (numStatus >= 500 || numStatus === 0) statusClass = "sharedom-badge-danger";
      const statusDisplay = numStatus > 0 ? `${numStatus} ${req.statusText || ""}`.trim() : req.statusText || "Failed";
      const durationStr = req.duration !== void 0 ? `${req.duration} ms` : "-";
      const rowNum = (options?.startIndex || 0) + index + 1;
      rowsHtml += `
            <tr>
                <td>${rowNum}</td>
                <td style="width: 72px;">
                    <span class="sharedom-pill ${methodClass}">${escapeHtml(m)}</span>
                </td>
                <td>
                    <div style="font-weight: 600; color: #f1f5f9; font-size: 12.5px; margin-bottom: 2px;">
                        ${escapeHtml(req.name)}
                    </div>
                    <div class="sharedom-mono" style="color: #64748b; font-size: 11px; word-break: break-all; max-width: 420px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                        ${escapeHtml(req.url)}
                    </div>
                </td>
                <td style="width: 100px;">
                    <span class="sharedom-pill ${statusClass}">${escapeHtml(statusDisplay)}</span>
                </td>
                <td style="width: 60px; font-size: 11px; color: #94a3b8; text-transform: uppercase;">
                    ${escapeHtml(req.type || "fetch")}
                </td>
                <td class="sharedom-mono" style="width: 70px; text-align: right; color: #cbd5e1; font-size: 11px;">
                    ${durationStr}
                </td>
                <td class="sharedom-mono" style="width: 90px; text-align: right; color: #64748b; font-size: 11px;">
                    ${formatTime(req.timestamp)}
                </td>
            </tr>
        `;
    });
    tableWrap.innerHTML = `
        <table class="sharedom-table">
            <thead>
                <tr>
                    <th style="width: 32px; text-align: center;">${t.colIndex}</th>
                    <th style="width: 72px;">${t.colMethod}</th>
                    <th>${t.colNameUrl}</th>
                    <th style="width: 100px;">${t.colStatus}</th>
                    <th style="width: 60px;">${t.colType}</th>
                    <th style="width: 70px; text-align: right;">${t.colDuration}</th>
                    <th style="width: 90px; text-align: right;">${t.colTime}</th>
                </tr>
            </thead>
            <tbody>
                ${rowsHtml}
            </tbody>
        </table>
    `;
    container.appendChild(tableWrap);
    return container;
  }

  // src/zip-writer.ts
  var CRC_TABLE = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    }
    CRC_TABLE[i] = c;
  }
  function crc32(bytes) {
    let crc = 4294967295;
    for (let i = 0; i < bytes.length; i++) {
      crc = CRC_TABLE[(crc ^ bytes[i]) & 255] ^ crc >>> 8;
    }
    return (crc ^ 4294967295) >>> 0;
  }
  function toDosDateTime(date = /* @__PURE__ */ new Date()) {
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = Math.floor(date.getSeconds() / 2);
    const dosTime = hours << 11 | minutes << 5 | seconds;
    const year = Math.max(1980, date.getFullYear()) - 1980;
    const month = date.getMonth() + 1;
    const day = date.getDate();
    const dosDate = year << 9 | month << 5 | day;
    return { time: dosTime, date: dosDate };
  }
  function normalizeZipData(data) {
    if (data instanceof Uint8Array) {
      return data;
    }
    if (data instanceof ArrayBuffer) {
      return new Uint8Array(data);
    }
    if (typeof data === "string") {
      let base64 = data;
      const commaIndex = data.indexOf(",");
      if (commaIndex !== -1 && data.startsWith("data:")) {
        base64 = data.slice(commaIndex + 1);
      }
      if (typeof atob === "function") {
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        return bytes;
      } else {
        const maybeBuffer = globalThis.Buffer;
        if (maybeBuffer) {
          return new Uint8Array(maybeBuffer.from(base64, "base64"));
        }
      }
    }
    return new Uint8Array(0);
  }
  var textEncoder = new TextEncoder();
  function buildZip(files) {
    const { time: dosTime, date: dosDate } = toDosDateTime(/* @__PURE__ */ new Date());
    const processed = [];
    let totalLocalHeadersSize = 0;
    for (const file of files) {
      const nameBytes = textEncoder.encode(file.name);
      const dataBytes = normalizeZipData(file.data);
      const crc = crc32(dataBytes);
      const localHeaderSize = 30 + nameBytes.length + dataBytes.length;
      processed.push({
        nameBytes,
        dataBytes,
        crc,
        localHeaderOffset: totalLocalHeadersSize
      });
      totalLocalHeadersSize += localHeaderSize;
    }
    let centralDirSize = 0;
    for (const entry of processed) {
      centralDirSize += 46 + entry.nameBytes.length;
    }
    const totalZipSize = totalLocalHeadersSize + centralDirSize + 22;
    const buffer = new Uint8Array(totalZipSize);
    const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
    let offset = 0;
    for (const entry of processed) {
      view.setUint32(offset, 67324752, true);
      view.setUint16(offset + 4, 20, true);
      view.setUint16(offset + 6, 2048, true);
      view.setUint16(offset + 8, 0, true);
      view.setUint16(offset + 10, dosTime, true);
      view.setUint16(offset + 12, dosDate, true);
      view.setUint32(offset + 14, entry.crc, true);
      view.setUint32(offset + 18, entry.dataBytes.length, true);
      view.setUint32(offset + 22, entry.dataBytes.length, true);
      view.setUint16(offset + 26, entry.nameBytes.length, true);
      view.setUint16(offset + 28, 0, true);
      offset += 30;
      buffer.set(entry.nameBytes, offset);
      offset += entry.nameBytes.length;
      buffer.set(entry.dataBytes, offset);
      offset += entry.dataBytes.length;
    }
    const centralDirStartOffset = offset;
    for (const entry of processed) {
      view.setUint32(offset, 33639248, true);
      view.setUint16(offset + 4, 20, true);
      view.setUint16(offset + 6, 20, true);
      view.setUint16(offset + 8, 2048, true);
      view.setUint16(offset + 10, 0, true);
      view.setUint16(offset + 12, dosTime, true);
      view.setUint16(offset + 14, dosDate, true);
      view.setUint32(offset + 16, entry.crc, true);
      view.setUint32(offset + 20, entry.dataBytes.length, true);
      view.setUint32(offset + 24, entry.dataBytes.length, true);
      view.setUint16(offset + 28, entry.nameBytes.length, true);
      view.setUint16(offset + 30, 0, true);
      view.setUint16(offset + 32, 0, true);
      view.setUint16(offset + 34, 0, true);
      view.setUint16(offset + 36, 0, true);
      view.setUint32(offset + 38, 0, true);
      view.setUint32(offset + 42, entry.localHeaderOffset, true);
      offset += 46;
      buffer.set(entry.nameBytes, offset);
      offset += entry.nameBytes.length;
    }
    view.setUint32(offset, 101010256, true);
    view.setUint16(offset + 4, 0, true);
    view.setUint16(offset + 6, 0, true);
    view.setUint16(offset + 8, processed.length, true);
    view.setUint16(offset + 10, processed.length, true);
    view.setUint32(offset + 12, centralDirSize, true);
    view.setUint32(offset + 16, centralDirStartOffset, true);
    view.setUint16(offset + 20, 0, true);
    return buffer;
  }
  function downloadZip(files, filename = "archive.zip") {
    if (typeof document === "undefined") {
      throw new Error("[sharedom]: downloadZip() requires a browser environment.");
    }
    const zipBytes = buildZip(files);
    const blob = new Blob([zipBytes.buffer], { type: "application/zip" });
    const url = URL.createObjectURL(blob);
    try {
      const link = document.createElement("a");
      link.download = filename.endsWith(".zip") ? filename : `${filename}.zip`;
      link.href = url;
      link.click();
    } finally {
      setTimeout(() => URL.revokeObjectURL(url), 1e3);
    }
  }

  // src/pdf-writer.ts
  var PAGE_PRESETS = {
    A4: { width: 595.28, height: 841.89 },
    A3: { width: 841.89, height: 1190.55 },
    A5: { width: 419.53, height: 595.28 },
    Letter: { width: 612, height: 792 },
    Legal: { width: 612, height: 1008 },
    Tabloid: { width: 792, height: 1224 }
  };
  var _encoder = new TextEncoder();
  function str(s) {
    return _encoder.encode(s);
  }
  function concat(...parts) {
    const total = parts.reduce((n, p) => n + p.length, 0);
    const out = new Uint8Array(total);
    let offset = 0;
    for (const part of parts) {
      out.set(part, offset);
      offset += part.length;
    }
    return out;
  }
  function pad10(n) {
    return String(Math.round(n)).padStart(10, "0");
  }
  function pad2(n) {
    return String(n).padStart(2, "0");
  }
  function pdfDate(d) {
    return `D:${d.getFullYear()}${pad2(d.getMonth() + 1)}${pad2(d.getDate())}${pad2(d.getHours())}${pad2(d.getMinutes())}${pad2(d.getSeconds())}`;
  }
  function encodePdfString(s) {
    const isPureAscii = /^[\x20-\x7E]*$/.test(s);
    if (isPureAscii) {
      return `(${s.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)")})`;
    }
    let hex = "FEFF";
    for (let i = 0; i < s.length; i++) {
      const code = s.charCodeAt(i);
      hex += code.toString(16).padStart(4, "0").toUpperCase();
    }
    return `<${hex}>`;
  }
  function num(n, decimals = 3) {
    return n.toFixed(decimals);
  }
  function buildPdf(jpegBytes, opts) {
    const {
      imageWidthPx,
      imageHeightPx,
      dpi = 96,
      pageSize = "auto",
      orientation = "portrait",
      margin = 0,
      title = "",
      author = "",
      subject = "",
      keywords
    } = opts;
    const pxToPt = 72 / dpi;
    const imgWidthPt = imageWidthPx * pxToPt;
    const imgHeightPt = imageHeightPx * pxToPt;
    let pageWidthPt;
    let pageHeightPt;
    if (pageSize === "auto") {
      pageWidthPt = imgWidthPt + margin * 2;
      pageHeightPt = imgHeightPt + margin * 2;
    } else {
      let preset = { ...PAGE_PRESETS[pageSize] };
      if (orientation === "landscape" && preset.width < preset.height) {
        preset = { width: preset.height, height: preset.width };
      } else if (orientation === "portrait" && preset.width > preset.height) {
        preset = { width: preset.height, height: preset.width };
      }
      pageWidthPt = preset.width;
      pageHeightPt = preset.height;
    }
    const availableWidth = pageWidthPt - margin * 2;
    const availableHeight = pageHeightPt - margin * 2;
    let drawWidthPt = imgWidthPt;
    let drawHeightPt = imgHeightPt;
    if (pageSize !== "auto") {
      const scaleX = availableWidth / imgWidthPt;
      const scaleY = availableHeight / imgHeightPt;
      const fitScale = Math.min(scaleX, scaleY, 1);
      drawWidthPt = imgWidthPt * fitScale;
      drawHeightPt = imgHeightPt * fitScale;
    }
    const xOff = margin + (availableWidth - drawWidthPt) / 2;
    const yOff = margin + (availableHeight - drawHeightPt) / 2;
    const now = /* @__PURE__ */ new Date();
    const dateStr = pdfDate(now);
    const creator = "sharedom";
    const producer = "sharedom (https://github.com/Erickgiber/sharedom)";
    const offsets = new Array(7).fill(0);
    const parts = [];
    const header = str("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");
    parts.push(header);
    let pos = header.length;
    function addObject(id, body) {
      offsets[id] = pos;
      const chunk = str(`${id} 0 obj
${body}
endobj
`);
      parts.push(chunk);
      pos += chunk.length;
    }
    addObject(1, "<< /Type /Catalog /Pages 2 0 R >>");
    addObject(2, "<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
    const mediaBox = `[0 0 ${num(pageWidthPt)} ${num(pageHeightPt)}]`;
    addObject(
      3,
      `<< /Type /Page /Parent 2 0 R /MediaBox ${mediaBox} /Contents 4 0 R /Resources << /XObject << /Img 5 0 R >> >> >>`
    );
    const contentInner = `${num(drawWidthPt)} 0 0 ${num(drawHeightPt)} ${num(xOff)} ${num(yOff)} cm /Img Do`;
    const contentBody = `q
${contentInner}
Q`;
    addObject(
      4,
      `<< /Length ${contentBody.length} >>
stream
${contentBody}
endstream`
    );
    {
      offsets[5] = pos;
      const imgDictAndStream = str(
        `5 0 obj
<< /Type /XObject /Subtype /Image /Width ${imageWidthPx} /Height ${imageHeightPx} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpegBytes.length} >>
stream
`
      );
      const imgFooter = str(`
endstream
endobj
`);
      const imageObj = concat(imgDictAndStream, jpegBytes, imgFooter);
      parts.push(imageObj);
      pos += imageObj.length;
    }
    const hasMetadata = Boolean(title || author || subject || keywords && (Array.isArray(keywords) ? keywords.length > 0 : Boolean(keywords)));
    let infoObjId = null;
    if (hasMetadata) {
      infoObjId = 6;
      const entries = [];
      if (title) entries.push(`/Title ${encodePdfString(title)}`);
      if (author) entries.push(`/Author ${encodePdfString(author)}`);
      if (subject) entries.push(`/Subject ${encodePdfString(subject)}`);
      if (keywords) {
        const kwStr = Array.isArray(keywords) ? keywords.join(", ") : keywords;
        if (kwStr) entries.push(`/Keywords ${encodePdfString(kwStr)}`);
      }
      entries.push(`/Creator (sharedom)`);
      entries.push(`/Producer (sharedom)`);
      entries.push(`/CreationDate (${dateStr})`);
      entries.push(`/ModDate (${dateStr})`);
      addObject(infoObjId, `<<
  ${entries.join("\n  ")}
>>`);
    }
    const xrefOffset = pos;
    const objCount = infoObjId ? 7 : 6;
    let xref = `xref
0 ${objCount}
`;
    xref += "0000000000 65535 f \n";
    for (let i = 1; i < objCount; i++) {
      xref += `${pad10(offsets[i])} 00000 n 
`;
    }
    const trailerInfo = infoObjId ? ` /Info ${infoObjId} 0 R` : "";
    xref += `trailer
<< /Size ${objCount} /Root 1 0 R${trailerInfo} >>
startxref
${xrefOffset}
%%EOF
`;
    parts.push(str(xref));
    return concat(...parts);
  }
  function buildMultiPagePdf(opts) {
    const {
      pages,
      dpi = 96,
      pageSize = "auto",
      orientation = "portrait",
      margin = 0,
      title = "",
      author = "",
      subject = "",
      keywords
    } = opts;
    if (!pages || pages.length === 0) {
      return buildPdf(new Uint8Array(), {
        imageWidthPx: 100,
        imageHeightPx: 100,
        ...opts
      });
    }
    if (pages.length === 1) {
      return buildPdf(pages[0].jpegBytes, {
        imageWidthPx: pages[0].imageWidthPx,
        imageHeightPx: pages[0].imageHeightPx,
        ...opts
      });
    }
    const pxToPt = 72 / dpi;
    const now = /* @__PURE__ */ new Date();
    const dateStr = pdfDate(now);
    const hasMetadata = Boolean(title || author || subject || keywords && (Array.isArray(keywords) ? keywords.length > 0 : Boolean(keywords)));
    const infoObjId = hasMetadata ? 3 + pages.length * 3 : null;
    const totalObjects = infoObjId ? infoObjId + 1 : 3 + pages.length * 3;
    const offsets = new Array(totalObjects).fill(0);
    const parts = [];
    const header = str("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");
    parts.push(header);
    let pos = header.length;
    function addObject(id, body) {
      offsets[id] = pos;
      const chunk = str(`${id} 0 obj
${body}
endobj
`);
      parts.push(chunk);
      pos += chunk.length;
    }
    addObject(1, "<< /Type /Catalog /Pages 2 0 R >>");
    const kidsArray = [];
    for (let i = 0; i < pages.length; i++) {
      const pageId = 3 + i * 3;
      kidsArray.push(`${pageId} 0 R`);
    }
    addObject(2, `<< /Type /Pages /Kids [${kidsArray.join(" ")}] /Count ${pages.length} >>`);
    for (let i = 0; i < pages.length; i++) {
      const page = pages[i];
      const pageId = 3 + i * 3;
      const contentId = 4 + i * 3;
      const imgId = 5 + i * 3;
      const imgWidthPt = page.imageWidthPx * pxToPt;
      const imgHeightPt = page.imageHeightPx * pxToPt;
      let pageWidthPt;
      let pageHeightPt;
      if (pageSize === "auto") {
        pageWidthPt = imgWidthPt + margin * 2;
        pageHeightPt = imgHeightPt + margin * 2;
      } else {
        let preset = { ...PAGE_PRESETS[pageSize] };
        if (orientation === "landscape" && preset.width < preset.height) {
          preset = { width: preset.height, height: preset.width };
        } else if (orientation === "portrait" && preset.width > preset.height) {
          preset = { width: preset.height, height: preset.width };
        }
        pageWidthPt = preset.width;
        pageHeightPt = preset.height;
      }
      const availableWidth = pageWidthPt - margin * 2;
      const availableHeight = pageHeightPt - margin * 2;
      let drawWidthPt = imgWidthPt;
      let drawHeightPt = imgHeightPt;
      if (pageSize !== "auto") {
        const scaleX = availableWidth / imgWidthPt;
        const scaleY = availableHeight / imgHeightPt;
        const fitScale = Math.min(scaleX, scaleY, 1);
        drawWidthPt = imgWidthPt * fitScale;
        drawHeightPt = imgHeightPt * fitScale;
      }
      const xOff = margin + (availableWidth - drawWidthPt) / 2;
      const yOff = margin + (availableHeight - drawHeightPt) / 2;
      const mediaBox = `[0 0 ${num(pageWidthPt)} ${num(pageHeightPt)}]`;
      addObject(
        pageId,
        `<< /Type /Page /Parent 2 0 R /MediaBox ${mediaBox} /Contents ${contentId} 0 R /Resources << /XObject << /Img ${imgId} 0 R >> >> >>`
      );
      const contentInner = `${num(drawWidthPt)} 0 0 ${num(drawHeightPt)} ${num(xOff)} ${num(yOff)} cm /Img Do`;
      const contentBody = `q
${contentInner}
Q`;
      addObject(
        contentId,
        `<< /Length ${contentBody.length} >>
stream
${contentBody}
endstream`
      );
      offsets[imgId] = pos;
      const imgDictAndStream = str(
        `${imgId} 0 obj
<< /Type /XObject /Subtype /Image /Width ${page.imageWidthPx} /Height ${page.imageHeightPx} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${page.jpegBytes.length} >>
stream
`
      );
      const imgFooter = str(`
endstream
endobj
`);
      const imageObj = concat(imgDictAndStream, page.jpegBytes, imgFooter);
      parts.push(imageObj);
      pos += imageObj.length;
    }
    if (hasMetadata && infoObjId) {
      const entries = [];
      if (title) entries.push(`/Title ${encodePdfString(title)}`);
      if (author) entries.push(`/Author ${encodePdfString(author)}`);
      if (subject) entries.push(`/Subject ${encodePdfString(subject)}`);
      if (keywords) {
        const kwStr = Array.isArray(keywords) ? keywords.join(", ") : keywords;
        if (kwStr) entries.push(`/Keywords ${encodePdfString(kwStr)}`);
      }
      entries.push(`/Creator (sharedom)`);
      entries.push(`/Producer (sharedom)`);
      entries.push(`/CreationDate (${dateStr})`);
      entries.push(`/ModDate (${dateStr})`);
      addObject(infoObjId, `<<
  ${entries.join("\n  ")}
>>`);
    }
    const xrefOffset = pos;
    let xref = `xref
0 ${totalObjects}
`;
    xref += "0000000000 65535 f \n";
    for (let i = 1; i < totalObjects; i++) {
      xref += `${pad10(offsets[i])} 00000 n 
`;
    }
    const trailerInfo = infoObjId ? ` /Info ${infoObjId} 0 R` : "";
    xref += `trailer
<< /Size ${totalObjects} /Root 1 0 R${trailerInfo} >>
startxref
${xrefOffset}
%%EOF
`;
    parts.push(str(xref));
    return concat(...parts);
  }

  // src/pdf.ts
  async function captureAsJpeg(target, scale, quality, backgroundColor) {
    const element = resolveElement(target);
    const { width, height } = validateElementDimensions(element);
    const clone = element.cloneNode(true);
    syncDynamicStates(element, clone);
    cloneComputedStyles(element, clone);
    clone.style.width = `${width}px`;
    clone.style.height = `${height}px`;
    clone.style.boxSizing = "border-box";
    clone.style.margin = "0";
    const cleanupImages = await inlineImages(clone);
    try {
      const svgDataUrl = createSvgDataUrl(clone, width, height);
      const dataUrl = await renderSvgToCanvas(svgDataUrl, width, height, {
        scale,
        format: "jpeg",
        quality,
        backgroundColor,
        optimize: true
      });
      return {
        dataUrl,
        widthPx: Math.round(width * scale),
        heightPx: Math.round(height * scale)
      };
    } finally {
      cleanupImages();
    }
  }
  function dataUrlToBytes(dataUrl) {
    const commaIdx = dataUrl.indexOf(",");
    const base64 = commaIdx !== -1 ? dataUrl.slice(commaIdx + 1) : dataUrl;
    const binaryStr = atob(base64);
    const bytes = new Uint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }
    return bytes;
  }
  async function capturePDF(target, options = {}) {
    const {
      scale = 2,
      backgroundColor = "#ffffff",
      quality = 0.92,
      pageSize = "auto",
      orientation = "portrait",
      margin = 0,
      title,
      author,
      subject,
      keywords
    } = options;
    const { dataUrl, widthPx, heightPx } = await captureAsJpeg(
      target,
      scale,
      quality,
      backgroundColor
    );
    const jpegBytes = dataUrlToBytes(dataUrl);
    const pdfBytes = buildPdf(jpegBytes, {
      imageWidthPx: widthPx,
      imageHeightPx: heightPx,
      dpi: 96 * scale,
      pageSize,
      orientation,
      margin,
      title,
      author,
      subject,
      keywords
    });
    return new Blob([pdfBytes.buffer], { type: "application/pdf" });
  }
  async function downloadPDF(target, filename = "capture.pdf", options = {}) {
    if (typeof document === "undefined") {
      throw new Error(
        '[sharedom]: downloadPDF() requires a browser environment. For SSR environments, use "createPdfFromImageSSR" or "buildPdf" from "sharedom/ssr".'
      );
    }
    const blob = await capturePDF(target, options);
    const url = URL.createObjectURL(blob);
    try {
      const link = document.createElement("a");
      link.download = filename.endsWith(".pdf") ? filename : `${filename}.pdf`;
      link.href = url;
      link.click();
    } finally {
      setTimeout(() => URL.revokeObjectURL(url), 1e3);
    }
  }

  // src/index.ts
  async function capture(target, options = {}) {
    validateOptions(options);
    const element = resolveElement(target);
    const { width, height } = validateElementDimensions(element);
    const targetWidth = options.width ?? width;
    const targetHeight = options.height ?? height;
    const clone = element.cloneNode(true);
    syncDynamicStates(element, clone);
    cloneComputedStyles(element, clone);
    clone.style.width = `${targetWidth}px`;
    clone.style.height = `${targetHeight}px`;
    clone.style.boxSizing = "border-box";
    clone.style.margin = "0";
    const cleanupImages = await inlineImages(clone);
    try {
      const svgDataUrl = createSvgDataUrl(clone, targetWidth, targetHeight);
      return await renderSvgToCanvas(svgDataUrl, targetWidth, targetHeight, options);
    } finally {
      cleanupImages();
    }
  }

  // extension/src/content/modal.ts
  function rgbToHex(rgbStr) {
    const match = rgbStr.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (!match) return "#6366f1";
    const r = parseInt(match[1], 10).toString(16).padStart(2, "0");
    const g = parseInt(match[2], 10).toString(16).padStart(2, "0");
    const b = parseInt(match[3], 10).toString(16).padStart(2, "0");
    return `#${r}${g}${b}`;
  }
  var ActionModal = class {
    shadow;
    backdrop = null;
    currentElement = null;
    currentDataUrl = "";
    detectedBgColor = void 0;
    currentOptions = {
      scale: 2,
      format: "png",
      backgroundColor: void 0,
      language: "en"
    };
    isCapturing = false;
    currentCaptureType = "element";
    chunkElements = [];
    chunkDataUrls = [];
    currentPageIndex = 0;
    totalPages = 1;
    keydownHandler = null;
    idleTimer = null;
    rawItems = [];
    onClose;
    onReselect;
    onToast;
    constructor(shadow, callbacks, initialOptions) {
      this.shadow = shadow;
      this.onClose = callbacks.onClose;
      this.onReselect = callbacks.onReselect;
      this.onToast = callbacks.onToast;
      if (initialOptions) {
        this.currentOptions = { ...this.currentOptions, ...initialOptions };
      }
    }
    setOptions(options) {
      this.currentOptions = { ...this.currentOptions, ...options };
    }
    detectBackgroundColor(element) {
      let current = element;
      while (current && current !== document.documentElement) {
        const style = window.getComputedStyle(current);
        const bg = style.backgroundColor;
        if (bg && bg !== "transparent" && bg !== "rgba(0, 0, 0, 0)" && !bg.endsWith(", 0)")) {
          return bg;
        }
        current = current.parentElement;
      }
      const bodyStyle = window.getComputedStyle(document.body);
      const bodyBg = bodyStyle.backgroundColor;
      if (bodyBg && bodyBg !== "transparent" && bodyBg !== "rgba(0, 0, 0, 0)" && !bodyBg.endsWith(", 0)")) {
        return bodyBg;
      }
      return void 0;
    }
    async show(element, captureType = "element", chunkElements, rawItems) {
      this.rawItems = rawItems || [];
      if (chunkElements && chunkElements.length > 0) {
        this.chunkElements = chunkElements;
        this.totalPages = chunkElements.length;
        this.currentPageIndex = 0;
        this.currentElement = chunkElements[0];
      } else {
        this.chunkElements = [element];
        this.totalPages = 1;
        this.currentPageIndex = 0;
        this.currentElement = element;
      }
      this.currentCaptureType = captureType;
      if (captureType === "console" || captureType === "network") {
        this.detectedBgColor = "#0f172a";
        this.currentOptions.backgroundColor = "#0f172a";
      } else {
        this.detectedBgColor = this.detectBackgroundColor(element);
        this.currentOptions.backgroundColor = this.detectedBgColor;
      }
      this.hide();
      this.createModalDOM();
      await this.refreshCapture();
    }
    hide() {
      if (this.idleTimer) {
        clearTimeout(this.idleTimer);
        this.idleTimer = null;
      }
      if (this.keydownHandler) {
        window.removeEventListener("keydown", this.keydownHandler);
        this.keydownHandler = null;
      }
      if (this.backdrop) {
        this.backdrop.remove();
        this.backdrop = null;
      }
    }
    renderPreviewImage(previewBox, dataUrl) {
      if (!previewBox || !this.currentElement) return;
      previewBox.innerHTML = "";
      const img = document.createElement("img");
      img.className = "sharedom-preview-img";
      img.src = dataUrl;
      const rect = this.currentElement.getBoundingClientRect();
      const width = Math.round(rect.width * this.currentOptions.scale);
      const height = Math.round(rect.height * this.currentOptions.scale);
      const meta = document.createElement("div");
      meta.className = "sharedom-preview-meta";
      meta.textContent = `${width} \xD7 ${height} px (${this.currentOptions.scale}x ${this.currentOptions.format.toUpperCase()})`;
      previewBox.appendChild(img);
      previewBox.appendChild(meta);
    }
    async switchPage(newIndex) {
      if (newIndex < 0 || newIndex >= this.totalPages) return;
      this.currentPageIndex = newIndex;
      this.currentElement = this.chunkElements[newIndex];
      const prevBtn = this.backdrop?.querySelector("#sharedom-prev-page-btn");
      const nextBtn = this.backdrop?.querySelector("#sharedom-next-page-btn");
      const indicator = this.backdrop?.querySelector("#sharedom-page-indicator");
      const previewBox = this.shadow.getElementById("sharedom-modal-preview-box");
      if (prevBtn) prevBtn.disabled = newIndex === 0;
      if (nextBtn) nextBtn.disabled = newIndex === this.totalPages - 1;
      if (indicator) indicator.textContent = `${newIndex + 1} / ${this.totalPages}`;
      if (this.chunkDataUrls[newIndex]) {
        this.currentDataUrl = this.chunkDataUrls[newIndex];
        this.renderPreviewImage(previewBox, this.currentDataUrl);
      } else {
        const t = translations[this.currentOptions.language].modal;
        if (previewBox) {
          previewBox.innerHTML = `
          <div class="sharedom-preview-loader">
            <div class="sharedom-spinner"></div>
            <span>${t.rendering}</span>
          </div>
        `;
        }
        try {
          const url = await capture(this.currentElement, {
            scale: this.currentOptions.scale,
            format: this.currentOptions.format,
            backgroundColor: this.currentOptions.backgroundColor,
            optimize: true
          });
          this.chunkDataUrls[newIndex] = url;
          if (this.currentPageIndex === newIndex) {
            this.currentDataUrl = url;
            this.renderPreviewImage(previewBox, url);
          }
        } catch {
          if (previewBox) {
            previewBox.innerHTML = `
            <div style="color: #ef4444; font-size: 13px; text-align: center; padding: 16px;">
              Failed to render page
            </div>
          `;
          }
        }
      }
    }
    scheduleBackgroundPreRender(options) {
      const renderNext = (idx) => {
        if (idx >= this.chunkElements.length) return;
        if (!this.chunkDataUrls[idx]) {
          capture(this.chunkElements[idx], options).then((url) => {
            this.chunkDataUrls[idx] = url;
            this.idleTimer = window.setTimeout(() => renderNext(idx + 1), 60);
          }).catch(() => {
            this.idleTimer = window.setTimeout(() => renderNext(idx + 1), 60);
          });
        } else {
          renderNext(idx + 1);
        }
      };
      this.idleTimer = window.setTimeout(() => renderNext(1), 100);
    }
    async ensureAllChunksCaptured() {
      const options = {
        scale: this.currentOptions.scale,
        format: this.currentOptions.format,
        backgroundColor: this.currentOptions.backgroundColor,
        optimize: true
      };
      for (let i = 0; i < this.chunkElements.length; i++) {
        if (!this.chunkDataUrls[i]) {
          this.chunkDataUrls[i] = await capture(this.chunkElements[i], options);
        }
      }
    }
    createModalDOM() {
      if (!this.currentElement) return;
      const t = translations[this.currentOptions.language].modal;
      this.backdrop = document.createElement("div");
      this.backdrop.className = "sharedom-modal-backdrop";
      const card = document.createElement("div");
      card.className = "sharedom-modal-card";
      card.addEventListener("click", (e) => e.stopPropagation());
      const header = document.createElement("div");
      header.className = "sharedom-modal-header";
      const titleWrap = document.createElement("div");
      titleWrap.className = "sharedom-modal-title-wrap";
      const logo = document.createElement("div");
      logo.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="28" height="28" fill="none">
        <rect width="48" height="48" rx="12" fill="#090d16" />
        <rect x="1.5" y="1.5" width="45" height="45" rx="10.5" stroke="rgba(255,255,255,0.12)" stroke-width="1.5" />
        <path d="M12 20V12H20" stroke="url(#modal_grad)" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M36 20V12H28" stroke="url(#modal_grad)" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M12 28V36H20" stroke="url(#modal_grad)" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M36 28V36H28" stroke="url(#modal_grad)" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" />
        <circle cx="24" cy="24" r="5" fill="url(#modal_grad)" />
        <defs>
          <linearGradient id="modal_grad" x1="12" y1="12" x2="36" y2="36" gradientUnits="userSpaceOnUse">
            <stop stop-color="#6366f1" />
            <stop offset="0.5" stop-color="#a855f7" />
            <stop offset="1" stop-color="#06b6d4" />
          </linearGradient>
        </defs>
      </svg>
    `;
      const textWrap = document.createElement("div");
      const title = document.createElement("div");
      title.className = "sharedom-modal-title";
      const subtitle = document.createElement("div");
      subtitle.className = "sharedom-modal-subtitle";
      if (this.currentCaptureType === "console") {
        title.textContent = t.consoleTitle;
        subtitle.textContent = t.logsSubtitle;
      } else if (this.currentCaptureType === "network") {
        title.textContent = t.networkTitle;
        subtitle.textContent = t.networkSubtitle;
      } else {
        title.textContent = t.title;
        const tag = this.currentElement.tagName.toLowerCase();
        const idStr = this.currentElement.id ? `#${this.currentElement.id}` : "";
        const classStr = this.currentElement.className && typeof this.currentElement.className === "string" ? `.${this.currentElement.className.trim().split(/\s+/).slice(0, 2).join(".")}` : "";
        subtitle.textContent = `<${tag}${idStr}${classStr}>`;
      }
      textWrap.appendChild(title);
      textWrap.appendChild(subtitle);
      titleWrap.appendChild(logo);
      titleWrap.appendChild(textWrap);
      const closeBtn = document.createElement("button");
      closeBtn.className = "sharedom-icon-btn";
      closeBtn.setAttribute("title", "Close (Esc)");
      closeBtn.innerHTML = `
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    `;
      closeBtn.addEventListener("click", () => {
        this.hide();
        this.onClose();
      });
      header.appendChild(titleWrap);
      header.appendChild(closeBtn);
      const body = document.createElement("div");
      body.className = "sharedom-modal-body";
      const previewContainer = document.createElement("div");
      previewContainer.className = "sharedom-preview-container";
      previewContainer.id = "sharedom-modal-preview-box";
      const loader = document.createElement("div");
      loader.className = "sharedom-preview-loader";
      loader.innerHTML = `
      <div class="sharedom-spinner"></div>
      <span>${t.rendering}</span>
    `;
      previewContainer.appendChild(loader);
      body.appendChild(previewContainer);
      if (this.totalPages > 1) {
        const paginationBar = document.createElement("div");
        paginationBar.className = "sharedom-pagination-bar";
        const prevBtn = document.createElement("button");
        prevBtn.className = "sharedom-page-btn";
        prevBtn.id = "sharedom-prev-page-btn";
        prevBtn.title = t.prevPage;
        prevBtn.innerHTML = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="15 18 9 12 15 6"></polyline>
        </svg>
        <span>${t.prevPage}</span>
      `;
        prevBtn.disabled = this.currentPageIndex === 0;
        const pageIndicator = document.createElement("span");
        pageIndicator.className = "sharedom-page-indicator";
        pageIndicator.id = "sharedom-page-indicator";
        pageIndicator.textContent = `${this.currentPageIndex + 1} / ${this.totalPages}`;
        const nextBtn = document.createElement("button");
        nextBtn.className = "sharedom-page-btn";
        nextBtn.id = "sharedom-next-page-btn";
        nextBtn.title = t.nextPage;
        nextBtn.innerHTML = `
        <span>${t.nextPage}</span>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="9 18 15 12 9 6"></polyline>
        </svg>
      `;
        nextBtn.disabled = this.currentPageIndex === this.totalPages - 1;
        prevBtn.addEventListener("click", async () => {
          if (this.currentPageIndex > 0) {
            await this.switchPage(this.currentPageIndex - 1);
          }
        });
        nextBtn.addEventListener("click", async () => {
          if (this.currentPageIndex < this.totalPages - 1) {
            await this.switchPage(this.currentPageIndex + 1);
          }
        });
        paginationBar.appendChild(prevBtn);
        paginationBar.appendChild(pageIndicator);
        paginationBar.appendChild(nextBtn);
        body.appendChild(paginationBar);
      }
      const controlsGrid = document.createElement("div");
      controlsGrid.className = "sharedom-controls-grid";
      const scaleGroup = document.createElement("div");
      scaleGroup.className = "sharedom-control-group";
      const scaleLabel = document.createElement("label");
      scaleLabel.className = "sharedom-control-label";
      scaleLabel.textContent = t.resolution;
      const scaleBtnGroup = document.createElement("div");
      scaleBtnGroup.className = "sharedom-btn-group";
      const scales = [1, 2, 3];
      scales.forEach((s) => {
        const btn = document.createElement("button");
        btn.className = `sharedom-btn-option ${this.currentOptions.scale === s ? "active" : ""}`;
        btn.textContent = `${s}x`;
        btn.addEventListener("click", async () => {
          if (this.currentOptions.scale === s || this.isCapturing) return;
          scaleBtnGroup.querySelectorAll(".sharedom-btn-option").forEach((b) => b.classList.remove("active"));
          btn.classList.add("active");
          this.currentOptions.scale = s;
          await this.refreshCapture();
        });
        scaleBtnGroup.appendChild(btn);
      });
      scaleGroup.appendChild(scaleLabel);
      scaleGroup.appendChild(scaleBtnGroup);
      const formatGroup = document.createElement("div");
      formatGroup.className = "sharedom-control-group";
      const formatLabel = document.createElement("label");
      formatLabel.className = "sharedom-control-label";
      formatLabel.textContent = t.format;
      const formatSelectWrap = document.createElement("div");
      formatSelectWrap.className = "sharedom-select-wrap";
      const formatSelect = document.createElement("select");
      formatSelect.className = "sharedom-select";
      ["png", "jpeg", "webp"].forEach((fmt) => {
        const opt = document.createElement("option");
        opt.value = fmt;
        opt.textContent = fmt.toUpperCase();
        if (this.currentOptions.format === fmt) opt.selected = true;
        formatSelect.appendChild(opt);
      });
      formatSelect.addEventListener("change", async () => {
        if (this.isCapturing) return;
        this.currentOptions.format = formatSelect.value;
        await this.refreshCapture();
      });
      formatSelectWrap.appendChild(formatSelect);
      formatGroup.appendChild(formatLabel);
      formatGroup.appendChild(formatSelectWrap);
      const bgGroup = document.createElement("div");
      bgGroup.className = "sharedom-control-group";
      const bgLabel = document.createElement("label");
      bgLabel.className = "sharedom-control-label";
      bgLabel.textContent = t.background;
      const bgSelectWrap = document.createElement("div");
      bgSelectWrap.className = "sharedom-select-wrap";
      const bgSelect = document.createElement("select");
      bgSelect.className = "sharedom-select";
      const bgOptions = [];
      if (this.detectedBgColor) {
        bgOptions.push({ label: t.bgAuto, value: "auto" });
      }
      bgOptions.push({ label: t.bgTransparent, value: "transparent" });
      bgOptions.push({ label: t.bgWhite, value: "#ffffff" });
      bgOptions.push({ label: t.bgDark, value: "#111116" });
      bgOptions.push({ label: t.bgCustom, value: "custom" });
      bgOptions.forEach((optData) => {
        const opt = document.createElement("option");
        opt.value = optData.value;
        opt.textContent = optData.label;
        if (this.detectedBgColor && optData.value === "auto") {
          opt.selected = true;
        } else if (!this.detectedBgColor && optData.value === "transparent") {
          opt.selected = true;
        }
        bgSelect.appendChild(opt);
      });
      const customColorInput = document.createElement("input");
      customColorInput.type = "color";
      customColorInput.value = this.detectedBgColor ? rgbToHex(this.detectedBgColor) : "#6366f1";
      customColorInput.style.display = "none";
      customColorInput.className = "sharedom-color-picker";
      bgSelect.addEventListener("change", async () => {
        if (this.isCapturing) return;
        const val = bgSelect.value;
        if (val === "custom") {
          customColorInput.style.display = "inline-block";
          this.currentOptions.backgroundColor = customColorInput.value;
        } else {
          customColorInput.style.display = "none";
          if (val === "auto") {
            this.currentOptions.backgroundColor = this.detectedBgColor;
          } else if (val === "transparent") {
            this.currentOptions.backgroundColor = void 0;
          } else {
            this.currentOptions.backgroundColor = val;
          }
        }
        await this.refreshCapture();
      });
      customColorInput.addEventListener("input", async () => {
        if (this.isCapturing) return;
        this.currentOptions.backgroundColor = customColorInput.value;
        await this.refreshCapture();
      });
      bgSelectWrap.appendChild(bgSelect);
      bgGroup.appendChild(bgLabel);
      bgGroup.appendChild(bgSelectWrap);
      bgGroup.appendChild(customColorInput);
      controlsGrid.appendChild(scaleGroup);
      controlsGrid.appendChild(formatGroup);
      controlsGrid.appendChild(bgGroup);
      body.appendChild(controlsGrid);
      const footer = document.createElement("div");
      footer.className = "sharedom-modal-footer";
      const footerLeft = document.createElement("div");
      footerLeft.className = "sharedom-footer-left";
      const reselectBtn = document.createElement("button");
      reselectBtn.className = "sharedom-btn sharedom-btn-secondary sharedom-btn-icon";
      reselectBtn.setAttribute("title", t.reselectTooltip);
      reselectBtn.setAttribute("aria-label", t.reselectTooltip);
      reselectBtn.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"></path>
        <path d="M21 3v5h-5"></path>
      </svg>
    `;
      reselectBtn.addEventListener("click", () => {
        this.hide();
        this.onReselect();
      });
      const copyDataUrlBtn = document.createElement("button");
      copyDataUrlBtn.className = "sharedom-btn sharedom-btn-ghost";
      copyDataUrlBtn.setAttribute("title", "Copy Base64 Data URL string");
      copyDataUrlBtn.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="16 18 22 12 16 6"></polyline>
        <polyline points="8 6 2 12 8 18"></polyline>
      </svg>
      ${t.base64}
    `;
      copyDataUrlBtn.addEventListener("click", async () => {
        if (!this.currentDataUrl) return;
        try {
          await navigator.clipboard.writeText(this.currentDataUrl);
          this.onToast(t.dataUrlSuccess, "\u{1F4CB}");
        } catch {
          this.onToast(t.dataUrlError, "\u26A0\uFE0F");
        }
      });
      if (this.currentCaptureType === "element") {
        footerLeft.appendChild(reselectBtn);
        footerLeft.appendChild(copyDataUrlBtn);
      } else if (this.currentCaptureType === "console") {
        const copyLogsBtn = document.createElement("button");
        copyLogsBtn.className = "sharedom-btn sharedom-btn-copylogs";
        copyLogsBtn.setAttribute("title", t.copyLogsTooltip);
        copyLogsBtn.innerHTML = `
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
          <polyline points="14 2 14 8 20 8"></polyline>
          <line x1="16" y1="13" x2="8" y2="13"></line>
          <line x1="16" y1="17" x2="8" y2="17"></line>
          <line x1="10" y1="9" x2="8" y2="9"></line>
        </svg>
        <span>${t.copyLogs}</span>
      `;
        copyLogsBtn.addEventListener("click", async () => {
          await this.copyLogsAsText();
        });
        footerLeft.appendChild(copyLogsBtn);
      } else {
        footerLeft.appendChild(copyDataUrlBtn);
      }
      const footerRight = document.createElement("div");
      footerRight.className = "sharedom-footer-right";
      const downloadBtn = document.createElement("button");
      downloadBtn.className = "sharedom-btn sharedom-btn-secondary";
      downloadBtn.innerHTML = `
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
        <polyline points="7 10 12 15 17 10"></polyline>
        <line x1="12" y1="15" x2="12" y2="3"></line>
      </svg>
      ${t.download}
    `;
      downloadBtn.addEventListener("click", async () => {
        await this.triggerDownload();
      });
      const downloadPdfBtn = document.createElement("button");
      downloadPdfBtn.className = "sharedom-btn sharedom-btn-secondary";
      downloadPdfBtn.setAttribute("title", t.pdfTooltip);
      downloadPdfBtn.innerHTML = `
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
        <polyline points="14 2 14 8 20 8"></polyline>
        <line x1="16" y1="13" x2="8" y2="13"></line>
        <line x1="16" y1="17" x2="8" y2="17"></line>
        <polyline points="10 9 9 9 8 9"></polyline>
      </svg>
      ${t.pdf}
    `;
      downloadPdfBtn.addEventListener("click", async () => {
        await this.triggerPdfDownload(downloadPdfBtn);
      });
      const copyBtn = document.createElement("button");
      copyBtn.className = "sharedom-btn sharedom-btn-primary";
      copyBtn.innerHTML = `
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
      </svg>
      ${t.copyImage}
    `;
      copyBtn.addEventListener("click", async () => {
        await this.copyImageToClipboard();
      });
      footerRight.appendChild(downloadBtn);
      footerRight.appendChild(downloadPdfBtn);
      footerRight.appendChild(copyBtn);
      footer.appendChild(footerLeft);
      footer.appendChild(footerRight);
      card.appendChild(header);
      card.appendChild(body);
      card.appendChild(footer);
      this.backdrop.appendChild(card);
      this.shadow.appendChild(this.backdrop);
      this.keydownHandler = (e) => {
        if (e.key === "Escape") {
          this.hide();
          this.onClose();
        } else if (e.key === "ArrowLeft" && this.totalPages > 1) {
          this.switchPage(this.currentPageIndex - 1);
        } else if (e.key === "ArrowRight" && this.totalPages > 1) {
          this.switchPage(this.currentPageIndex + 1);
        }
      };
      window.addEventListener("keydown", this.keydownHandler);
    }
    async refreshCapture() {
      if (!this.currentElement || !this.shadow) return;
      const t = translations[this.currentOptions.language].modal;
      this.isCapturing = true;
      if (this.idleTimer) {
        clearTimeout(this.idleTimer);
        this.idleTimer = null;
      }
      const previewBox = this.shadow.getElementById("sharedom-modal-preview-box");
      if (previewBox) {
        previewBox.innerHTML = `
        <div class="sharedom-preview-loader">
          <div class="sharedom-spinner"></div>
          <span>${t.rendering}</span>
        </div>
      `;
      }
      try {
        const options = {
          scale: this.currentOptions.scale,
          format: this.currentOptions.format,
          backgroundColor: this.currentOptions.backgroundColor,
          optimize: true
        };
        this.chunkDataUrls = new Array(this.chunkElements.length).fill("");
        const activeElement = this.chunkElements[this.currentPageIndex] || this.chunkElements[0];
        const activeUrl = await capture(activeElement, options);
        this.chunkDataUrls[this.currentPageIndex] = activeUrl;
        this.currentDataUrl = activeUrl;
        this.renderPreviewImage(previewBox, activeUrl);
        if (this.totalPages > 1) {
          this.scheduleBackgroundPreRender(options);
        }
      } catch (error) {
        if (previewBox) {
          previewBox.innerHTML = `
          <div style="color: #ef4444; font-size: 13px; text-align: center; padding: 16px;">
            ${t.captureFailed}<br>
            <span style="font-size: 11px; color: #a1a1aa;">${String(error)}</span>
          </div>
        `;
        }
      } finally {
        this.isCapturing = false;
      }
    }
    async copyImageToClipboard() {
      if (!this.currentElement) return;
      const t = translations[this.currentOptions.language].modal;
      try {
        if (this.totalPages > 1) {
          await this.ensureAllChunksCaptured();
          const htmlImgs = this.chunkDataUrls.map((url, idx) => `<div style="margin-bottom: 16px;"><img src="${url}" alt="Page ${idx + 1}" style="max-width: 100%; border-radius: 12px; display: block;" /></div>`).join("");
          const htmlPayload = `<div style="display: flex; flex-direction: column; gap: 16px;">${htmlImgs}</div>`;
          const htmlBlob = new Blob([htmlPayload], { type: "text/html" });
          const currentRes = await fetch(this.currentDataUrl);
          const currentBlob = await currentRes.blob();
          await navigator.clipboard.write([
            new ClipboardItem({
              "text/html": htmlBlob,
              "image/png": currentBlob
            })
          ]);
          this.onToast(t.allCopied, "\u{1F4CB}");
          return;
        }
        let pngBlob;
        if (this.currentOptions.format === "png" && this.currentDataUrl.startsWith("data:image/png")) {
          const res = await fetch(this.currentDataUrl);
          pngBlob = await res.blob();
        } else {
          const pngDataUrl = await capture(this.currentElement, {
            scale: this.currentOptions.scale,
            format: "png",
            backgroundColor: this.currentOptions.backgroundColor,
            optimize: true
          });
          const res = await fetch(pngDataUrl);
          pngBlob = await res.blob();
        }
        await navigator.clipboard.write([
          new ClipboardItem({ "image/png": pngBlob })
        ]);
        this.onToast(t.copySuccess, "\u{1F4CB}");
      } catch (error) {
        try {
          if (this.currentDataUrl) {
            await navigator.clipboard.writeText(this.currentDataUrl);
            this.onToast(t.dataUrlSuccess, "\u{1F4CB}");
            return;
          }
        } catch {
        }
        this.onToast(t.copyError, "\u26A0\uFE0F");
      }
    }
    async triggerDownload() {
      if (!this.currentDataUrl || !this.currentElement) return;
      const t = translations[this.currentOptions.language].modal;
      const now = /* @__PURE__ */ new Date();
      const timestamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}-${String(now.getHours()).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}${String(now.getSeconds()).padStart(2, "0")}`;
      const ext = this.currentOptions.format;
      let basePrefix = "";
      if (this.currentCaptureType === "console") {
        basePrefix = `sharedom-console-${timestamp}`;
      } else if (this.currentCaptureType === "network") {
        basePrefix = `sharedom-network-${timestamp}`;
      } else {
        const tag = this.currentElement.tagName.toLowerCase();
        const id = this.currentElement.id ? `-${this.currentElement.id}` : "";
        basePrefix = `sharedom-${tag}${id}-${timestamp}`;
      }
      if (this.totalPages > 1) {
        await this.ensureAllChunksCaptured();
        const zipFiles = this.chunkDataUrls.map((url, i) => ({
          name: `${basePrefix}-part${i + 1}.${ext}`,
          data: url
        }));
        downloadZip(zipFiles, `${basePrefix}.zip`);
        this.onToast(t.zipDownloaded || t.allDownloaded, "\u{1F4E6}");
        return;
      }
      const link = document.createElement("a");
      link.download = `${basePrefix}.${ext}`;
      link.href = this.currentDataUrl;
      link.click();
      this.onToast(`${t.downloaded} ${link.download}`, "\u{1F4E5}");
    }
    async triggerPdfDownload(btn) {
      if (!this.currentElement || this.isCapturing) return;
      const t = translations[this.currentOptions.language].modal;
      const now = /* @__PURE__ */ new Date();
      const timestamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}-${String(now.getHours()).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}${String(now.getSeconds()).padStart(2, "0")}`;
      let filename = "";
      if (this.currentCaptureType === "console") {
        filename = `sharedom-console-${timestamp}.pdf`;
      } else if (this.currentCaptureType === "network") {
        filename = `sharedom-network-${timestamp}.pdf`;
      } else {
        const tag = this.currentElement.tagName.toLowerCase();
        const id = this.currentElement.id ? `-${this.currentElement.id}` : "";
        filename = `sharedom-${tag}${id}-${timestamp}.pdf`;
      }
      const originalHTML = btn?.innerHTML;
      if (btn) {
        btn.disabled = true;
        btn.innerHTML = `
        <div class="sharedom-spinner" style="width:13px;height:13px;border-width:2px;display:inline-block"></div>
        <span>${t.pdf}</span>
      `;
      }
      try {
        const bgColor = this.currentOptions.backgroundColor ?? "#ffffff";
        const pdfOpts = {
          scale: this.currentOptions.scale,
          backgroundColor: bgColor,
          quality: 0.92,
          pageSize: "auto"
        };
        if (this.totalPages > 1 && this.chunkElements.length > 1) {
          const pages = [];
          for (const el of this.chunkElements) {
            const rect = el.getBoundingClientRect();
            const w = Math.round(rect.width * this.currentOptions.scale);
            const h = Math.round(rect.height * this.currentOptions.scale);
            const jpegDataUrl = await capture(el, {
              scale: this.currentOptions.scale,
              format: "jpeg",
              quality: 0.92,
              backgroundColor: bgColor,
              optimize: true
            });
            const bin = atob(jpegDataUrl.split(",")[1]);
            const bytes = new Uint8Array(bin.length);
            for (let b = 0; b < bin.length; b++) bytes[b] = bin.charCodeAt(b);
            pages.push({ jpegBytes: bytes, imageWidthPx: w, imageHeightPx: h });
          }
          const pdfBytes = buildMultiPagePdf({
            pages,
            dpi: 96 * this.currentOptions.scale,
            pageSize: "auto",
            margin: 0
          });
          const blob = new Blob([pdfBytes.buffer], { type: "application/pdf" });
          const url = URL.createObjectURL(blob);
          const link = document.createElement("a");
          link.download = filename;
          link.href = url;
          link.click();
          setTimeout(() => URL.revokeObjectURL(url), 1e3);
          this.onToast(`${t.pdfSuccess} ${filename}`, "\u{1F4C4}");
        } else {
          await downloadPDF(this.currentElement, filename, pdfOpts);
          this.onToast(`${t.pdfSuccess} ${filename}`, "\u{1F4C4}");
        }
      } catch (error) {
        this.onToast(`${t.pdfError}: ${String(error)}`, "\u26A0\uFE0F");
      } finally {
        if (btn && originalHTML) {
          btn.disabled = false;
          btn.innerHTML = originalHTML;
        }
      }
    }
    async copyLogsAsText() {
      const t = translations[this.currentOptions.language].modal;
      const logs = this.rawItems;
      if (!logs || logs.length === 0) {
        this.onToast(this.currentOptions.language === "es" ? "No hay logs registrados para copiar" : "No logs recorded to copy", "\u2139\uFE0F");
        return;
      }
      try {
        const pad = (n) => n.toString().padStart(2, "0");
        const formatTime2 = (ts) => {
          const d = new Date(ts);
          return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
        };
        const now = /* @__PURE__ */ new Date();
        const dateStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
        const header = `=== ShareDOM Console Logs (${logs.length} ${logs.length === 1 ? "log" : "logs"}) - ${dateStr} ===
`;
        const lines = logs.map((log) => {
          const time = log.timestamp ? formatTime2(log.timestamp) : formatTime2(Date.now());
          const level = (log.level || "LOG").toUpperCase().padEnd(5, " ");
          const count = log.count && log.count > 1 ? ` (x${log.count})` : "";
          return `[${time}] [${level}] ${log.message}${count}`;
        });
        const fullText = header + "\n" + lines.join("\n");
        await navigator.clipboard.writeText(fullText);
        this.onToast(t.logsCopied, "\u{1F4CB}");
      } catch {
        this.onToast(t.logsCopyError, "\u26A0\uFE0F");
      }
    }
  };

  // extension/src/content/inspector.ts
  var pageLogs = [];
  var pageRequests = [];
  if (typeof window !== "undefined") {
    startConsoleCapture();
    startNetworkCapture();
    const handlePageLog = (e) => {
      let detail = e.detail;
      if (typeof detail === "string") {
        try {
          detail = JSON.parse(detail);
        } catch {
        }
      }
      if (!detail || !detail.message) return;
      const last = pageLogs[pageLogs.length - 1];
      if (last && last.level === detail.level && last.message === detail.message) {
        if (last.timestamp === detail.timestamp) return;
        last.count = (last.count || 1) + (detail.count || 1);
        last.timestamp = detail.timestamp || Date.now();
        return;
      }
      const exists = pageLogs.some((l) => l.timestamp === detail.timestamp && l.message === detail.message);
      if (exists) return;
      pageLogs.push(detail);
      if (pageLogs.length > 200) pageLogs.shift();
    };
    window.addEventListener("__sharedom_page_log__", handlePageLog);
    document.addEventListener("__sharedom_page_log__", handlePageLog);
    const handlePageReq = (e) => {
      let detail = e.detail;
      if (typeof detail === "string") {
        try {
          detail = JSON.parse(detail);
        } catch {
        }
      }
      if (!detail || !detail.url) return;
      const exists = pageRequests.some((r) => r.timestamp === detail.timestamp && r.url === detail.url && r.method === detail.method);
      if (exists) return;
      pageRequests.push(detail);
      if (pageRequests.length > 200) pageRequests.shift();
    };
    window.addEventListener("__sharedom_page_req__", handlePageReq);
    document.addEventListener("__sharedom_page_req__", handlePageReq);
    try {
      const syncEv = new CustomEvent("__sharedom_request_sync__");
      window.dispatchEvent(syncEv);
      document.dispatchEvent(syncEv);
    } catch {
    }
  }
  function installPageTracker() {
    if (typeof document === "undefined" || document.getElementById("__sharedom_page_tracker__")) {
      return;
    }
    try {
      const script = document.createElement("script");
      script.id = "__sharedom_page_tracker__";
      script.src = chrome.runtime.getURL("page-tracker.js");
      script.onload = () => {
        try {
          script.remove();
        } catch (_) {
        }
      };
      script.onerror = () => {
        try {
          script.remove();
        } catch (_) {
        }
      };
      (document.head || document.documentElement).appendChild(script);
    } catch (_) {
    }
  }
  var DomInspector = class {
    overlay = null;
    modal = null;
    isActive = false;
    isModalOpen = false;
    hoveredElement = null;
    selectedElement = null;
    temporaryWrapper = null;
    currentLanguage = "en";
    onMouseMoveBound = this.onMouseMove.bind(this);
    onMouseOverBound = this.onMouseOver.bind(this);
    onClickBound = this.onClick.bind(this);
    onKeyDownBound = this.onKeyDown.bind(this);
    onScrollBound = this.onScroll.bind(this);
    async initOverlayAndModal(options) {
      let scale = options?.scale ?? 2;
      let format = options?.format ?? "png";
      let language = options?.language;
      if (!language) {
        try {
          const stored = await chrome.storage.local.get(["language", "defaultScale", "defaultFormat"]);
          if (stored.language === "en" || stored.language === "es") {
            language = stored.language;
          }
          if (stored.defaultScale && !options?.scale) {
            scale = Number(stored.defaultScale);
          }
          if (stored.defaultFormat && !options?.format) {
            if (stored.defaultFormat === "png" || stored.defaultFormat === "jpeg" || stored.defaultFormat === "webp") {
              format = stored.defaultFormat;
            }
          }
        } catch {
        }
      }
      this.currentLanguage = language || "en";
      if (!this.overlay) {
        this.overlay = new OverlayManager(this.currentLanguage);
      } else {
        this.overlay.setLanguage(this.currentLanguage);
      }
      const shadow = this.overlay.getShadowRoot();
      if (shadow && !this.modal) {
        this.modal = new ActionModal(
          shadow,
          {
            onClose: () => this.stop(),
            onReselect: () => this.resumeInspection(),
            onToast: (msg, icon) => this.overlay?.showToast(msg, icon)
          },
          { scale, format, language: this.currentLanguage }
        );
      } else if (this.modal) {
        this.modal.setOptions({ scale, format, language: this.currentLanguage });
      }
      return { scale, format };
    }
    async start(options) {
      if (this.isActive) return;
      this.isActive = true;
      this.isModalOpen = false;
      this.hoveredElement = null;
      this.selectedElement = null;
      await this.initOverlayAndModal(options);
      this.overlay?.showStatusPill(() => this.stop(), this.currentLanguage);
      this.attachEvents();
    }
    async captureConsole(options) {
      try {
        const syncEv = new CustomEvent("__sharedom_request_sync__");
        window.dispatchEvent(syncEv);
        document.dispatchEvent(syncEv);
      } catch {
      }
      this.stop();
      this.isActive = true;
      this.isModalOpen = true;
      await this.initOverlayAndModal(options);
      const logs = pageLogs.length > 0 ? pageLogs : getConsoleLogs();
      const chunks = chunkItems(logs, 15);
      this.temporaryWrapper = document.createElement("div");
      this.temporaryWrapper.style.position = "fixed";
      this.temporaryWrapper.style.top = "-99999px";
      this.temporaryWrapper.style.left = "-99999px";
      this.temporaryWrapper.style.opacity = "0";
      this.temporaryWrapper.style.pointerEvents = "none";
      this.temporaryWrapper.style.zIndex = "-9999";
      const chunkElements = [];
      chunks.forEach((chunk, i) => {
        const el = createConsoleLogsElement(chunk, {
          language: this.currentLanguage,
          pageIndex: i + 1,
          totalPages: chunks.length,
          startIndex: i * 15,
          totalItems: logs.length
        });
        chunkElements.push(el);
        this.temporaryWrapper.appendChild(el);
      });
      document.body.appendChild(this.temporaryWrapper);
      this.selectedElement = chunkElements[0];
      if (this.modal) {
        await this.modal.show(chunkElements[0], "console", chunkElements, logs);
      }
    }
    async captureNetwork(options) {
      try {
        const syncEv = new CustomEvent("__sharedom_request_sync__");
        window.dispatchEvent(syncEv);
        document.dispatchEvent(syncEv);
      } catch {
      }
      this.stop();
      this.isActive = true;
      this.isModalOpen = true;
      await this.initOverlayAndModal(options);
      const requests = pageRequests.length > 0 ? pageRequests : getNetworkRequests();
      const chunks = chunkItems(requests, 12);
      this.temporaryWrapper = document.createElement("div");
      this.temporaryWrapper.style.position = "fixed";
      this.temporaryWrapper.style.top = "-99999px";
      this.temporaryWrapper.style.left = "-99999px";
      this.temporaryWrapper.style.opacity = "0";
      this.temporaryWrapper.style.pointerEvents = "none";
      this.temporaryWrapper.style.zIndex = "-9999";
      const chunkElements = [];
      chunks.forEach((chunk, i) => {
        const el = createNetworkRequestsElement(chunk, {
          language: this.currentLanguage,
          pageIndex: i + 1,
          totalPages: chunks.length,
          startIndex: i * 12,
          totalItems: requests.length
        });
        chunkElements.push(el);
        this.temporaryWrapper.appendChild(el);
      });
      document.body.appendChild(this.temporaryWrapper);
      this.selectedElement = chunkElements[0];
      if (this.modal) {
        await this.modal.show(chunkElements[0], "network", chunkElements, requests);
      }
    }
    stop() {
      if (!this.isActive) return;
      this.detachEvents();
      this.isActive = false;
      this.isModalOpen = false;
      this.hoveredElement = null;
      this.selectedElement = null;
      if (this.temporaryWrapper && this.temporaryWrapper.parentNode) {
        this.temporaryWrapper.parentNode.removeChild(this.temporaryWrapper);
        this.temporaryWrapper = null;
      }
      if (this.modal) {
        this.modal.hide();
        this.modal = null;
      }
      if (this.overlay) {
        this.overlay.destroy();
        this.overlay = null;
      }
    }
    async toggle(options) {
      if (this.isActive) {
        this.stop();
      } else {
        await this.start(options);
      }
    }
    getIsActive() {
      return this.isActive;
    }
    resumeInspection() {
      this.isModalOpen = false;
      this.selectedElement = null;
      if (this.overlay) {
        this.overlay.showStatusPill(() => this.stop(), this.currentLanguage);
      }
    }
    attachEvents() {
      window.addEventListener("mousemove", this.onMouseMoveBound, true);
      window.addEventListener("mouseover", this.onMouseOverBound, true);
      window.addEventListener("click", this.onClickBound, true);
      window.addEventListener("keydown", this.onKeyDownBound, true);
      window.addEventListener("scroll", this.onScrollBound, true);
      window.addEventListener("resize", this.onScrollBound, true);
    }
    detachEvents() {
      window.removeEventListener("mousemove", this.onMouseMoveBound, true);
      window.removeEventListener("mouseover", this.onMouseOverBound, true);
      window.removeEventListener("click", this.onClickBound, true);
      window.removeEventListener("keydown", this.onKeyDownBound, true);
      window.removeEventListener("scroll", this.onScrollBound, true);
      window.removeEventListener("resize", this.onScrollBound, true);
    }
    isExtensionElement(target) {
      if (!target || !(target instanceof Node)) return false;
      const host = this.overlay?.getHostElement();
      if (!host) return false;
      return host === target || host.contains(target);
    }
    onMouseMove(e) {
      if (!this.isActive || this.isModalOpen) return;
      if (this.isExtensionElement(e.target)) return;
      const target = document.elementFromPoint(e.clientX, e.clientY);
      if (!target || !(target instanceof HTMLElement)) return;
      if (this.isExtensionElement(target)) return;
      if (target === document.documentElement) return;
      this.hoveredElement = target;
      this.overlay?.showHighlight(target);
    }
    onMouseOver(e) {
      if (!this.isActive || this.isModalOpen) return;
      if (this.isExtensionElement(e.target)) return;
      if (e.target instanceof HTMLElement && e.target !== document.documentElement) {
        this.hoveredElement = e.target;
        this.overlay?.showHighlight(e.target);
      }
    }
    async onClick(e) {
      if (!this.isActive) return;
      if (this.isExtensionElement(e.target)) return;
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      if (this.isModalOpen) return;
      const target = this.hoveredElement || (e.target instanceof HTMLElement ? e.target : null);
      if (!target || target === document.documentElement) return;
      this.selectedElement = target;
      this.isModalOpen = true;
      this.overlay?.hideHighlight();
      this.overlay?.hideStatusPill();
      if (this.modal) {
        await this.modal.show(this.selectedElement, "element");
      }
    }
    async onKeyDown(e) {
      if (!this.isActive) return;
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        this.stop();
        return;
      }
      if (this.isModalOpen) return;
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        e.stopPropagation();
        const target = this.hoveredElement;
        if (target && target !== document.documentElement) {
          this.selectedElement = target;
          this.isModalOpen = true;
          this.overlay?.hideHighlight();
          this.overlay?.hideStatusPill();
          if (this.modal) {
            await this.modal.show(this.selectedElement, "element");
          }
        }
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        if (this.hoveredElement && this.hoveredElement.parentElement && this.hoveredElement.parentElement !== document.documentElement) {
          this.hoveredElement = this.hoveredElement.parentElement;
          this.overlay?.showHighlight(this.hoveredElement);
        }
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        if (this.hoveredElement && this.hoveredElement.firstElementChild instanceof HTMLElement) {
          this.hoveredElement = this.hoveredElement.firstElementChild;
          this.overlay?.showHighlight(this.hoveredElement);
        }
      }
    }
    onScroll() {
      if (!this.isActive || this.isModalOpen || !this.hoveredElement) return;
      this.overlay?.showHighlight(this.hoveredElement);
    }
  };

  // extension/src/content/content.ts
  if (!window.__sharedom_content_script_loaded__) {
    window.__sharedom_content_script_loaded__ = true;
    const inspector = new DomInspector();
    installPageTracker();
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (!message || typeof message !== "object") return;
      switch (message.type) {
        case "START_INSPECTOR":
          inspector.start(message.options);
          sendResponse({ success: true, active: true });
          break;
        case "CAPTURE_CONSOLE_LOGS":
          inspector.captureConsole(message.options);
          sendResponse({ success: true, active: true });
          break;
        case "CAPTURE_NETWORK_REQUESTS":
          inspector.captureNetwork(message.options);
          sendResponse({ success: true, active: true });
          break;
        case "STOP_INSPECTOR":
          inspector.stop();
          sendResponse({ success: true, active: false });
          break;
        case "TOGGLE_INSPECTOR":
          inspector.toggle(message.options);
          sendResponse({ success: true, active: inspector.getIsActive() });
          break;
        case "GET_INSPECTOR_STATUS":
          sendResponse({ active: inspector.getIsActive() });
          break;
        default:
          break;
      }
      return true;
    });
  }
})();
