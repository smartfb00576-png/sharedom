"use strict";
(() => {
  // extension/src/content/styles.ts
  var overlayStyles = `
:host {
  all: initial;
  z-index: 2147483647;
  position: fixed;
  inset: 0;
  pointer-events: none;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
}

*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

.sharedom-hidden {
  display: none !important;
}

.sharedom-status-pill {
  position: fixed;
  top: 18px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(18, 18, 24, 0.94);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  color: #f4f4f5;
  border: 1px solid rgba(255, 255, 255, 0.14);
  padding: 8px 16px;
  border-radius: 9999px;
  display: flex;
  align-items: center;
  gap: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.05);
  pointer-events: auto;
  user-select: none;
  font-size: 13px;
  font-weight: 500;
  z-index: 2147483647;
  animation: sharedomSlideDown 0.2s cubic-bezier(0.16, 1, 0.3, 1);
}

.sharedom-status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #22c55e;
  box-shadow: 0 0 8px #22c55e;
  animation: sharedomPulse 1.8s infinite;
}

.sharedom-status-title {
  color: #ffffff;
  font-weight: 600;
  letter-spacing: -0.01em;
}

.sharedom-shortcut-group {
  display: flex;
  align-items: center;
  gap: 6px;
  border-left: 1px solid rgba(255, 255, 255, 0.12);
  padding-left: 12px;
}

.sharedom-kbd {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.15);
  color: #d4d4d8;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 4px;
  line-height: 1;
}

.sharedom-close-pill-btn {
  background: transparent;
  border: none;
  color: #a1a1aa;
  cursor: pointer;
  padding: 4px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease;
}

.sharedom-close-pill-btn:hover {
  background: rgba(255, 255, 255, 0.15);
  color: #ffffff;
}

.sharedom-highlight-box {
  position: fixed;
  pointer-events: none;
  border: 2px solid #6366f1;
  background: rgba(99, 102, 241, 0.15);
  border-radius: 4px;
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.35), 0 0 24px rgba(99, 102, 241, 0.25);
  transition: top 0.05s ease-out, left 0.05s ease-out, width 0.05s ease-out, height 0.05s ease-out;
  z-index: 2147483645;
}

.sharedom-highlight-tag {
  position: absolute;
  top: -28px;
  left: 0;
  background: #0f172a;
  color: #f8fafc;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 11px;
  font-weight: 500;
  padding: 3px 8px;
  border-radius: 5px;
  border: 1px solid rgba(255, 255, 255, 0.16);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.35);
  white-space: nowrap;
  pointer-events: none;
  display: flex;
  align-items: center;
  gap: 6px;
}

.sharedom-highlight-tag.flipped-down {
  top: auto;
  bottom: -28px;
}

.sharedom-tag-name {
  color: #818cf8;
  font-weight: 700;
}

.sharedom-tag-class {
  color: #94a3b8;
}

.sharedom-tag-size {
  color: #38bdf8;
  border-left: 1px solid rgba(255, 255, 255, 0.15);
  padding-left: 6px;
}

.sharedom-modal-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.55);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
  display: flex;
  align-items: center;
  justify-content: center;
  pointer-events: auto;
  z-index: 2147483646;
  animation: sharedomFadeIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
  padding: 16px;
}

.sharedom-modal-card {
  background: #111116;
  color: #fafafa;
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 20px;
  width: 540px;
  max-width: calc(100vw - 32px);
  max-height: 90vh;
  box-shadow: 0 25px 60px -15px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.05);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  animation: sharedomScaleUp 0.22s cubic-bezier(0.16, 1, 0.3, 1);
}

.sharedom-modal-header {
  padding: 18px 22px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}

.sharedom-modal-title-wrap {
  display: flex;
  align-items: center;
  gap: 10px;
}

.sharedom-modal-logo {
  width: 28px;
  height: 28px;
  border-radius: 8px;
  background: linear-gradient(135deg, #6366f1, #06b6d4);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-weight: 800;
  font-size: 14px;
}

.sharedom-modal-title {
  font-size: 16px;
  font-weight: 600;
  color: #ffffff;
  letter-spacing: -0.01em;
}

.sharedom-modal-subtitle {
  font-size: 12px;
  color: #a1a1aa;
}

.sharedom-icon-btn {
  background: transparent;
  border: none;
  color: #71717a;
  cursor: pointer;
  padding: 6px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s ease;
}

.sharedom-icon-btn:hover {
  background: rgba(255, 255, 255, 0.08);
  color: #ffffff;
}

.sharedom-modal-body {
  padding: 20px 22px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.sharedom-preview-container {
  width: 100%;
  min-height: 180px;
  max-height: 300px;
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  background-color: #1c1c24;
  background-image: 
    linear-gradient(45deg, #262633 25%, transparent 25%), 
    linear-gradient(-45deg, #262633 25%, transparent 25%), 
    linear-gradient(45deg, transparent 75%, #262633 75%), 
    linear-gradient(-45deg, transparent 75%, #262633 75%);
  background-size: 16px 16px;
  background-position: 0 0, 0 8px, 8px -8px, -8px 0px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  position: relative;
}

.sharedom-preview-img {
  max-width: 100%;
  max-height: 290px;
  object-fit: contain;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
  border-radius: 4px;
}

.sharedom-preview-loader {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  color: #a1a1aa;
  font-size: 13px;
}

.sharedom-spinner {
  width: 28px;
  height: 28px;
  border: 3px solid rgba(255, 255, 255, 0.1);
  border-top-color: #6366f1;
  border-radius: 50%;
  animation: sharedomSpin 0.8s linear infinite;
}

.sharedom-preview-meta {
  position: absolute;
  bottom: 8px;
  right: 8px;
  background: rgba(0, 0, 0, 0.75);
  backdrop-filter: blur(6px);
  color: #e4e4e7;
  font-size: 11px;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  padding: 3px 8px;
  border-radius: 6px;
  border: 1px solid rgba(255, 255, 255, 0.12);
}

.sharedom-controls-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}

.sharedom-control-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.sharedom-control-label {
  font-size: 12px;
  font-weight: 500;
  color: #a1a1aa;
}

.sharedom-select-wrap {
  position: relative;
}

.sharedom-select {
  width: 100%;
  background: #1e1e26;
  border: 1px solid rgba(255, 255, 255, 0.12);
  color: #ffffff;
  padding: 8px 12px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  outline: none;
  cursor: pointer;
  appearance: none;
  transition: all 0.15s ease;
}

.sharedom-select:hover {
  border-color: rgba(255, 255, 255, 0.22);
}

.sharedom-select:focus {
  border-color: #6366f1;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.25);
}

.sharedom-btn-group {
  display: flex;
  border-radius: 8px;
  background: #1e1e26;
  border: 1px solid rgba(255, 255, 255, 0.12);
  overflow: hidden;
}

.sharedom-btn-option {
  flex: 1;
  background: transparent;
  border: none;
  color: #a1a1aa;
  padding: 8px 4px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.15s ease;
  text-align: center;
}

.sharedom-btn-option:not(:last-child) {
  border-right: 1px solid rgba(255, 255, 255, 0.08);
}

.sharedom-btn-option:hover {
  color: #ffffff;
  background: rgba(255, 255, 255, 0.04);
}

.sharedom-btn-option.active {
  background: #6366f1;
  color: #ffffff;
}

.sharedom-color-picker-wrap {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #1e1e26;
  border: 1px solid rgba(255, 255, 255, 0.12);
  padding: 4px 8px;
  border-radius: 8px;
}

.sharedom-color-input {
  width: 24px;
  height: 24px;
  border: none;
  border-radius: 4px;
  background: transparent;
  cursor: pointer;
  padding: 0;
}

.sharedom-color-label {
  font-size: 12px;
  color: #ffffff;
  font-family: ui-monospace, monospace;
}

.sharedom-modal-footer {
  padding: 16px 20px;
  border-top: 1px solid rgba(255, 255, 255, 0.08);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  background: #0d0d12;
}

.sharedom-footer-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.sharedom-footer-right {
  display: flex;
  align-items: center;
  gap: 10px;
}

.sharedom-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  height: 38px;
  min-height: 38px;
  max-height: 38px;
  padding: 0 14px;
  border-radius: 10px;
  font-size: 13px;
  font-weight: 600;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  transition: all 0.15s ease;
  border: none;
  outline: none;
  user-select: none;
  box-sizing: border-box;
}

.sharedom-btn-icon {
  width: 38px;
  height: 38px;
  min-width: 38px;
  max-width: 38px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.sharedom-btn svg {
  flex-shrink: 0;
}

.sharedom-btn-secondary {
  background: #24242e;
  color: #f4f4f5;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.sharedom-btn-secondary:hover {
  background: #2e2e3a;
  border-color: rgba(255, 255, 255, 0.18);
}

.sharedom-btn-primary {
  background: linear-gradient(135deg, #6366f1, #4f46e5);
  color: #ffffff;
  box-shadow: 0 4px 14px rgba(99, 102, 241, 0.35);
}

.sharedom-btn-primary:hover {
  background: linear-gradient(135deg, #4f46e5, #4338ca);
  box-shadow: 0 6px 20px rgba(99, 102, 241, 0.45);
  transform: translateY(-1px);
}

.sharedom-btn-primary:active {
  transform: translateY(0);
}

.sharedom-btn-ghost {
  background: transparent;
  color: #a1a1aa;
  padding: 8px 12px;
}

.sharedom-btn-ghost:hover {
  background: rgba(255, 255, 255, 0.08);
  color: #ffffff;
}

.sharedom-toast-container {
  position: fixed;
  bottom: 24px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  flex-direction: column;
  gap: 8px;
  z-index: 2147483647;
  pointer-events: none;
}

.sharedom-toast {
  background: #09090b;
  color: #ffffff;
  border: 1px solid rgba(255, 255, 255, 0.16);
  padding: 10px 18px;
  border-radius: 12px;
  font-size: 13px;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 10px;
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(255, 255, 255, 0.08);
  animation: sharedomToastIn 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  pointer-events: auto;
}

@keyframes sharedomSlideDown {
  from {
    opacity: 0;
    transform: translate(-50%, -12px);
  }
  to {
    opacity: 1;
    transform: translate(-50%, 0);
  }
}

@keyframes sharedomFadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes sharedomScaleUp {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

@keyframes sharedomPulse {
  0%, 100% {
    opacity: 1;
    transform: scale(1);
  }
  50% {
    opacity: 0.5;
    transform: scale(0.85);
  }
}

@keyframes sharedomSpin {
  to {
    transform: rotate(360deg);
  }
}

@keyframes sharedomToastIn {
  from {
    opacity: 0;
    transform: translateY(12px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
`;

  // extension/src/shared/i18n.ts
  var translations = {
    en: {
      popup: {
        title: "sharedom",
        badge: "v1.0.0",
        ctaTitle: "Inspect DOM Element",
        ctaSubtitle: "Hover & click any element on the page",
        defaultSettings: "Default Settings",
        resolution: "Resolution",
        format: "Format",
        resStandard: "1x Standard",
        resRetina: "2x Retina HD",
        resUltra: "3x Ultra HD",
        fmtPng: "PNG (Alpha)",
        fmtJpeg: "JPEG",
        fmtWebp: "WebP",
        shortcutsTitle: "Keyboard Shortcuts",
        shortcutInspect: "Inspect Element",
        shortcutParentChild: "Parent / Child",
        shortcutCapture: "Capture Element",
        shortcutCancel: "Cancel / Close",
        buyCoffee: "Buy me a coffee",
        footer: "Zero dependencies DOM snapshotter",
        restrictedPageTitle: "Protected Page",
        restrictedPageDesc: "Browser internal pages and Chrome Web Store are protected by security policy. Open a regular website to inspect.",
        permissionErrorTitle: "Inspection Failed",
        permissionErrorDesc: "Could not access the page. Please reload the tab or check permissions and try again.",
        btnRetry: "Retry Inspection",
        btnReloadTab: "Reload Tab"
      },
      overlay: {
        title: "DOM Inspector",
        prompt: "Click or press Enter/Space",
        parent: "\u2191 Parent",
        capture: "\u21B5 Capture",
        exit: "Esc Exit"
      },
      modal: {
        title: "Capture DOM Element",
        rendering: "Rendering DOM Snapshot...",
        resolution: "Resolution",
        format: "Format",
        background: "Background",
        bgAuto: "Auto (Detected)",
        bgTransparent: "Transparent",
        bgWhite: "White (#FFF)",
        bgDark: "Dark (#111)",
        bgCustom: "Custom...",
        reselect: "Re-select",
        reselectTooltip: "Re-select element (Esc to exit)",
        base64: "Base64",
        download: "Download",
        copyImage: "Copy Image",
        copySuccess: "Image copied to clipboard!",
        copyError: "Could not copy image to clipboard",
        dataUrlSuccess: "Base64 Data URL copied!",
        dataUrlError: "Failed to copy Data URL",
        downloaded: "Downloaded",
        captureFailed: "Failed to capture element snapshot."
      }
    },
    es: {
      popup: {
        title: "sharedom",
        badge: "v1.0.0",
        ctaTitle: "Inspeccionar Elemento DOM",
        ctaSubtitle: "Pasa el cursor y haz clic en cualquier elemento",
        defaultSettings: "Ajustes por Defecto",
        resolution: "Resoluci\xF3n",
        format: "Formato",
        resStandard: "1x Est\xE1ndar",
        resRetina: "2x Retina HD",
        resUltra: "3x Ultra HD",
        fmtPng: "PNG (Transparencia)",
        fmtJpeg: "JPEG",
        fmtWebp: "WebP",
        shortcutsTitle: "Atajos de Teclado",
        shortcutInspect: "Inspeccionar",
        shortcutParentChild: "Padre / Hijo",
        shortcutCapture: "Capturar elemento",
        shortcutCancel: "Cancelar / Cerrar",
        buyCoffee: "Inv\xEDtame un caf\xE9",
        footer: "Capturador de DOM con cero dependencias",
        restrictedPageTitle: "P\xE1gina Protegida",
        restrictedPageDesc: "Las p\xE1ginas internas del navegador y Chrome Web Store est\xE1n protegidas por seguridad. Abre una web normal para inspeccionar.",
        permissionErrorTitle: "Error de Inspecci\xF3n",
        permissionErrorDesc: "No se pudo acceder a la p\xE1gina. Por favor recarga la pesta\xF1a o verifica los permisos e intenta de nuevo.",
        btnRetry: "Reintentar Inspecci\xF3n",
        btnReloadTab: "Recargar Pesta\xF1a"
      },
      overlay: {
        title: "Inspector DOM",
        prompt: "Clic o pulsa Enter/Espacio",
        parent: "\u2191 Padre",
        capture: "\u21B5 Capturar",
        exit: "Esc Salir"
      },
      modal: {
        title: "Capturar Elemento DOM",
        rendering: "Renderizando Captura del DOM...",
        resolution: "Resoluci\xF3n",
        format: "Formato",
        background: "Fondo",
        bgAuto: "Auto (Detectado)",
        bgTransparent: "Transparente",
        bgWhite: "Blanco (#FFF)",
        bgDark: "Oscuro (#111)",
        bgCustom: "Personalizado...",
        reselect: "Re-seleccionar",
        reselectTooltip: "Re-seleccionar elemento (Esc para salir)",
        base64: "Base64",
        download: "Descargar",
        copyImage: "Copiar Imagen",
        copySuccess: "\xA1Imagen copiada al portapapeles!",
        copyError: "No se pudo copiar la imagen al portapapeles",
        dataUrlSuccess: "\xA1Data URL Base64 copiada!",
        dataUrlError: "Error al copiar Data URL",
        downloaded: "Descargado",
        captureFailed: "Error al capturar el elemento."
      }
    }
  };

  // extension/src/content/overlay.ts
  var OverlayManager = class {
    host = null;
    shadow = null;
    statusPill = null;
    highlightBox = null;
    highlightTag = null;
    tagNameEl = null;
    tagClassEl = null;
    tagSizeEl = null;
    toastContainer = null;
    language = "en";
    constructor(language = "en") {
      this.language = language;
      this.init();
    }
    setLanguage(language) {
      this.language = language;
    }
    init() {
      const existing = document.getElementById("sharedom-inspector-host");
      if (existing) {
        existing.remove();
      }
      this.host = document.createElement("div");
      this.host.id = "sharedom-inspector-host";
      this.shadow = this.host.attachShadow({ mode: "open" });
      const styleEl = document.createElement("style");
      styleEl.textContent = overlayStyles;
      this.shadow.appendChild(styleEl);
      this.createHighlightBox();
      this.createToastContainer();
      document.documentElement.appendChild(this.host);
    }
    createHighlightBox() {
      if (!this.shadow) return;
      this.highlightBox = document.createElement("div");
      this.highlightBox.className = "sharedom-highlight-box sharedom-hidden";
      this.highlightTag = document.createElement("div");
      this.highlightTag.className = "sharedom-highlight-tag";
      this.tagNameEl = document.createElement("span");
      this.tagNameEl.className = "sharedom-tag-name";
      this.tagClassEl = document.createElement("span");
      this.tagClassEl.className = "sharedom-tag-class";
      this.tagSizeEl = document.createElement("span");
      this.tagSizeEl.className = "sharedom-tag-size";
      this.highlightTag.appendChild(this.tagNameEl);
      this.highlightTag.appendChild(this.tagClassEl);
      this.highlightTag.appendChild(this.tagSizeEl);
      this.highlightBox.appendChild(this.highlightTag);
      this.shadow.appendChild(this.highlightBox);
    }
    createToastContainer() {
      if (!this.shadow) return;
      this.toastContainer = document.createElement("div");
      this.toastContainer.className = "sharedom-toast-container";
      this.shadow.appendChild(this.toastContainer);
    }
    showStatusPill(onClose, language = this.language) {
      if (!this.shadow) return;
      this.language = language;
      const t = translations[this.language].overlay;
      if (this.statusPill) {
        this.statusPill.remove();
      }
      this.statusPill = document.createElement("div");
      this.statusPill.className = "sharedom-status-pill";
      const dot = document.createElement("div");
      dot.className = "sharedom-status-dot";
      const title = document.createElement("span");
      title.className = "sharedom-status-title";
      title.textContent = t.title;
      const promptText = document.createElement("span");
      promptText.style.color = "#a1a1aa";
      promptText.textContent = t.prompt;
      const shortcutGroup = document.createElement("div");
      shortcutGroup.className = "sharedom-shortcut-group";
      const kbdParent = document.createElement("span");
      kbdParent.className = "sharedom-kbd";
      kbdParent.textContent = t.parent;
      const kbdCapture = document.createElement("span");
      kbdCapture.className = "sharedom-kbd";
      kbdCapture.textContent = t.capture;
      const kbdEsc = document.createElement("span");
      kbdEsc.className = "sharedom-kbd";
      kbdEsc.textContent = t.exit;
      shortcutGroup.appendChild(kbdParent);
      shortcutGroup.appendChild(kbdCapture);
      shortcutGroup.appendChild(kbdEsc);
      const closeBtn = document.createElement("button");
      closeBtn.className = "sharedom-close-pill-btn";
      closeBtn.setAttribute("title", `${t.exit}`);
      closeBtn.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    `;
      closeBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        onClose();
      });
      this.statusPill.appendChild(dot);
      this.statusPill.appendChild(title);
      this.statusPill.appendChild(promptText);
      this.statusPill.appendChild(shortcutGroup);
      this.statusPill.appendChild(closeBtn);
      this.shadow.appendChild(this.statusPill);
    }
    hideStatusPill() {
      if (this.statusPill) {
        this.statusPill.remove();
        this.statusPill = null;
      }
    }
    showHighlight(element) {
      if (!this.highlightBox || !this.highlightTag || !this.tagNameEl || !this.tagClassEl || !this.tagSizeEl) {
        return;
      }
      const rect = element.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) {
        this.hideHighlight();
        return;
      }
      this.highlightBox.style.top = `${rect.top}px`;
      this.highlightBox.style.left = `${rect.left}px`;
      this.highlightBox.style.width = `${rect.width}px`;
      this.highlightBox.style.height = `${rect.height}px`;
      this.highlightBox.classList.remove("sharedom-hidden");
      const tagName = element.tagName.toLowerCase();
      this.tagNameEl.textContent = tagName;
      let classDesc = "";
      if (element.id) {
        classDesc += `#${element.id}`;
      }
      if (element.classList && element.classList.length > 0) {
        const classes = Array.from(element.classList).slice(0, 2).map((c) => `.${c}`).join("");
        classDesc += classes;
      }
      this.tagClassEl.textContent = classDesc;
      const width = Math.round(rect.width);
      const height = Math.round(rect.height);
      this.tagSizeEl.textContent = `${width} \xD7 ${height}`;
      if (rect.top < 32) {
        this.highlightTag.classList.add("flipped-down");
      } else {
        this.highlightTag.classList.remove("flipped-down");
      }
    }
    hideHighlight() {
      if (this.highlightBox) {
        this.highlightBox.classList.add("sharedom-hidden");
      }
    }
    showToast(message, icon = "\u2713") {
      if (!this.toastContainer) return;
      const toast = document.createElement("div");
      toast.className = "sharedom-toast";
      const iconSpan = document.createElement("span");
      iconSpan.style.color = "#38bdf8";
      iconSpan.style.fontWeight = "700";
      iconSpan.textContent = icon;
      const msgSpan = document.createElement("span");
      msgSpan.textContent = message;
      toast.appendChild(iconSpan);
      toast.appendChild(msgSpan);
      this.toastContainer.appendChild(toast);
      setTimeout(() => {
        toast.style.transition = "opacity 0.25s ease, transform 0.25s ease";
        toast.style.opacity = "0";
        toast.style.transform = "translateY(12px)";
        setTimeout(() => toast.remove(), 260);
      }, 2400);
    }
    getShadowRoot() {
      return this.shadow;
    }
    getHostElement() {
      return this.host;
    }
    destroy() {
      if (this.host && this.host.parentNode) {
        this.host.remove();
      }
      this.host = null;
      this.shadow = null;
      this.statusPill = null;
      this.highlightBox = null;
      this.toastContainer = null;
    }
  };

  // src/dom.ts
  function resolveElement(target) {
    if (typeof target === "string") {
      const element = document.querySelector(target);
      if (!element) {
        throw new Error(`[sharedom]: No element found matching selector "${target}".`);
      }
      return element;
    }
    if (target instanceof HTMLElement) {
      return target;
    }
    throw new Error("[sharedom]: Target must be a valid CSS selector string or an HTMLElement.");
  }
  function validateElementDimensions(element) {
    const rect = element.getBoundingClientRect();
    const width = Math.round(rect.width);
    const height = Math.round(rect.height);
    if (width <= 0 || height <= 0) {
      throw new Error("[sharedom]: Cannot capture element with width or height of 0. Ensure the element is visible in the DOM.");
    }
    return { width, height };
  }
  function validateOptions(options) {
    if (options.scale !== void 0 && (typeof options.scale !== "number" || options.scale <= 0)) {
      throw new Error("[sharedom]: Scale option must be a positive number.");
    }
    if (options.quality !== void 0 && (typeof options.quality !== "number" || options.quality < 0 || options.quality > 1)) {
      throw new Error("[sharedom]: Quality option must be a number between 0 and 1.");
    }
    if (options.format !== void 0 && options.format !== "png" && options.format !== "jpeg" && options.format !== "webp") {
      throw new Error('[sharedom]: Format option must be "png", "jpeg", or "webp".');
    }
  }
  function syncDynamicStates(source, target) {
    if (source instanceof HTMLInputElement && target instanceof HTMLInputElement) {
      target.setAttribute("value", source.value);
      target.value = source.value;
      if (source.checked) {
        target.setAttribute("checked", "");
        target.checked = true;
      }
    } else if (source instanceof HTMLTextAreaElement && target instanceof HTMLTextAreaElement) {
      target.textContent = source.value;
      target.value = source.value;
    } else if (source instanceof HTMLSelectElement && target instanceof HTMLSelectElement) {
      target.value = source.value;
      const targetOptions = target.querySelectorAll("option");
      const selectedIndex = source.selectedIndex;
      if (selectedIndex >= 0 && targetOptions[selectedIndex]) {
        targetOptions[selectedIndex].setAttribute("selected", "true");
      }
    } else if (source instanceof HTMLCanvasElement && target instanceof HTMLCanvasElement) {
      try {
        const dataUrl = source.toDataURL();
        const image = new Image();
        image.src = dataUrl;
        target.replaceWith(image);
      } catch {
      }
    }
    const sourceChildren = Array.from(source.children);
    const targetChildren = Array.from(target.children);
    for (let i = 0; i < sourceChildren.length; i++) {
      if (targetChildren[i]) {
        syncDynamicStates(sourceChildren[i], targetChildren[i]);
      }
    }
  }

  // src/styles.ts
  function cloneComputedStyles(source, target) {
    const sourceStyles = window.getComputedStyle(source);
    const targetElement = target;
    for (let i = 0; i < sourceStyles.length; i++) {
      const key = sourceStyles[i];
      const value = sourceStyles.getPropertyValue(key);
      const priority = sourceStyles.getPropertyPriority(key);
      targetElement.style.setProperty(key, value, priority);
    }
    const sourceChildren = Array.from(source.children);
    const targetChildren = Array.from(target.children);
    for (let i = 0; i < sourceChildren.length; i++) {
      if (targetChildren[i]) {
        cloneComputedStyles(sourceChildren[i], targetChildren[i]);
      }
    }
  }
  function getDocumentFontStyles() {
    let fontStyles = "";
    const linkElements = Array.from(document.querySelectorAll('link[rel="stylesheet"]'));
    for (const link of linkElements) {
      if (link.href) {
        fontStyles += `@import url('${link.href}');
`;
      }
    }
    try {
      const sheets = Array.from(document.styleSheets);
      for (const sheet of sheets) {
        try {
          const rules = Array.from(sheet.cssRules || []);
          for (const rule of rules) {
            if (rule instanceof CSSFontFaceRule) {
              fontStyles += rule.cssText + "\n";
            }
          }
        } catch {
          continue;
        }
      }
    } catch {
    }
    return fontStyles;
  }

  // src/images.ts
  async function fetchUrlViaChromeExtension(url) {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      return null;
    }
    try {
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: "SHAREDOM_FETCH_IMAGE", url }, (res) => {
          if (chrome.runtime.lastError || !res) {
            resolve({});
          } else {
            resolve(res);
          }
        });
      });
      if (response?.dataUrl && response.dataUrl.startsWith("data:")) {
        return response.dataUrl;
      }
    } catch {
    }
    return null;
  }
  async function fetchUrlAsDataUrl(url) {
    if (!url || url.startsWith("data:")) {
      return url;
    }
    const extensionDataUrl = await fetchUrlViaChromeExtension(url);
    if (extensionDataUrl) {
      return extensionDataUrl;
    }
    try {
      const response = await fetch(url, { mode: "cors" });
      if (response.ok) {
        const blob = await response.blob();
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            resolve(typeof reader.result === "string" ? reader.result : url);
          };
          reader.onerror = () => {
            resolve(url);
          };
          reader.readAsDataURL(blob);
        });
      }
    } catch {
    }
    try {
      const anonymousDataUrl = await new Promise((resolve, reject) => {
        const temp = new Image();
        temp.crossOrigin = "anonymous";
        temp.onload = () => {
          try {
            const canvas = document.createElement("canvas");
            canvas.width = temp.naturalWidth;
            canvas.height = temp.naturalHeight;
            const ctx = canvas.getContext("2d");
            if (!ctx) return reject();
            ctx.drawImage(temp, 0, 0);
            resolve(canvas.toDataURL("image/png"));
          } catch (e) {
            reject(e);
          }
        };
        temp.onerror = reject;
        temp.src = url;
      });
      if (anonymousDataUrl && anonymousDataUrl.startsWith("data:")) {
        return anonymousDataUrl;
      }
    } catch {
    }
    return url;
  }
  async function fetchImageAsDataUrl(img) {
    const url = img.currentSrc || img.src || img.getAttribute("src") || "";
    if (!url || url.startsWith("data:")) {
      return url;
    }
    const fetched = await fetchUrlAsDataUrl(url);
    if (fetched && fetched.startsWith("data:")) {
      return fetched;
    }
    if (img.complete && img.naturalWidth > 0 && img.naturalHeight > 0) {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          return canvas.toDataURL("image/png");
        }
      } catch {
      }
    }
    return url;
  }
  async function inlineImages(rootElement) {
    const images = Array.from(rootElement.querySelectorAll("img"));
    const originalSources = /* @__PURE__ */ new Map();
    const inliningPromises = images.map(async (img) => {
      const originalSrc = img.getAttribute("src") || "";
      const originalSrcset = img.getAttribute("srcset") || void 0;
      originalSources.set(img, { src: originalSrc, srcset: originalSrcset });
      const dataUrl = await fetchImageAsDataUrl(img);
      if (dataUrl && dataUrl.startsWith("data:")) {
        img.removeAttribute("srcset");
        img.removeAttribute("sizes");
        img.setAttribute("src", dataUrl);
      }
    });
    const svgImages = Array.from(rootElement.querySelectorAll("image"));
    const svgPromises = svgImages.map(async (svgImg) => {
      const href = svgImg.getAttribute("href") || svgImg.getAttribute("xlink:href") || "";
      if (href && !href.startsWith("data:")) {
        const dataUrl = await fetchUrlAsDataUrl(href);
        if (dataUrl && dataUrl.startsWith("data:")) {
          svgImg.setAttribute("href", dataUrl);
          if (svgImg.hasAttribute("xlink:href")) {
            svgImg.setAttribute("xlink:href", dataUrl);
          }
        }
      }
    });
    const allElements = [rootElement, ...Array.from(rootElement.querySelectorAll("*"))];
    const bgPromises = allElements.map(async (el) => {
      const bg = el.style.backgroundImage || window.getComputedStyle(el).backgroundImage;
      if (!bg || bg === "none") return;
      const match = bg.match(/url\(["']?(https?:\/\/[^"')]+)["']?\)/i);
      if (match && match[1]) {
        const bgUrl = match[1];
        const dataUrl = await fetchUrlAsDataUrl(bgUrl);
        if (dataUrl && dataUrl.startsWith("data:")) {
          el.style.backgroundImage = `url("${dataUrl}")`;
        }
      }
    });
    await Promise.all([...inliningPromises, ...svgPromises, ...bgPromises]);
    return () => {
      originalSources.clear();
    };
  }

  // src/svg.ts
  function createSvgDataUrl(element, width, height) {
    const serializedHtml = new XMLSerializer().serializeToString(element);
    const fontStyles = getDocumentFontStyles();
    const styleBlock = fontStyles ? `<style><![CDATA[
${fontStyles}
]]></style>` : "";
    const svgString = `
    <svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
      <foreignObject width="100%" height="100%">
        <div xmlns="http://www.w3.org/1999/xhtml" style="width:100%;height:100%;">
          ${styleBlock}
          ${serializedHtml}
        </div>
      </foreignObject>
    </svg>
  `;
    return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgString)}`;
  }

  // src/optimizer.ts
  function optimizeCanvasPixels(context, width, height) {
    const imageData = context.getImageData(0, 0, width, height);
    const data = imageData.data;
    const pixelView = new Uint32Array(data.buffer);
    const length = pixelView.length;
    let hasModifications = false;
    for (let i = 0; i < length; i++) {
      if ((pixelView[i] & 4278190080) === 0 && pixelView[i] !== 0) {
        pixelView[i] = 0;
        hasModifications = true;
      }
    }
    if (hasModifications) {
      context.putImageData(imageData, 0, 0);
    }
  }
  function optimizeDataUrl(dataUrl) {
    const commaIndex = dataUrl.indexOf(",");
    if (commaIndex === -1) {
      return dataUrl;
    }
    const header = dataUrl.slice(0, commaIndex);
    const base64Payload = dataUrl.slice(commaIndex + 1).trim();
    return `${header},${base64Payload}`;
  }
  function exportOptimizedCanvas(canvas, context, format = "png", quality = 0.92) {
    optimizeCanvasPixels(context, canvas.width, canvas.height);
    const mimeType = format === "jpeg" ? "image/jpeg" : format === "webp" ? "image/webp" : "image/png";
    const rawDataUrl = canvas.toDataURL(mimeType, quality);
    return optimizeDataUrl(rawDataUrl);
  }

  // src/canvas.ts
  function renderSvgToCanvas(svgDataUrl, width, height, options) {
    const { scale = 1, backgroundColor, quality = 0.92, format = "png", optimize = true } = options;
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(width * scale);
        canvas.height = Math.round(height * scale);
        const context = canvas.getContext("2d", { willReadFrequently: true });
        if (!context) {
          return reject(new Error("[sharedom]: Could not obtain 2D canvas context."));
        }
        context.imageSmoothingEnabled = true;
        context.imageSmoothingQuality = "high";
        context.scale(scale, scale);
        if (backgroundColor) {
          context.fillStyle = backgroundColor;
          context.fillRect(0, 0, width, height);
        }
        context.drawImage(image, 0, 0);
        try {
          if (optimize) {
            const dataUrl = exportOptimizedCanvas(canvas, context, format, quality);
            resolve(dataUrl);
          } else {
            const mimeType = format === "jpeg" ? "image/jpeg" : format === "webp" ? "image/webp" : "image/png";
            const dataUrl = canvas.toDataURL(mimeType, quality);
            resolve(dataUrl);
          }
        } catch (error) {
          reject(new Error(`[sharedom]: Failed to export canvas image. ${error}`));
        }
      };
      image.onerror = (error) => {
        reject(new Error(`[sharedom]: Failed to load rendered SVG image. ${error}`));
      };
      image.src = svgDataUrl;
    });
  }

  // src/index.ts
  async function capture(target, options = {}) {
    validateOptions(options);
    const element = resolveElement(target);
    const { width, height } = validateElementDimensions(element);
    const targetWidth = options.width ?? width;
    const targetHeight = options.height ?? height;
    const clone = element.cloneNode(true);
    syncDynamicStates(element, clone);
    cloneComputedStyles(element, clone);
    clone.style.width = `${targetWidth}px`;
    clone.style.height = `${targetHeight}px`;
    clone.style.boxSizing = "border-box";
    clone.style.margin = "0";
    const cleanupImages = await inlineImages(clone);
    try {
      const svgDataUrl = createSvgDataUrl(clone, targetWidth, targetHeight);
      return await renderSvgToCanvas(svgDataUrl, targetWidth, targetHeight, options);
    } finally {
      cleanupImages();
    }
  }

  // extension/src/content/modal.ts
  function rgbToHex(rgbStr) {
    const match = rgbStr.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (!match) return "#6366f1";
    const r = parseInt(match[1], 10).toString(16).padStart(2, "0");
    const g = parseInt(match[2], 10).toString(16).padStart(2, "0");
    const b = parseInt(match[3], 10).toString(16).padStart(2, "0");
    return `#${r}${g}${b}`;
  }
  var ActionModal = class {
    shadow;
    backdrop = null;
    currentElement = null;
    currentDataUrl = "";
    detectedBgColor = void 0;
    currentOptions = {
      scale: 2,
      format: "png",
      backgroundColor: void 0,
      language: "en"
    };
    isCapturing = false;
    onClose;
    onReselect;
    onToast;
    constructor(shadow, callbacks, initialOptions) {
      this.shadow = shadow;
      this.onClose = callbacks.onClose;
      this.onReselect = callbacks.onReselect;
      this.onToast = callbacks.onToast;
      if (initialOptions) {
        this.currentOptions = { ...this.currentOptions, ...initialOptions };
      }
    }
    setOptions(options) {
      this.currentOptions = { ...this.currentOptions, ...options };
    }
    detectBackgroundColor(element) {
      let current = element;
      while (current && current !== document.documentElement) {
        const style = window.getComputedStyle(current);
        const bg = style.backgroundColor;
        if (bg && bg !== "transparent" && bg !== "rgba(0, 0, 0, 0)" && !bg.endsWith(", 0)")) {
          return bg;
        }
        current = current.parentElement;
      }
      const bodyStyle = window.getComputedStyle(document.body);
      const bodyBg = bodyStyle.backgroundColor;
      if (bodyBg && bodyBg !== "transparent" && bodyBg !== "rgba(0, 0, 0, 0)" && !bodyBg.endsWith(", 0)")) {
        return bodyBg;
      }
      return void 0;
    }
    async show(element) {
      this.currentElement = element;
      this.detectedBgColor = this.detectBackgroundColor(element);
      this.currentOptions.backgroundColor = this.detectedBgColor;
      this.hide();
      this.createModalDOM();
      await this.refreshCapture();
    }
    hide() {
      if (this.backdrop) {
        this.backdrop.remove();
        this.backdrop = null;
      }
    }
    createModalDOM() {
      if (!this.currentElement) return;
      const t = translations[this.currentOptions.language].modal;
      this.backdrop = document.createElement("div");
      this.backdrop.className = "sharedom-modal-backdrop";
      const card = document.createElement("div");
      card.className = "sharedom-modal-card";
      card.addEventListener("click", (e) => e.stopPropagation());
      const header = document.createElement("div");
      header.className = "sharedom-modal-header";
      const titleWrap = document.createElement("div");
      titleWrap.className = "sharedom-modal-title-wrap";
      const logo = document.createElement("div");
      logo.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="28" height="28" fill="none">
        <defs>
          <linearGradient id="modalLogoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#a78bfa" />
            <stop offset="100%" stop-color="#7c3aed" />
          </linearGradient>
        </defs>
        <rect width="48" height="48" rx="12" fill="url(#modalLogoGrad)" />
        <rect x="1" y="1" width="46" height="46" rx="11" stroke="rgba(255,255,255,0.25)" stroke-width="1" />
        <path d="M12 18V14H16" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M36 18V14H32" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M12 30V34H16" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M36 30V34H32" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M19 22L16 24.5L19 27" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M29 22L32 24.5L29 27" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
        <circle cx="24" cy="24.5" r="3" fill="white" />
        <circle cx="34" cy="14" r="1.5" fill="#facc15" />
      </svg>
    `;
      logo.style.display = "flex";
      logo.style.alignItems = "center";
      const textWrap = document.createElement("div");
      const title = document.createElement("div");
      title.className = "sharedom-modal-title";
      title.textContent = t.title;
      const subtitle = document.createElement("div");
      subtitle.className = "sharedom-modal-subtitle";
      const tag = this.currentElement.tagName.toLowerCase();
      const idStr = this.currentElement.id ? `#${this.currentElement.id}` : "";
      const classStr = this.currentElement.className && typeof this.currentElement.className === "string" ? `.${this.currentElement.className.trim().split(/\s+/).slice(0, 2).join(".")}` : "";
      subtitle.textContent = `<${tag}${idStr}${classStr}>`;
      textWrap.appendChild(title);
      textWrap.appendChild(subtitle);
      titleWrap.appendChild(logo);
      titleWrap.appendChild(textWrap);
      const closeBtn = document.createElement("button");
      closeBtn.className = "sharedom-icon-btn";
      closeBtn.setAttribute("title", "Close (Esc)");
      closeBtn.innerHTML = `
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    `;
      closeBtn.addEventListener("click", () => {
        this.hide();
        this.onClose();
      });
      header.appendChild(titleWrap);
      header.appendChild(closeBtn);
      const body = document.createElement("div");
      body.className = "sharedom-modal-body";
      const previewContainer = document.createElement("div");
      previewContainer.className = "sharedom-preview-container";
      previewContainer.id = "sharedom-modal-preview-box";
      const loader = document.createElement("div");
      loader.className = "sharedom-preview-loader";
      loader.innerHTML = `
      <div class="sharedom-spinner"></div>
      <span>${t.rendering}</span>
    `;
      previewContainer.appendChild(loader);
      const controlsGrid = document.createElement("div");
      controlsGrid.className = "sharedom-controls-grid";
      const scaleGroup = document.createElement("div");
      scaleGroup.className = "sharedom-control-group";
      const scaleLabel = document.createElement("label");
      scaleLabel.className = "sharedom-control-label";
      scaleLabel.textContent = t.resolution;
      const scaleBtnGroup = document.createElement("div");
      scaleBtnGroup.className = "sharedom-btn-group";
      const scales = [1, 2, 3];
      scales.forEach((s) => {
        const btn = document.createElement("button");
        btn.className = `sharedom-btn-option ${this.currentOptions.scale === s ? "active" : ""}`;
        btn.textContent = `${s}x`;
        btn.addEventListener("click", async () => {
          if (this.currentOptions.scale === s || this.isCapturing) return;
          scaleBtnGroup.querySelectorAll(".sharedom-btn-option").forEach((b) => b.classList.remove("active"));
          btn.classList.add("active");
          this.currentOptions.scale = s;
          await this.refreshCapture();
        });
        scaleBtnGroup.appendChild(btn);
      });
      scaleGroup.appendChild(scaleLabel);
      scaleGroup.appendChild(scaleBtnGroup);
      const formatGroup = document.createElement("div");
      formatGroup.className = "sharedom-control-group";
      const formatLabel = document.createElement("label");
      formatLabel.className = "sharedom-control-label";
      formatLabel.textContent = t.format;
      const formatSelectWrap = document.createElement("div");
      formatSelectWrap.className = "sharedom-select-wrap";
      const formatSelect = document.createElement("select");
      formatSelect.className = "sharedom-select";
      ["png", "jpeg", "webp"].forEach((fmt) => {
        const opt = document.createElement("option");
        opt.value = fmt;
        opt.textContent = fmt.toUpperCase();
        if (this.currentOptions.format === fmt) opt.selected = true;
        formatSelect.appendChild(opt);
      });
      formatSelect.addEventListener("change", async () => {
        if (this.isCapturing) return;
        this.currentOptions.format = formatSelect.value;
        await this.refreshCapture();
      });
      formatSelectWrap.appendChild(formatSelect);
      formatGroup.appendChild(formatLabel);
      formatGroup.appendChild(formatSelectWrap);
      const bgGroup = document.createElement("div");
      bgGroup.className = "sharedom-control-group";
      const bgLabel = document.createElement("label");
      bgLabel.className = "sharedom-control-label";
      bgLabel.textContent = t.background;
      const bgSelectWrap = document.createElement("div");
      bgSelectWrap.className = "sharedom-select-wrap";
      const bgSelect = document.createElement("select");
      bgSelect.className = "sharedom-select";
      const bgOptions = [];
      if (this.detectedBgColor) {
        bgOptions.push({ label: t.bgAuto, value: "auto" });
      }
      bgOptions.push({ label: t.bgTransparent, value: "transparent" });
      bgOptions.push({ label: t.bgWhite, value: "#ffffff" });
      bgOptions.push({ label: t.bgDark, value: "#111116" });
      bgOptions.push({ label: t.bgCustom, value: "custom" });
      bgOptions.forEach((optData) => {
        const opt = document.createElement("option");
        opt.value = optData.value;
        opt.textContent = optData.label;
        if (this.detectedBgColor && optData.value === "auto") {
          opt.selected = true;
        } else if (!this.detectedBgColor && optData.value === "transparent") {
          opt.selected = true;
        }
        bgSelect.appendChild(opt);
      });
      const customColorInput = document.createElement("input");
      customColorInput.type = "color";
      customColorInput.className = "sharedom-color-input";
      customColorInput.value = this.detectedBgColor ? rgbToHex(this.detectedBgColor) : "#6366f1";
      customColorInput.style.display = "none";
      bgSelect.addEventListener("change", async () => {
        if (this.isCapturing) return;
        const val = bgSelect.value;
        if (val === "auto") {
          this.currentOptions.backgroundColor = this.detectedBgColor;
          customColorInput.style.display = "none";
        } else if (val === "transparent") {
          this.currentOptions.backgroundColor = void 0;
          customColorInput.style.display = "none";
        } else if (val === "custom") {
          customColorInput.style.display = "block";
          this.currentOptions.backgroundColor = customColorInput.value;
        } else {
          this.currentOptions.backgroundColor = val;
          customColorInput.style.display = "none";
        }
        await this.refreshCapture();
      });
      customColorInput.addEventListener("input", async () => {
        if (this.isCapturing) return;
        this.currentOptions.backgroundColor = customColorInput.value;
        await this.refreshCapture();
      });
      bgSelectWrap.appendChild(bgSelect);
      bgGroup.appendChild(bgLabel);
      bgGroup.appendChild(bgSelectWrap);
      bgGroup.appendChild(customColorInput);
      controlsGrid.appendChild(scaleGroup);
      controlsGrid.appendChild(formatGroup);
      controlsGrid.appendChild(bgGroup);
      body.appendChild(previewContainer);
      body.appendChild(controlsGrid);
      const footer = document.createElement("div");
      footer.className = "sharedom-modal-footer";
      const footerLeft = document.createElement("div");
      footerLeft.className = "sharedom-footer-left";
      const reselectBtn = document.createElement("button");
      reselectBtn.className = "sharedom-btn sharedom-btn-secondary sharedom-btn-icon";
      reselectBtn.setAttribute("title", t.reselectTooltip);
      reselectBtn.setAttribute("aria-label", t.reselectTooltip);
      reselectBtn.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"></path>
        <path d="M21 3v5h-5"></path>
      </svg>
    `;
      reselectBtn.addEventListener("click", () => {
        this.hide();
        this.onReselect();
      });
      const copyDataUrlBtn = document.createElement("button");
      copyDataUrlBtn.className = "sharedom-btn sharedom-btn-ghost";
      copyDataUrlBtn.setAttribute("title", "Copy Base64 Data URL string");
      copyDataUrlBtn.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="16 18 22 12 16 6"></polyline>
        <polyline points="8 6 2 12 8 18"></polyline>
      </svg>
      ${t.base64}
    `;
      copyDataUrlBtn.addEventListener("click", async () => {
        if (!this.currentDataUrl) return;
        try {
          await navigator.clipboard.writeText(this.currentDataUrl);
          this.onToast(t.dataUrlSuccess, "\u{1F4CB}");
        } catch {
          this.onToast(t.dataUrlError, "\u26A0\uFE0F");
        }
      });
      footerLeft.appendChild(reselectBtn);
      footerLeft.appendChild(copyDataUrlBtn);
      const footerRight = document.createElement("div");
      footerRight.className = "sharedom-footer-right";
      const downloadBtn = document.createElement("button");
      downloadBtn.className = "sharedom-btn sharedom-btn-secondary";
      downloadBtn.innerHTML = `
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
        <polyline points="7 10 12 15 17 10"></polyline>
        <line x1="12" y1="15" x2="12" y2="3"></line>
      </svg>
      ${t.download}
    `;
      downloadBtn.addEventListener("click", () => {
        this.triggerDownload();
      });
      const copyBtn = document.createElement("button");
      copyBtn.className = "sharedom-btn sharedom-btn-primary";
      copyBtn.innerHTML = `
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
      </svg>
      ${t.copyImage}
    `;
      copyBtn.addEventListener("click", async () => {
        await this.copyImageToClipboard();
      });
      footerRight.appendChild(downloadBtn);
      footerRight.appendChild(copyBtn);
      footer.appendChild(footerLeft);
      footer.appendChild(footerRight);
      card.appendChild(header);
      card.appendChild(body);
      card.appendChild(footer);
      this.backdrop.appendChild(card);
      this.shadow.appendChild(this.backdrop);
    }
    async refreshCapture() {
      if (!this.currentElement || !this.shadow) return;
      const t = translations[this.currentOptions.language].modal;
      this.isCapturing = true;
      const previewBox = this.shadow.getElementById("sharedom-modal-preview-box");
      if (previewBox) {
        previewBox.innerHTML = `
        <div class="sharedom-preview-loader">
          <div class="sharedom-spinner"></div>
          <span>${t.rendering}</span>
        </div>
      `;
      }
      try {
        const options = {
          scale: this.currentOptions.scale,
          format: this.currentOptions.format,
          backgroundColor: this.currentOptions.backgroundColor,
          optimize: true
        };
        const dataUrl = await capture(this.currentElement, options);
        this.currentDataUrl = dataUrl;
        if (previewBox) {
          previewBox.innerHTML = "";
          const img = document.createElement("img");
          img.className = "sharedom-preview-img";
          img.src = dataUrl;
          const rect = this.currentElement.getBoundingClientRect();
          const width = Math.round(rect.width * this.currentOptions.scale);
          const height = Math.round(rect.height * this.currentOptions.scale);
          const meta = document.createElement("div");
          meta.className = "sharedom-preview-meta";
          meta.textContent = `${width} \xD7 ${height} px (${this.currentOptions.scale}x ${this.currentOptions.format.toUpperCase()})`;
          previewBox.appendChild(img);
          previewBox.appendChild(meta);
        }
      } catch (error) {
        if (previewBox) {
          previewBox.innerHTML = `
          <div style="color: #ef4444; font-size: 13px; text-align: center; padding: 16px;">
            ${t.captureFailed}<br>
            <span style="font-size: 11px; color: #a1a1aa;">${String(error)}</span>
          </div>
        `;
        }
      } finally {
        this.isCapturing = false;
      }
    }
    async copyImageToClipboard() {
      if (!this.currentElement) return;
      const t = translations[this.currentOptions.language].modal;
      try {
        let pngBlob;
        if (this.currentOptions.format === "png" && this.currentDataUrl.startsWith("data:image/png")) {
          const res = await fetch(this.currentDataUrl);
          pngBlob = await res.blob();
        } else {
          const pngDataUrl = await capture(this.currentElement, {
            scale: this.currentOptions.scale,
            format: "png",
            backgroundColor: this.currentOptions.backgroundColor,
            optimize: true
          });
          const res = await fetch(pngDataUrl);
          pngBlob = await res.blob();
        }
        await navigator.clipboard.write([
          new ClipboardItem({ "image/png": pngBlob })
        ]);
        this.onToast(t.copySuccess, "\u{1F4CB}");
      } catch (error) {
        try {
          if (this.currentDataUrl) {
            await navigator.clipboard.writeText(this.currentDataUrl);
            this.onToast(t.dataUrlSuccess, "\u{1F4CB}");
            return;
          }
        } catch {
        }
        this.onToast(t.copyError, "\u26A0\uFE0F");
      }
    }
    triggerDownload() {
      if (!this.currentDataUrl || !this.currentElement) return;
      const t = translations[this.currentOptions.language].modal;
      const tag = this.currentElement.tagName.toLowerCase();
      const id = this.currentElement.id ? `-${this.currentElement.id}` : "";
      const now = /* @__PURE__ */ new Date();
      const timestamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}-${String(now.getHours()).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}${String(now.getSeconds()).padStart(2, "0")}`;
      const ext = this.currentOptions.format;
      const filename = `domsnap-${tag}${id}-${timestamp}.${ext}`;
      const link = document.createElement("a");
      link.download = filename;
      link.href = this.currentDataUrl;
      link.click();
      this.onToast(`${t.downloaded} ${filename}`, "\u{1F4E5}");
    }
  };

  // extension/src/content/inspector.ts
  var DomInspector = class {
    overlay = null;
    modal = null;
    isActive = false;
    isModalOpen = false;
    hoveredElement = null;
    selectedElement = null;
    currentLanguage = "en";
    onMouseMoveBound = this.onMouseMove.bind(this);
    onMouseOverBound = this.onMouseOver.bind(this);
    onClickBound = this.onClick.bind(this);
    onKeyDownBound = this.onKeyDown.bind(this);
    onScrollBound = this.onScroll.bind(this);
    async start(options) {
      if (this.isActive) return;
      this.isActive = true;
      this.isModalOpen = false;
      this.hoveredElement = null;
      this.selectedElement = null;
      let scale = options?.scale ?? 2;
      let format = options?.format ?? "png";
      let language = options?.language;
      if (!language) {
        try {
          const stored = await chrome.storage.local.get(["language", "defaultScale", "defaultFormat"]);
          if (stored.language === "en" || stored.language === "es") {
            language = stored.language;
          }
          if (stored.defaultScale && !options?.scale) {
            scale = Number(stored.defaultScale);
          }
          if (stored.defaultFormat && !options?.format) {
            if (stored.defaultFormat === "png" || stored.defaultFormat === "jpeg" || stored.defaultFormat === "webp") {
              format = stored.defaultFormat;
            }
          }
        } catch {
        }
      }
      this.currentLanguage = language || "en";
      if (!this.overlay) {
        this.overlay = new OverlayManager(this.currentLanguage);
      } else {
        this.overlay.setLanguage(this.currentLanguage);
      }
      const shadow = this.overlay.getShadowRoot();
      if (shadow) {
        const modalOptions = {
          scale,
          format,
          language: this.currentLanguage
        };
        this.modal = new ActionModal(
          shadow,
          {
            onClose: () => this.stop(),
            onReselect: () => this.resumeInspection(),
            onToast: (msg, icon) => this.overlay?.showToast(msg, icon)
          },
          modalOptions
        );
      }
      this.overlay.showStatusPill(() => this.stop(), this.currentLanguage);
      this.attachEvents();
    }
    stop() {
      if (!this.isActive) return;
      this.detachEvents();
      this.isActive = false;
      this.isModalOpen = false;
      this.hoveredElement = null;
      this.selectedElement = null;
      if (this.modal) {
        this.modal.hide();
        this.modal = null;
      }
      if (this.overlay) {
        this.overlay.destroy();
        this.overlay = null;
      }
    }
    async toggle(options) {
      if (this.isActive) {
        this.stop();
      } else {
        await this.start(options);
      }
    }
    getIsActive() {
      return this.isActive;
    }
    resumeInspection() {
      this.isModalOpen = false;
      this.selectedElement = null;
      if (this.overlay) {
        this.overlay.showStatusPill(() => this.stop(), this.currentLanguage);
      }
    }
    attachEvents() {
      window.addEventListener("mousemove", this.onMouseMoveBound, true);
      window.addEventListener("mouseover", this.onMouseOverBound, true);
      window.addEventListener("click", this.onClickBound, true);
      window.addEventListener("keydown", this.onKeyDownBound, true);
      window.addEventListener("scroll", this.onScrollBound, true);
      window.addEventListener("resize", this.onScrollBound, true);
    }
    detachEvents() {
      window.removeEventListener("mousemove", this.onMouseMoveBound, true);
      window.removeEventListener("mouseover", this.onMouseOverBound, true);
      window.removeEventListener("click", this.onClickBound, true);
      window.removeEventListener("keydown", this.onKeyDownBound, true);
      window.removeEventListener("scroll", this.onScrollBound, true);
      window.removeEventListener("resize", this.onScrollBound, true);
    }
    isExtensionElement(target) {
      if (!target || !(target instanceof Node)) return false;
      const host = this.overlay?.getHostElement();
      if (!host) return false;
      return host === target || host.contains(target);
    }
    onMouseMove(e) {
      if (!this.isActive || this.isModalOpen) return;
      if (this.isExtensionElement(e.target)) return;
      const target = document.elementFromPoint(e.clientX, e.clientY);
      if (!target || !(target instanceof HTMLElement)) return;
      if (this.isExtensionElement(target)) return;
      if (target === document.documentElement) return;
      this.hoveredElement = target;
      this.overlay?.showHighlight(target);
    }
    onMouseOver(e) {
      if (!this.isActive || this.isModalOpen) return;
      if (this.isExtensionElement(e.target)) return;
      if (e.target instanceof HTMLElement && e.target !== document.documentElement) {
        this.hoveredElement = e.target;
        this.overlay?.showHighlight(e.target);
      }
    }
    onClick(e) {
      if (!this.isActive) return;
      if (this.isExtensionElement(e.target)) return;
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      if (this.isModalOpen) return;
      const target = this.hoveredElement || (e.target instanceof HTMLElement ? e.target : null);
      if (!target || target === document.documentElement) return;
      this.selectedElement = target;
      this.isModalOpen = true;
      this.overlay?.hideHighlight();
      this.overlay?.hideStatusPill();
      if (this.modal) {
        this.modal.show(this.selectedElement);
      }
    }
    onKeyDown(e) {
      if (!this.isActive) return;
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        this.stop();
        return;
      }
      if (this.isModalOpen) return;
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        e.stopPropagation();
        const target = this.hoveredElement;
        if (target && target !== document.documentElement) {
          this.selectedElement = target;
          this.isModalOpen = true;
          this.overlay?.hideHighlight();
          this.overlay?.hideStatusPill();
          if (this.modal) {
            this.modal.show(this.selectedElement);
          }
        }
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        if (this.hoveredElement && this.hoveredElement.parentElement && this.hoveredElement.parentElement !== document.documentElement) {
          this.hoveredElement = this.hoveredElement.parentElement;
          this.overlay?.showHighlight(this.hoveredElement);
        }
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        if (this.hoveredElement && this.hoveredElement.firstElementChild instanceof HTMLElement) {
          this.hoveredElement = this.hoveredElement.firstElementChild;
          this.overlay?.showHighlight(this.hoveredElement);
        }
      }
    }
    onScroll() {
      if (!this.isActive || this.isModalOpen || !this.hoveredElement) return;
      this.overlay?.showHighlight(this.hoveredElement);
    }
  };

  // extension/src/content/content.ts
  var inspector = new DomInspector();
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || typeof message !== "object") return;
    switch (message.type) {
      case "START_INSPECTOR":
        inspector.start(message.options);
        sendResponse({ success: true, active: true });
        break;
      case "STOP_INSPECTOR":
        inspector.stop();
        sendResponse({ success: true, active: false });
        break;
      case "TOGGLE_INSPECTOR":
        inspector.toggle(message.options);
        sendResponse({ success: true, active: inspector.getIsActive() });
        break;
      case "GET_INSPECTOR_STATUS":
        sendResponse({ active: inspector.getIsActive() });
        break;
      default:
        break;
    }
    return true;
  });
})();
